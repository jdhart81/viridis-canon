# Codex task: deposit the P1C confirmatory pre-registration on Zenodo

Prepared by Claude for Justin Hart, 2026-10-20.

**Scope:** one new Zenodo record holding the frozen confirmatory plan for the P1 wildfire replication in northeast Washington.

**Out of scope:** no other Zenodo, GitHub or website write.

**How to use:** Justin ticks Section 0 and sends this file to Codex.

**Supporting files:** in `p1c_registration/`, next to this packet.

---

## 0. Authorization (`[x]` = authorized)

Anything not ticked is **not** authorized. Stop and ask.

- [ ] **R1 Deposit.** Create and publish one new Zenodo record, a new concept, not a version of any existing record:
  - **Title:** "Pre-registration: confirmatory replication in northeast Washington — do wildfires stay smaller inside small compartments of mapped barriers? (P1C v1.0)"
  - **Resource type:** Publication / Preprint is acceptable; "Other" is acceptable if Preprint is refused.
  - **Creators:** Justin D. Hart (ORCID 0009-0008-3082-2482), Viridis LLC. No AI tool as creator or contributor.
  - **License:** CC-BY-4.0.
  - **Description:** the first section of `REGISTRATION_README.md`, plus this AI-use sentence: "Claude (Anthropic) designed the analysis, wrote the code and ran it under the author's direction; automated tools are not research authors."
  - **Related identifier:** `isSupplementTo` the Trees Cannot Cut concept DOI 10.5281/zenodo.21686446.
  - **Files:** upload exactly the files in `p1c_registration/` and nothing else.

## 1. Invariants

- **Z-1:** the deposited `PREREGISTRATION_P1C_NEWA_v1.0.md` has sha256 `6ece3e36c354a59de8d5dc9620d7deddb52ffbfe90ba97931406976c7f94ade4`.
- **Z-2:** the deposited `FREEZE.json` has sha256 `eef249f92a3be238ccdb50c4f89c99f5e9cdcd8dcf890bc6038e5b7eb940d120`.
- **Z-3:** no other record is created or modified. The token never appears in any output.

## 2. Acceptance

- An anonymous API read of the new record shows Justin as sole creator and CC-BY-4.0.
- The record's files listing gives md5 checksums equal to the local files:
  - prereg md5 `300500da7cbc71808ee2d1c91ef297bb`;
  - FREEZE md5 `20f2ca0b820d90a6a0fd59ca4acdd9e3`.
- Reply to Justin with the DOI. Claude then runs `python3 verify_registration.py zenodo <record id>`, which writes `REGISTRATION.json` only if both files match.
