# Pre-registration: confirmatory replication in northeast Washington — do real fires stay smaller inside small compartments?

**Project:** P1C, the confirmatory replication of P1 ("Trees Cannot Cut on real fires").
**Version:** 1.0.
**Author:** Justin D. Hart (Viridis LLC). Analysis designed and run by Claude (Anthropic) under the author's direction.

**Status at freeze:** no fire size or size class for any ignition in this region has been requested or stored.
- The plan, code and blind predictor table are hash-frozen in `FREEZE.json`. `FREEZE.json` is timestamped on the Bitcoin blockchain with OpenTimestamps.
- `fetch_outcomes.py` refuses to request outcomes unless:
  - **G1:** every frozen file is unchanged;
  - **G2:** a public registration of this file and `FREEZE.json` exists, either a Zenodo/OSF DOI or a commit in a public GitHub repository, and its copies match byte-for-byte;
  - **G3:** the sample shares no ignition with the pilot.

## 1. What is being replicated

The pilot covered Okanogan, Methow and Chelan, Washington, using FPA FOD 1992–2024. Its plan was frozen at 20:13 ET on 2026-10-20, before any fire size was fetched. The decisive pre-registered test was H2: compartment size predicts final fire size beyond barrier density and road distance.

| Pilot definition | β, log₁₀ size per log₁₀ compartment area (95% CI) | n | Verdict |
|---|---|---|---|
| B, mapped barriers | **0.063 (0.010, 0.117)**; cluster bootstrap (0.012, 0.120); p = 0.021 | 2,677 | SUPPORTED |
| A50, DNR control-location map (PCL > 0.5) | 0.169 (−0.012, 0.350) | 194 | not supported (underpowered) |

In words: a compartment ten times larger went with fires about 16% larger.

**A post-hoc check on the pilot.** This is exploratory, run while writing this plan. With standard errors clustered both by year and by 20 km spatial block (S9 below), the pilot's B estimate keeps its sign and significance: 0.063 (0.017, 0.109), with 33 year clusters and 41 block clusters. Repeated ignitions in the same landscape do not explain it away.

**What was known when this plan was written.** The pilot's outcomes were known, and they fix the hypothesis, the barrier definition and the decision rule. No outcome from this region is known.

## 2. The single confirmatory test

**H2, definition B, model M2:** β(log₁₀ A_enc) > 0.

**Decision rule.** The CI is CR1 cluster-robust by year, Wald, β ± 1.96 SE, exactly as in the pilot.
- **SUPPORTED** if the 95% CI lies entirely above 0.
- **CONTRADICTED** if it lies entirely below 0.
- **NOT SUPPORTED** otherwise.

This is one test, so there is no multiplicity adjustment. Everything else in this plan is secondary.

**Pre-specified reading.** These readings never change the decision.

| Reading | Condition |
|---|---|
| **REPLICATED** | SUPPORTED |
| **NOT REPLICATED** | NOT SUPPORTED, and the upper 90% bound is below β₃₃ = 0.0415 |
| **INCONCLUSIVE** | NOT SUPPORTED, otherwise |
| **CONTRADICTED** | CONTRADICTED |

β₃₃ is the effect the pilot had 33% power to detect: the small-telescopes benchmark (Simonsohn 2015, *Psychological Science* 26:559–569). An upper 90% bound below it means the effect, if there is one, is too small for the pilot to have had even a one-in-three chance of detecting it.

**Also reported, descriptive:**
- the difference from the pilot estimate (z test);
- the inverse-variance pooled estimate of pilot and replication.

## 3. Region, data and sample

**Region**
- **Analysis box:** lon −119.4 to −117.0, lat 47.75 to 49.0. It covers eastern Okanogan, Ferry, Stevens and Pend Oreille counties, the northern edges of Lincoln and Spokane counties, and a strip about 3 km wide of the Idaho panhandle at the east edge.
- **Compute box:** the analysis box plus 15 km, {{W}} × {{H}} cells at 30 m in EPSG:5070 (`p1_config.json`).
- **Why this region:** it adjoins the pilot to the east and has similar fuels and fire regimes. It was fixed before any data from it were fetched. It was also expected to be covered by the DNR PCL raster, but §5 shows large gaps.

**Data.** The sources are identical to the pilot:
- **Ignitions:** FPA FOD 7th edition (FPA_FOD_20260615; 1992–2024), USFS EDW `EDW_FireOccurrenceCurrentEdition_01`, layer 0. Only allow-listed fields are used: id, year, discovery date and day, cause, location, owner and agency.
- **Roads:** TIGER, vehicle MTFCC classes only.
- **Water:** NHD large-scale Area (FTYPE 460, 431) and Waterbody (390, 436, 378). The waterbodies were requested by FTYPE because the USGS server timed out on the full layer. The features used are the same.
- **Fuels:** LANDFIRE LF2024 FBFM40; non-burnable 91, 92, 93, 98, 99.
- **Control locations:** Washington DNR PCL raster.
- **Burn scars:** MTBS perimeters, for B+ only.
- **Weather:** gridMET ERC-G as a per-cell percentile over 1992–2024.

**Sample.** All FPA FOD records whose point lies in the analysis box: {{N_RAW}} records. Any record that is also in the pilot table is removed by fod_id. {{EXCL_SENTENCE}} That leaves {{N_TABLE}} ignitions:

| Cause | Ignitions |
|---|---|
| Natural | {{N_NAT}} |
| Human | {{N_HUM}} |
| Missing | {{N_MISS}} |

ERC is available for {{ERC_AVAIL}} of them.

**Blindness, checked before the freeze** (`check_predictors.py`, all PASS):
- **P1:** no outcome field in the predictor table or the raw ignition records.
- **P2:** diagonal lines split 4-connected fuel.
- **P3:** edge-touching compartments are censored.
- **P4:** every layer is on the compute grid.
- **P5:** no pilot ignition is present, and the exclusion list is the frozen pilot table (sha256 `57118595…`).
- **P6:** the table equals the raw in-box records minus the pilot records.

**Known limits of blindness, disclosed:**
- **MTBS perimeters.** These perimeters of large fires are on disk because B+ uses them as barriers for later years. They were requested as geometry only, keeping just the year, so no size attribute was ever received. They were used only as barriers: never linked to ignition records, and nothing about them was looked at beyond the count per year.
- **The PCL raster.** It is a model product that may have been trained on fire perimeters that include this region. That is one reason A50 and A25 are secondary here. The other is power.

## 4. Models and code, unchanged from the pilot

**Outcome:** Y = log₁₀(fire_size, acres).

**Models:**
- **M1:** Y ~ log₁₀ A_enc + ERC_pct + fuel group + cause + month + year (fixed effects).
- **M2:** M1 + log₁₀(ρ + 0.001) + log₁₀(road distance + 30 m).

**Estimation.** OLS with CR1 standard errors clustered by year. A 2,000-replicate cluster bootstrap by year is reported as a check.

**Sample rules.** Records need fire_size > 0, ERC and month. Ignitions on holdable cells and censored compartments are excluded, per definition.

**Definitions:**
- **B (primary):** roads, water and non-burnable ground.
- **A50:** PCL > 0.5. **A25:** PCL > 0.25.
- **B+:** B plus MTBS scars from the 10 prior years.

All are exactly as in the pilot.

**Code identity, verified before the freeze:**
- **`build_predictors.py`:** rebuilt the frozen pilot predictor table byte-for-byte (sha256 `57118595…`; `EQUIVALENCE.json`). The confirmatory changes leave every predictor unchanged:
  - the pilot exclusion;
  - int32 summed-area tables;
  - packed burn-scar masks;
  - the B+ mask computed once per year.
- **`run_test.py`:** run on the pilot data, it reproduces every pilot CR1 estimate, standard error and CI exactly (maximum absolute difference 0). Its changes from the pilot code:
  1. B is the only primary definition;
  2. a disjointness assertion;
  3. the interpretive outputs in §2;
  4. the S9 two-way-clustered secondary analysis;
  5. the pilot's Deviation 1 not-estimable guard is built in.
- **`fetch_outcomes.py`:** adds guards G2 and G3.

**Synthetic validation,** in a scratch directory with no real outcome present (`SYNTHETIC_VALIDATION.json`):
- **Planted effect:** β = 0.30 on B was recovered as {{SYN_PLANT}} and called {{SYN_PLANT_DEC}}.
- **One null draw** (seed 202, the pilot-style check) was recovered as {{SYN_NULL}} and called {{SYN_NULL_DEC}}.
- **Null calibration.** One draw cannot measure an error rate, so before the freeze the check was extended to a 1,000-replicate null calibration of the decision rule on this design. Of the replicates, {{CAL_SUP}} were called SUPPORTED and {{CAL_CON}} CONTRADICTED: a false-positive rate of {{CAL_FPR}} against the nominal 5%, inside the 99% binomial band of 3.2–6.8% fixed before the calibration ran. The rule is calibrated, and the single draw is a tail event of the kind that happens about {{CAL_CON}} of the time. The first run's record is kept as `SYNTHETIC_VALIDATION_run1_single_null_draw.json`.

## 5. Blind sample sizes and power

| Definition | Usable ignitions | Compartment area, log₁₀ acres (10th / 50th / 90th percentile) |
|---|---|---|
{{USABLE_ROWS}}

"Usable" counts records that pass every predictor-based rule. The one outcome-based rule, fire_size > 0, removed no record in the pilot.

The DNR PCL raster has no-data gaps across much of this region, so almost every A50 and A25 compartment touches no-data and is censored. Those two definitions are reported, but they carry little information here. Definition B does not depend on PCL.

**Power for the primary test (B, M2)**

The power is computed from three things:
- the pilot's residual SD (1.080) and design effect (CR1 over iid SE: 1.064);
- this region's blind design: n = {{N_B}}, and the residual SD of log₁₀ A_enc given the other M2 terms, {{SDRES}} (pilot: 0.813);
- a 400-replicate Monte Carlo on this region's design, which checks the analytic standard error: mean CR1 SE {{MC_SE}} against analytic iid SE {{AN_SE}}; rejection rate {{MC_REJ}} at β = 0.063.

| Scenario | Predicted SE | Power at β = 0.063 (pilot) | Power at β = 0.0415 (β₃₃) | Power at β = 0.032 (half the pilot) |
|---|---|---|---|---|
{{POWER_ROWS}}

Two assumptions are flagged:
- **Residual SD:** this region's residual SD is assumed similar to the pilot's. The pessimistic row allows 15% more noise and a 1.5 design effect.
- **The pilot estimate is probably inflated.** It cleared p < 0.05 in a pilot, so the winner's curse applies. The β₃₃ and half-pilot columns are the honest planning numbers.

## 6. Secondary analyses (identical to the pilot; reported in full, not confirmatory)

- **H1:** M1 for B and A50.
- **A50 under M2**, with the bootstrap.
- **A25** under M1 and M2.
- **H3:** M2 on fires of at least 10 acres, for A50 and B.
- **H4:** containment permutation (10,000 permutations within year × fuel-group strata) for A50 and B.
- **Sensitivity, for A50 and B:**
  - S1: snap on-holdable ignitions;
  - S2: include censored compartments;
  - S3: drop coarse coordinates;
  - S6a: lightning only;
  - S6b: human only;
  - S8: 2010 and later.
- **S5:** B+.
- **S9 (new; added before the freeze):** the M2 estimate for B and for A50, with standard errors two-way clustered by year and by 20 km spatial block (Cameron, Gelbach & Miller 2011). If the primary CI excludes 0 but S9's does not, the report will say the result is sensitive to spatial clustering.

## 7. Known threats

**Same as the pilot:**
- **Suppression access:** handled by road distance, density and the lightning-only analysis.
- **Anachronism:** 2024 maps applied to 1992–2024 fires (see S8).
- **Location precision:** see S3.
- **Clustering:** by year in the primary test, as in the pilot. S9 adds 20 km spatial blocks.

**New here:**
- **Landscape overlap with the pilot.** {{N_SHARED}} of {{N_B}} usable B ignitions sit in a compartment that also contains a pilot ignition. The samples are disjoint by ignition, but not entirely by landscape.
- **More wildland–urban interface near Spokane.** There are more human ignitions near dense roads. M2's road and density controls apply, and S6 splits by cause.
- **Different reporting agencies,** for example tribal and BIA records. Agency is not in the model, as in the pilot.

## 8. Freeze, timestamp and registration

**Frozen files:** everything listed in `FREEZE.json`:
- this file;
- the analysis and fetch code: `run_test.py`, `fetch_outcomes.py`, `fetch_data.py`;
- the build and check code: `build_predictors.py`, `check_predictors.py`;
- the design, validation, equivalence, fill, registration and freeze scripts;
- the blind predictor table and `p1_config.json`;
- the records: `EQUIVALENCE.json`, `BLIND_DESIGN.json`, `SYNTHETIC_VALIDATION.json` (and the run-1 record), `CHECKS.txt`;
- the pilot exclusion table.

Their SHA-256 hashes are in `FREEZE.json`, which is timestamped with OpenTimestamps (`FREEZE.json.ots`).

**Public registration.**
- **This folder:** published under the author's account in a public GitHub repository, or deposited on Zenodo.
- **`verify_registration.py`:** downloads the public copies anonymously and writes `REGISTRATION.json` only if they match.
- **`fetch_outcomes.py`:** checks `REGISTRATION.json` before any outcome is requested.

## 9. Deviations

Any change after the freeze is reported as a numbered deviation, with its date and reason.
