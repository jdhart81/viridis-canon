# P1C: pre-registration of a confirmatory wildfire test (northeast Washington)

This folder is the **public registration** of a confirmatory test. Everything here was frozen before any fire-size outcome for the region was requested.

## What is tested

**The claim.** Wildfires that start inside smaller compartments of mapped barriers end smaller. The barriers are vehicle roads, open water and non-burnable ground. The effect holds beyond barrier density and distance to the nearest road. The claim comes from *Trees Cannot Cut*: compartments come only from closed loops of holdable features.

**The pilot,** in Okanogan, Methow and Chelan, WA, pre-registered and frozen 2026-10-20 20:13 ET:
- β = 0.063 (95% CI 0.010–0.117), n = 2,677;
- about 16% larger fires per tenfold larger compartment.

**This test.** One confirmatory test in a new, adjacent region:
- **H2, definition B, model M2:** SUPPORTED if the year-clustered 95% CI for β lies entirely above 0.
- **The plan:** `PREREGISTRATION_P1C_NEWA_v1.0.md`.

## How to check the freeze

1. **Hashes.** `FREEZE.json` lists the SHA-256 of every frozen file. Check each with `sha256sum`.
2. **The blind predictor table** is shipped gzipped. Run `gunzip -k predictors_blind.csv.gz` to recover the frozen `predictors_blind.csv`; its hash is in `FREEZE.json`.
3. **The timestamp.** `FREEZE.json.ots` is an OpenTimestamps proof that `FREEZE.json` existed at the time it was stamped. Run `ots upgrade FREEZE.json.ots`, then `ots verify FREEZE.json.ots`. Bitcoin confirmation takes a few hours after stamping.
4. **The outcome guard.** `fetch_outcomes.py` requests outcomes only if three conditions hold:
   - the frozen files are unchanged;
   - this public copy matches them byte-for-byte (`verify_registration.py`);
   - the sample shares no ignition with the pilot.

**The pilot exclusion table** is the frozen pilot predictor table, which contains no outcomes. It is shipped as `pilot_predictors_blind.csv.gz`. The scripts expect it at `../p1/predictors_blind.csv`. To put it there:

```
mkdir -p ../p1
gunzip -c pilot_predictors_blind.csv.gz > ../p1/predictors_blind.csv
```

Results will be added later in a separate file. The files above will not change; any change after the freeze is reported as a numbered deviation.

## Authorship and AI use

**Author:** Justin D. Hart (Viridis LLC).

**AI use:** Claude (Anthropic) designed the analysis, wrote the code and ran it under the author's direction. Automated tools are not research authors; see `AI_USE_AND_AUTHORSHIP.md` at the repository root.
