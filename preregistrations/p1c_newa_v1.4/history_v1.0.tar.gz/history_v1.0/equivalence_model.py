#!/usr/bin/env python3
"""Model-code equivalence: the confirmatory run_test.py, applied to the PILOT data, must reproduce every pilot
CR1 estimate, standard error and CI in p1/results.json exactly. Appends the result to EQUIVALENCE.json.
(Pilot outcomes are already known; no confirmatory outcome is read.)"""
import hashlib, importlib.util, json, time
import pandas as pd

spec = importlib.util.spec_from_file_location('rtc', 'run_test.py'); rtc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rtc)
R = json.load(open('../p1/results.json'))
df = pd.read_csv('../p1/predictors_blind.csv').merge(pd.read_csv('../p1/outcomes.csv')[['fod_id', 'fire_size']],
                                                      on='fod_id', how='left')
cases = [(r, None) for r in R['primary']] + [(r, 10) for r in R['H3_escaped']]
maxdiff, n = 0.0, 0
for old, ms in cases:
    new = rtc.fit(df, old['defn'], old['model'], min_size=ms)
    if old.get('beta') is None:
        assert new.get('not_estimable'); n += 1; continue
    assert old['n'] == new['n']
    maxdiff = max([maxdiff, abs(old['beta'] - new['beta']), abs(old['se'] - new['se'])] +
                  [abs(a - b) for a, b in zip(old['ci95'], new['ci95'])])
    n += 1
E = json.load(open('EQUIVALENCE.json'))
E['model_code'] = dict(test='confirmatory run_test.fit on the pilot data vs pilot results.json (primary and H3 models)',
                       run_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                       run_test_sha256=hashlib.sha256(open('run_test.py', 'rb').read()).hexdigest(),
                       models_compared=n, max_abs_difference=maxdiff, identical=(maxdiff == 0.0))
json.dump(E, open('EQUIVALENCE.json', 'w'), indent=1)
print(json.dumps(E['model_code'], indent=1))
assert maxdiff == 0.0
