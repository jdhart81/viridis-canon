#!/usr/bin/env python3
"""P1 confirmatory replication (NE Washington): fetch outcomes ONLY after the freeze AND the public registration.

Every guard must pass before any outcome is requested; otherwise the script exits having fetched nothing.
  G1  FREEZE.json exists and every frozen file still has its frozen SHA-256 (nothing edited after the freeze).
  G2  REGISTRATION.json exists and names a public record: a Zenodo or OSF DOI (10.5281/zenodo.N,
      10.17605/OSF.IO/X), or a commit (40-hex SHA) in a public GitHub repository. The SHA-256 and MD5 it records
      for the registered pre-registration and FREEZE.json must equal the local frozen files, so the public record
      is the frozen plan and not a later edit. verify_registration.py writes REGISTRATION.json only after
      downloading the public copies anonymously and hashing them.
  G3  No ignition in the confirmatory table appears in the pilot table.
Usage: python3 fetch_outcomes.py            (runs the guards, then fetches)
       python3 fetch_outcomes.py --check    (runs the guards only; fetches nothing)
"""
import csv, hashlib, json, os, re, sys, urllib.parse, urllib.request

PREREG = 'PREREGISTRATION_P1C_NEWA_v1.0.md'


def sha256(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def guards():
    # G1
    if not os.path.exists('FREEZE.json'):
        sys.exit('G1 FAIL: FREEZE.json missing; the plan is not frozen')
    frozen = json.load(open('FREEZE.json'))
    for path, h in frozen['sha256'].items():
        if sha256(path) != h:
            sys.exit(f'G1 FAIL: {path} changed after the freeze')
    # G2
    if not os.path.exists('REGISTRATION.json'):
        sys.exit('G2 FAIL: REGISTRATION.json missing; the plan is not yet publicly registered')
    reg = json.load(open('REGISTRATION.json'))
    doi = reg.get('doi') or ''
    gh = reg.get('github') or {}
    is_doi = bool(re.fullmatch(r'10\.5281/zenodo\.\d+|10\.17605/OSF\.IO/[A-Z0-9]+', doi))
    is_gh = bool(re.fullmatch(r'[A-Za-z0-9-]+/[A-Za-z0-9._-]+', gh.get('repo', '')) and
                 re.fullmatch(r'[0-9a-f]{40}', gh.get('commit', '')) and gh.get('public') is True)
    if not (is_doi or is_gh):
        sys.exit('G2 FAIL: REGISTRATION.json names neither a Zenodo/OSF DOI nor a public GitHub commit')
    for f in (PREREG, 'FREEZE.json'):
        dep = reg.get('registered_files', {}).get(f, {})
        if dep.get('sha256') != sha256(f):
            sys.exit(f'G2 FAIL: the registered {f} is not the local frozen file (SHA-256 differs)')
        if dep.get('md5') != hashlib.md5(open(f, 'rb').read()).hexdigest():
            sys.exit(f'G2 FAIL: the MD5 recorded from the public record for {f} does not match')
    # G3
    pilot = {int(float(r['fod_id'])) for r in csv.DictReader(open(json.load(open('p1_config.json'))['exclude_fod_ids_from']))}
    mine = [int(float(r['fod_id'])) for r in csv.DictReader(open('predictors_blind.csv'))]
    if pilot & set(mine):
        sys.exit('G3 FAIL: pilot ignitions present in the confirmatory table')
    where = f'doi:{doi}' if is_doi else f"github.com/{gh['repo']}@{gh['commit'][:12]}"
    print(f'guards passed: frozen files intact; publicly registered at {where}; samples disjoint')
    return mine


def fetch(ids):
    url = 'https://apps.fs.usda.gov/arcx/rest/services/EDW/EDW_FireOccurrenceCurrentEdition_01/MapServer/0/query'
    rows = []
    for i in range(0, len(ids), 200):
        chunk = ids[i:i + 200]
        q = dict(where='fod_id IN (' + ','.join(str(x) for x in chunk) + ')',
                 outFields='fod_id,fire_size,fire_size_class', returnGeometry='false', f='json')
        for attempt in range(4):
            try:
                r = json.loads(urllib.request.urlopen(url, data=urllib.parse.urlencode(q).encode(), timeout=180).read())
                break
            except Exception:
                if attempt == 3:
                    raise
        rows += [f['attributes'] for f in r['features']]
    with open('outcomes.csv', 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=['fod_id', 'fire_size', 'fire_size_class']); w.writeheader(); w.writerows(rows)
    print('outcomes fetched:', len(rows), 'of', len(ids))


if __name__ == '__main__':
    ids = guards()
    if '--check' not in sys.argv:
        fetch(ids)
