#!/usr/bin/env python3
"""Fill PREREG_TEMPLATE.md with blind numbers computed from files (no hand transcription) and write
PREREGISTRATION_P1C_NEWA_v1.0.md. Reads only predictor-side files."""
import json, re
import pandas as pd

cfg = json.load(open('p1_config.json'))
D = json.load(open('BLIND_DESIGN.json'))
S = json.load(open('SYNTHETIC_VALIDATION.json'))
raw = json.load(open('raw/fpafod_ignitions_blind.json'))
pilot = set(pd.read_csv(cfg['exclude_fod_ids_from'], usecols=['fod_id'])['fod_id'].astype('int64'))
AX0, AY0, AX1, AY1 = cfg['analysis_box_5070']
inbox = [f for f in raw if (f.get('geometry') or {}).get('x') is not None
         and AX0 <= f['geometry']['x'] <= AX1 and AY0 <= f['geometry']['y'] <= AY1]
excl = [f for f in inbox if int(float(f['attributes']['fod_id'])) in pilot]
on_meridian = sum(abs(float(f['attributes']['longitude']) - (-119.4)) < 1e-9 for f in excl)
assert D['n_table'] == len(inbox) - len(excl), (D['n_table'], len(inbox), len(excl))
if not excl:
    excl_sentence = ('No record needed removing: the two boxes meet only along the meridian at −119.4, and no '
                     'record lies on it in both. The check runs anyway, in the build and in every guard.')
else:
    excl_sentence = (f'{len(excl):,} records were removed, ' + ('all' if on_meridian == len(excl) else f'{on_meridian:,} of them')
                     + ' with longitude exactly −119.4, the shared boundary.')
cause = D['cause']
fmt = lambda v: f'{v:,}'
P = D['power_primary']
usable_rows = '\n'.join(
    f"| {name} | {fmt(D['usable'][k]['n'])} | " + ' / '.join(f'{q:.2f}' for q in D['usable'][k]['log10_Aenc_acres_q10_q50_q90']) + ' |'
    for k, name in [('B', 'B, mapped barriers (primary)'), ('A50', 'A50, PCL > 0.5'), ('A25', 'A25, PCL > 0.25'), ('Bp', 'B+, B plus prior scars')])
power_rows = '\n'.join(
    f"| {name} | {v['predicted_se']:.4f} | " + ' | '.join(f"{p:.2f}" for p in v['power'].values()) + ' |'
    for name, v in P['scenarios'].items())
mc = P['monte_carlo_iid']
fill = {
    'W': fmt(cfg['W']), 'H': fmt(cfg['H']), 'N_RAW': fmt(len(inbox)),
    'N_TABLE': fmt(D['n_table']), 'EXCL_SENTENCE': excl_sentence, 'N_NAT': fmt(cause.get('Natural', 0)), 'N_HUM': fmt(cause.get('Human', 0)),
    'N_MISS': fmt(sum(v for k, v in cause.items() if k not in ('Natural', 'Human'))),
    'ERC_AVAIL': f"{D['erc_available']:.1%}",
    'SYN_PLANT': f"{S['planted']['beta']:.3f} (95% CI {S['planted']['ci95'][0]:.3f}–{S['planted']['ci95'][1]:.3f})",
    'SYN_PLANT_DEC': S['planted']['decision'],
    'SYN_NULL': f"{S['null']['beta']:.3f} (95% CI {S['null']['ci95'][0]:.3f} to {S['null']['ci95'][1]:.3f})",
    'SYN_NULL_DEC': S['null']['decision'],
    'CAL_SUP': f"{S['null_calibration']['supported_rate']:.1%}", 'CAL_CON': f"{S['null_calibration']['contradicted_rate']:.1%}",
    'CAL_FPR': f"{S['null_calibration']['false_positive_rate']:.1%}",
    'USABLE_ROWS': usable_rows, 'N_B': fmt(P['n_usable_B']), 'SDRES': f"{P['sd_resid_log10Aenc']:.3f}",
    'MC_SE': f"{mc['mean_cr1_se']:.4f}", 'AN_SE': f"{mc['analytic_iid_se']:.4f}", 'MC_REJ': f"{mc['rejection_rate']:.2f}",
    'POWER_ROWS': power_rows,
    'N_SHARED': fmt(D['landscape_overlap']['usable_B_ignitions_sharing_a_compartment_with_a_pilot_ignition']),
}
t = open('PREREG_TEMPLATE.md').read()
for k, v in fill.items():
    t = t.replace('{{' + k + '}}', re.sub(r'(?<![\w.])-(?=\d)', '\u2212', v))   # typographic minus for negatives
left = re.findall(r'\{\{[A-Z_]+\}\}', t)
assert not left, left
open('PREREGISTRATION_P1C_NEWA_v1.0.md', 'w').write(t)
print('written; excluded:', len(excl), '| on meridian:', on_meridian)
