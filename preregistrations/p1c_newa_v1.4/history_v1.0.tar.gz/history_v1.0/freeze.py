#!/usr/bin/env python3
"""Freeze the confirmatory plan: hash every frozen file into FREEZE.json, refusing if any outcome exists.

Invariants checked here (the run stops on any failure):
  F1 no outcomes.csv and no results.json exist in this folder (nothing has been fetched or run);
  F2 the raw ignition records carry only the allow-listed fields (no outcome field was ever returned);
  F3 every frozen file exists; F4 the pre-registration has no unfilled {{placeholder}};
  F5 EQUIVALENCE.json was produced by the build_predictors.py and run_test.py being frozen.
Then OpenTimestamps-stamp FREEZE.json (python3 freeze.py --stamp).
"""
import hashlib, json, os, re, subprocess, sys, time

FROZEN = ['PREREGISTRATION_P1C_NEWA_v1.0.md', 'run_test.py', 'predictors_blind.csv', 'fetch_outcomes.py',
          'build_predictors.py', 'fetch_data.py', 'check_predictors.py', 'blind_design.py', 'validate_synthetic.py',
          'verify_registration.py', 'p1_config.json', 'EQUIVALENCE.json', 'BLIND_DESIGN.json',
          'SYNTHETIC_VALIDATION.json', 'SYNTHETIC_VALIDATION_run1_single_null_draw.json', 'CHECKS.txt', 'equivalence_model.py', 'fill_prereg.py', 'freeze.py', '../p1/predictors_blind.csv']


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def main():
    assert not os.path.exists('outcomes.csv') and not os.path.exists('results.json'), 'F1: outcome or results present'
    allow = {'objectid', 'fod_id', 'fire_year', 'discovery_date', 'discovery_doy', 'nwcg_cause_classification',
             'nwcg_general_cause', 'latitude', 'longitude', 'owner_descr', 'state', 'nwcg_reporting_agency'}
    keys = {k.lower() for f in json.load(open('raw/fpafod_ignitions_blind.json')) for k in f['attributes']}
    assert keys <= allow, f'F2: non-allow-listed fields in raw ignitions: {keys - allow}'
    missing = [f for f in FROZEN if not os.path.exists(f)]
    assert not missing, f'F3: missing {missing}'
    assert not re.search(r'\{\{[A-Z_]+\}\}', open(FROZEN[0]).read()), 'F4: unfilled placeholder in the prereg'
    E = json.load(open('EQUIVALENCE.json'))
    assert E['build_predictors_sha256'] == sha('build_predictors.py') and E['identical'], 'F5: build equivalence stale'
    assert E['model_code']['run_test_sha256'] == sha('run_test.py') and E['model_code']['identical'], 'F5: model equivalence stale'
    t = time.time()
    rec = dict(frozen_at_local=time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(t)),
               frozen_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t)),
               note=('Frozen before any FPA FOD outcome field (fire_size etc.) for this region was requested. '
                     'fetch_outcomes.py verifies these hashes and the public registration before fetching.'),
               sha256={f: sha(f) for f in FROZEN})
    json.dump(rec, open('FREEZE.json', 'w'), indent=1)
    print(json.dumps(rec, indent=1))
    print('FREEZE.json sha256', sha('FREEZE.json'))


def stamp():
    cals = ['https://alice.btc.calendar.opentimestamps.org', 'https://finney.calendar.eternitywall.com',
            'https://bob.btc.calendar.opentimestamps.org', 'https://a.pool.opentimestamps.org']
    cmd = ['ots', 'stamp', '-m', '1'] + sum([['-c', c] for c in cals], []) + ['FREEZE.json']
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    print(r.stdout, r.stderr)
    assert os.path.exists('FREEZE.json.ots'), 'stamp failed'
    print(subprocess.run(['ots', 'info', 'FREEZE.json.ots'], capture_output=True, text=True).stdout[:2000])


if __name__ == '__main__':
    stamp() if '--stamp' in sys.argv else main()
