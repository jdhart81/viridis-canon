#!/usr/bin/env python3
"""Validate the frozen-to-be run_test.py on SYNTHETIC outcomes, in a scratch directory, before the freeze.

Two worlds on this region's real blind predictors, each run end to end through run_test.py:
  planted: log10 size = 0.30 * log10 Aenc_B + 0.5 * erc_pct + N(0, 1.08)  -> must be SUPPORTED
  null:    log10 size =                      0.5 * erc_pct + N(0, 1.08)  -> one fixed draw, reported as is
Version 2 (before the freeze): one null draw cannot measure an error rate (run 1's draw, seed 202, came out
CONTRADICTED; kept in SYNTHETIC_VALIDATION_run1_single_null_draw.json). So the pass criterion now uses a
1,000-replicate null calibration of the registered decision rule on the same design (the primary fit's exact
arithmetic, checked against run_test.fit on the first replicates): the share of replicates called SUPPORTED or
CONTRADICTED must lie in [0.032, 0.068], the 99% binomial band around the nominal 0.05.
No real outcome exists anywhere for this region; the script asserts that before and after.
Usage: python3 validate_synthetic.py <scratch dir>
"""
import json, os, shutil, subprocess, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv')), 'a real outcome file exists; stop'
SC = os.path.abspath(sys.argv[1]); os.makedirs(SC, exist_ok=True)
link = os.path.join(SC, 'p1')
if not os.path.islink(link):
    os.symlink('/home/claude/p1', link)            # so ../p1/predictors_blind.csv resolves for the disjointness check
pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
la = np.log10(pred['Aenc_B'].where(pred['Aenc_B'] > 0, 1000.0)).values
erc = pred['erc_pct'].fillna(0.5).values
out = {}
for world, beta, seed in [('planted', 0.30, 101), ('null', 0.0, 202)]:
    d = os.path.join(SC, world); os.makedirs(d, exist_ok=True)
    shutil.copy(os.path.join(HERE, 'run_test.py'), d)
    dst = os.path.join(d, 'predictors_blind.csv')
    if not os.path.exists(dst):
        os.symlink(os.path.join(HERE, 'predictors_blind.csv'), dst)
    rng = np.random.default_rng(seed)
    y = beta * la + 0.5 * erc + rng.normal(0, 1.08, len(pred))
    pd.DataFrame({'fod_id': pred['fod_id'], 'fire_size': 10 ** y, 'fire_size_class': 'SYN'}).to_csv(os.path.join(d, 'outcomes.csv'), index=False)
    subprocess.run([sys.executable, 'run_test.py'], cwd=d, check=True, capture_output=True)
    R = json.load(open(os.path.join(d, 'results.json')))
    p = R['primary_test']
    out[world] = dict(planted_beta=beta, beta=round(p['beta'], 3), ci95=[round(v, 3) for v in p['ci95']], n=p['n'],
                      decision=R['decision'], reading=R['interpretation']['reading'])
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))

# Null calibration of the registered decision rule (B, M2, CR1 by year, +-1.96 SE) on this design
import importlib.util
spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
base = pred.assign(fire_size=1.0)
s, a = rt.sample(base, 'B')
X = rt.design(s, a, 'rho_B', 'M2'); Xv = X.values.astype(float); n, k = Xv.shape
j = list(X.columns).index('log10_Aenc'); XtX_inv = np.linalg.pinv(Xv.T @ Xv)
g = s['fire_year'].values; G = pd.unique(g); idx = [g == gg for gg in G]
cfac = len(G) / (len(G) - 1) * (n - 1) / (n - k)
pos = pred.index.get_indexer(s.index)
calls = {'SUPPORTED': 0, 'CONTRADICTED': 0, 'NOT SUPPORTED': 0}
REPS = 1000
for r in range(REPS):
    rng = np.random.default_rng(10000 + r)
    yfull = 0.5 * erc + rng.normal(0, 1.08, len(pred))
    y = yfull[pos]
    b = XtX_inv @ Xv.T @ y; e = y - Xv @ b
    meat = np.zeros((k, k))
    for ii in idx:
        sc = Xv[ii].T @ e[ii]; meat += np.outer(sc, sc)
    se = np.sqrt(cfac * (XtX_inv @ meat @ XtX_inv)[j, j])
    lo, hi = b[j] - 1.96 * se, b[j] + 1.96 * se
    if r < 3:   # the fast path must equal run_test.fit exactly
        chk = rt.fit(pred.assign(fire_size=10 ** yfull), 'B', 'M2')
        assert abs(chk['beta'] - b[j]) < 1e-10 and abs(chk['se'] - se) < 1e-10, (chk, b[j], se)
    calls['SUPPORTED' if lo > 0 else ('CONTRADICTED' if hi < 0 else 'NOT SUPPORTED')] += 1
rate = (calls['SUPPORTED'] + calls['CONTRADICTED']) / REPS
out['null_calibration'] = dict(reps=REPS, n=int(n), calls=calls, false_positive_rate=rate,
                               supported_rate=calls['SUPPORTED'] / REPS, contradicted_rate=calls['CONTRADICTED'] / REPS,
                               band99=[0.032, 0.068], seeds='10000..10999')
ok = out['planted']['decision'] == 'SUPPORTED' and 0.032 <= rate <= 0.068
out['pass_criterion'] = 'planted SUPPORTED and null false-positive rate in [0.032, 0.068]; the single null draw is reported, not scored'
out['pass'] = ok
json.dump(out, open(os.path.join(HERE, 'SYNTHETIC_VALIDATION.json'), 'w'), indent=1)
print(json.dumps(out, indent=1))
sys.exit(0 if ok else 1)
