# Codex task: deposit the P1C confirmatory pre-registration on Zenodo

Prepared by Claude for Justin Hart, 2026-10-21 (plan v1.1; v1.0 was never published).

**Scope:** one new Zenodo record holding the frozen confirmatory plan for the P1 wildfire replication in northeast Washington.

**Out of scope:** no other Zenodo, GitHub or website write.

**How to use:** Justin ticks Section 0 and sends this file to Codex.

**Supporting files:** in `p1c_registration_v1.1/`, next to this packet.

---

## 0. Authorization (`[x]` = authorized)

Anything not ticked is **not** authorized. Stop and ask.

- [ ] **R1 Deposit.** Create and publish one new Zenodo record, a new concept, not a version of any existing record:
  - **Title:** "Pre-registration: confirmatory replication in northeast Washington — do wildfires stay smaller inside small compartments of mapped barriers? (P1C v1.1)"
  - **Resource type:** Publication / Preprint is acceptable; "Other" is acceptable if Preprint is refused.
  - **Creators:** Justin D. Hart (ORCID 0009-0008-3082-2482), Viridis LLC. No AI tool as creator or contributor.
  - **License:** CC-BY-4.0.
  - **Description:** the first section of the package's `README.md`, plus this AI-use sentence: "Claude (Anthropic) designed the analysis, wrote the code and ran it under the author's direction; automated tools are not research authors."
  - **Related identifier:** `isSupplementTo` the Trees Cannot Cut concept DOI 10.5281/zenodo.21686446.
  - **Files:** upload exactly the files in `p1c_registration_v1.1/` and nothing else.

## 1. Invariants

- **Z-1:** the deposited `PREREGISTRATION_P1C_NEWA_v1.1.md` has sha256 `9e4ed1426d0643cda120b25a26dc3db50e3b8e6e92b8722b33d133e70a52f199`.
- **Z-2:** the deposited `FREEZE.json` has sha256 `efd026fd3a9d2d25b80ba56573e14d026fb1c0ed804956f0252d799c811f7c70`.
- **Z-3:** no other record is created or modified. The token never appears in any output.

## 2. Acceptance

- An anonymous API read of the new record shows Justin as sole creator and CC-BY-4.0.
- The record's files listing gives md5 checksums equal to the local files:
  - prereg md5 `ccbdf6e8f481541a266a4ac51e98ef66`;
  - FREEZE md5 `7506b5b4361ed5e570789b0366602015`.
- Reply to Justin with the DOI. Claude then runs `python3 verify_registration.py zenodo <record id>`. `fetch_outcomes.py` repeats the anonymous download and comparison itself before requesting any outcome.
