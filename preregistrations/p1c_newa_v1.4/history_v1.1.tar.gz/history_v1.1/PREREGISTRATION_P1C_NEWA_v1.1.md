# Pre-registration: confirmatory replication in northeast Washington — do real fires stay smaller inside small compartments?

**Project:** P1C, the confirmatory replication of P1 ("Trees Cannot Cut on real fires").
**Version:** 1.1. It supersedes v1.0, which was frozen but never published (§0).
**Author:** Justin D. Hart (Viridis LLC). Analysis designed and run by Claude (Anthropic) under the author's direction.

**Status at freeze**
- **Not requested:** no FPA FOD fire size, size class or containment field for any ignition in this region has been requested or stored.
- **Exception, large-fire perimeters (MTBS):** during the pilot, their full attribute records were received for part of this region. Only geometry and year were kept. See "Known limits of blindness" in §3.
- **Frozen:** the plan, code, blind predictor table, raw inputs and fetch logs are hash-frozen in `FREEZE.json`. It has been submitted to OpenTimestamps for Bitcoin timestamping.
- **Guarded:** `fetch_outcomes.py` requests outcomes only if three guards pass, re-run immediately before the request:
  - **G1:** every frozen file is unchanged;
  - **G2:** it downloads the public copy of this file and of `FREEZE.json` anonymously, from GitHub or Zenodo, and they match byte-for-byte;
  - **G3:** the sample shares no ignition with the pilot.

## 0. Version history

**v1.0** was frozen at 2026-10-20 23:58:20 EDT. `FREEZE.json` sha256 is `eef249f92a3be238ccdb50c4f89c99f5e9cdcd8dcf890bc6038e5b7eb940d120`, submitted to OpenTimestamps. It was never published, and it is kept with its timestamp in `history_v1.0/`.

That night, an independent audit was run by an agent that had not built the study. Every mechanical check passed:
- the hashes, blindness of the files, disjointness and completeness;
- reproduction of the pilot code;
- every number in the plan.

**What the audit found:**
- **C1 (critical):** one blindness statement was inaccurate. MTBS attribute records had been received during the pilot for part of this region.
- **M1:** the registration guard trusted a local file.
- **M2:** the comparison with the pilot ignored the 33 years the two studies share.
- **M3:** the fetch evidence was not frozen.
- **M4:** post-fire updates in the 2024 maps were not disclosed.
- **Minor issues** in wording and checks.

**v1.1 fixes all of them.** A new calibration added in response (§2, §4) also showed that the pilot's interval calls a true null effect too often in this design, so v1.1 decides on a stricter interval. The hypothesis, barrier definition, model, sample and estimator are unchanged.

## 1. What is being replicated

**The pilot:**
- **Region and data:** Okanogan, Methow and Chelan, Washington; FPA FOD 1992–2024.
- **Freeze:** the plan was frozen at 20:13 ET on 2026-10-20, before any fire size was fetched.
- **The decisive test, H2:** compartment size predicts final fire size beyond barrier density and road distance.
- **Two co-primary definitions:** a Bonferroni split gives 0.025 each.

| Pilot definition | β, log₁₀ size per log₁₀ compartment area (95% CI) | n | Verdict |
|---|---|---|---|
| B, mapped barriers | **0.063 (0.010, 0.117)**; cluster bootstrap (0.012, 0.120); p = 0.021, below 0.025 | 2,677 | SUPPORTED |
| A50, DNR control-location map (PCL > 0.5) | 0.169 (−0.012, 0.350) | 194 | not supported (underpowered) |

In words: a compartment ten times larger went with fires about 16% larger.

**The pilot under this plan's stricter rule** (§2): the B interval is (0.0075, 0.1188), still SUPPORTED. The two-way clustered SE on the pilot (0.0234) is smaller than its year-only SE (0.0273), so the stricter rule's interval there comes from the year-only SE and the t critical value. This check is recorded as pilot Deviation 2 (`p1/DEVIATION_2.json`).

**What was known when this plan was written.** The pilot's outcomes were known, and they fix the hypothesis, the barrier definition and the model. No outcome from this region is known.

## 2. The single confirmatory test

**H2, definition B, model M2:** β(log₁₀ A_enc) > 0.

**Decision rule.** The interval is β ± t(0.975, G − 1) × max(SE₂, SE_year), where:
- **SE₂** is the CR1 standard error two-way clustered by year and 20 km block (Cameron, Gelbach & Miller 2011);
- **SE_year** is the pilot's year-clustered CR1 standard error;
- **G** is min(year clusters, block clusters). Blindly, G − 1 = 32 and t = 2.037.

The verdicts:
- **SUPPORTED** if the interval lies entirely above 0.
- **CONTRADICTED** if it lies entirely below 0.
- **NOT SUPPORTED** otherwise.
- **NOT ESTIMABLE** if n ≤ k or fewer than 2 year clusters.

This is one test, so there is no multiplicity adjustment. Everything else in this plan is secondary.

**Why the rule is stricter than the pilot's (β ± 1.96 × SE_year).**
- **How the rules were checked:** null outcomes were simulated on this region's blind design, 10,000 per error model (`SYNTHETIC_VALIDATION.json`). The variance shared within 20 km blocks was estimated from the pilot's B/M2 residuals: 0.071 of 1.146, an intraclass correlation of 0.062.
- **The result:** the pilot's rule over-calls, and this rule does not.

| Rule | False calls, iid errors | False calls, block-correlated errors |
|---|---|---|
| Pilot's rule: 1.96 × SE_year | 5.9% | 12.6% |
| 1.96 × max(SE₂, SE_year) | 5.1% | 6.6% |
| **This plan's rule:** t × max(SE₂, SE_year) | **4.3%** | **5.8%** |

The pilot-rule reading is reported alongside the decision for comparability, but it does not decide.

**Pre-specified reading.** These readings never change the decision.

| Reading | Condition |
|---|---|
| **REPLICATED** | SUPPORTED |
| **NOT REPLICATED** | NOT SUPPORTED, and the one-sided 95% upper bound β + t(0.95, G − 1) × max(SE₂, SE_year) is below β₃₃ = 0.0415 |
| **INCONCLUSIVE** | NOT SUPPORTED, otherwise |
| **CONTRADICTED** | CONTRADICTED |

**β₃₃** is the effect the pilot had 33% power to detect with its own rule: the small-telescopes benchmark (Simonsohn 2015, *Psychological Science* 26:559–569). An upper bound below it means the effect, if there is one, is too small for the pilot to have had even a one-in-three chance of detecting it.

**Also reported (descriptive):** the difference from the pilot and the pooled estimate.
- **From a stacked model:** both samples in one block-diagonal regression, clustered across both regions, so the estimate's covariance with the pilot through the 33 shared years is accounted for.
- **Under independence:** for reference.

**Retrieval rules, registered.** Every requested fod_id must come back exactly once. Each record's fire_year, discovery_date, latitude and longitude must equal the frozen blind record. Otherwise outcomes.csv is not written, and the failure is resolved as a numbered deviation before any analysis.

## 3. Region, data and sample

**Region**
- **Analysis box:** lon −119.4 to −117.0, lat 47.75 to 49.0. It covers eastern Okanogan, Ferry, Stevens and Pend Oreille counties, the northern edges of Lincoln and Spokane counties, and a strip about 3 km wide of the Idaho panhandle at the east edge.
- **Compute box:** the analysis box plus 15 km, 7,885 × 6,849 cells at 30 m in EPSG:5070 (`p1_config.json`).
- **Why this region:** it adjoins the pilot to the east and has similar fuels and fire regimes. It was fixed before any data from it were fetched. It was also expected to be covered by the DNR PCL raster, but §5 shows large gaps.

**Data.** The sources are the pilot's.
- **Ignitions:** FPA FOD 7th edition (FPA_FOD_20260615; 1992–2024), USFS EDW `EDW_FireOccurrenceCurrentEdition_01`, layer 0. Only the allow-listed fields are requested: id, year, discovery date and day, cause, location, owner and agency.
- **Roads:** TIGER, vehicle MTFCC classes only.
- **Water:** NHD large-scale Area (FTYPE 460, 431) and Waterbody (390, 436, 378). The waterbodies were requested by FTYPE because the USGS server timed out on the full layer. The features used are the same.
- **Fuels:** LANDFIRE LF2024 FBFM40; non-burnable 91, 92, 93, 98, 99.
- **Control locations:** Washington DNR PCL raster.
- **Burn scars:** MTBS perimeters, geometry only, for B+.
- **Weather:** gridMET ERC-G as a per-cell percentile over 1992–2024.

`FETCH_PROVENANCE.md` records which code version fetched each input.

**Sample.** The sample is every FPA FOD record inside the closed lon/lat box above, judged by its own coordinates: 14,105 records. This filter is now explicit in the build, and it removes no record that the server's envelope query returned. Any record also in the pilot table is removed by fod_id. No record needed removing: the two boxes meet only along the meridian at −119.4, and no record lies on it in both. The check runs anyway, in the build and in every guard. That leaves 14,105 ignitions:

| Cause | Ignitions |
|---|---|
| Natural | 4,779 |
| Human | 9,080 |
| Missing | 246 |

ERC is available for 100.0% of them.

**Blindness, checked before the freeze** (`check_predictors.py`, all PASS):
- **P1:** no outcome field in the predictor table or the raw ignition records.
- **P2:** diagonal lines split 4-connected fuel.
- **P3:** edge-touching compartments are censored.
- **P4:** every layer is on the compute grid.
- **P5:** no pilot ignition is present, and the exclusion list is the frozen pilot table (sha256 `57118595…`).
- **P6:** the table equals the raw records inside the lon/lat box minus the pilot records.

**Known limits of blindness, disclosed:**
- **MTBS during the pilot.** The pilot fetched MTBS perimeters at 19:53 and 20:06, before this region was chosen at about 20:33. It requested all attributes, which include burned acreage, over the pilot's compute box. 63 of those perimeters (61 from 1992–2024) reach into this region, and 1,697 of this region's ignitions lie inside the pilot's compute box. The pilot code kept only geometry and year, and no attribute value was stored, printed or looked at. This region's own MTBS fetch requested geometry only. S10 drops those 1,697 ignitions.
- **MTBS geometry.** The perimeter polygons on disk encode the burned area of every large fire (≥ 1,000 acres). They were used only as barriers in B+: never linked to ignitions or measured, and only their count per year was looked at.
- **The PCL raster.** It is a model product that may have been trained on fire perimeters that include this region. That is one reason A50 and A25 are secondary here. The other is power.
- **Post-fire map updates.** The maps are from 2024 and are applied to 1992–2024 fires.
  - **Fuels:** LANDFIRE updates fuels after disturbances, so for recent large fires the fuel group at the ignition cell partly reflects that fire's own aftermath. S11 drops the fuel-group term.
  - **Roads:** roads built after a fire, such as salvage roads, would make compartments around large past fires smaller. That works against the hypothesis.

## 4. Models and code, unchanged from the pilot

**Outcome:** Y = log₁₀(fire_size, acres).

**Models:**
- **M1:** Y ~ log₁₀ A_enc + ERC_pct + fuel group + cause + month + year (fixed effects).
- **M2:** M1 + log₁₀(ρ + 0.001) + log₁₀(road distance + 30 m).

**Estimation.** OLS. The decision interval is defined in §2. The pilot's year-clustered CR1 interval and a 2,000-replicate cluster bootstrap by year are reported alongside.

**Sample rules.** Records need fire_size > 0, ERC and month. Ignitions on holdable cells and censored compartments are excluded, per definition.

**Definitions:**
- **B (primary):** roads, water and non-burnable ground.
- **A50:** PCL > 0.5. **A25:** PCL > 0.25.
- **B+:** B plus MTBS scars from the 10 prior years.

All are exactly as in the pilot.

**Code identity, verified before the freeze** (`equivalence.py` → `EQUIVALENCE.json`):
- **`build_predictors.py`:** rebuilt the frozen pilot predictor table byte-for-byte (sha256 `57118595…`). Its changes leave every predictor unchanged:
  - the pilot exclusion;
  - the explicit lon/lat filter;
  - int32 summed-area tables;
  - packed burn-scar masks;
  - the B+ mask computed once per year.
- **`run_test.py`:** replaying the pilot's call sequence with it reproduces all 233 numbers in the pilot's 23 reported outputs exactly. That covers the estimates, SEs, CIs, bootstrap intervals, H3, H4 and every sensitivity analysis. The changes from the pilot code are listed in its header:
  - the single primary and its interval;
  - the disjointness assertion;
  - the interpretive outputs;
  - the built-in Deviation 1 guard;
  - S9–S11;
  - the stacked model;
  - leave-one-year-out.
- **`fetch_outcomes.py`:** its guards and retrieval rules are given in the status section and §2.

**Synthetic validation,** in a scratch directory with no real outcome present (`SYNTHETIC_VALIDATION.json`):
- **Planted effect:** β = 0.30 on B was recovered as 0.290 (interval 0.264–0.317) and called SUPPORTED.
- **One null draw** (seed 202) was recovered as −0.036 (interval −0.068 to −0.003) and called CONTRADICTED. One draw cannot measure an error rate; it is a tail event of a kind the calibration shows happens a few percent of the time.
- **Null calibration:** the table in §2.
- **Pass criterion:** the planted effect is SUPPORTED, and the registered rule's false-call share is at most 0.065 under both error models.
- **How the criterion came about, disclosed:**
  - v1.0 scored the single null draw.
  - After it came out CONTRADICTED, a 1,000-replicate iid calibration of the pilot's rule replaced it, and gave 4.4%.
  - For v1.1, the 0.065 tolerance was set after an exploratory 4,000-replicate run. That run gave 4.7% iid and 5.6% block-correlated for this rule, and 6.7% and 12.0% for the pilot's.
  - The 10,000-replicate figures above are the record.

## 5. Blind sample sizes and power

| Definition | Usable ignitions | Compartment area, log₁₀ acres (10th / 50th / 90th percentile) |
|---|---|---|
| B, mapped barriers (primary) | 11,314 | 2.41 / 3.63 / 4.46 |
| A50, PCL > 0.5 | 102 | −0.33 / 1.51 / 4.94 |
| A25, PCL > 0.25 | 712 | 1.00 / 3.26 / 4.40 |
| B+, B plus prior scars | 11,105 | 2.39 / 3.59 / 4.43 |

"Usable" counts records that pass every predictor-based rule. The one outcome-based rule, fire_size > 0, removed no record in the pilot.

S10 keeps 9,941 usable B ignitions and drops the 1,373 inside the pilot's compute box.

The DNR PCL raster has no-data gaps across much of this region, so almost every A50 and A25 compartment touches no-data and is censored. Those two definitions are reported, but they carry little information here. Definition B does not depend on PCL.

**Power of the registered rule.** This is P(SUPPORTED), simulated on this region's blind design with 4,000 replicates per cell (`BLIND_DESIGN.json`).

| Error model | β = 0.063 (pilot) | β = 0.0415 (β₃₃) | β = 0.032 (half the pilot) |
|---|---|---|---|
| iid | 0.99 | 0.78 | 0.55 |
| block-correlated (pilot variance components) | 0.93 | 0.65 | 0.44 |

**For reference:**
- the analytic iid SE on this design is 0.0143 (n = 11,314);
- the residual SD of log₁₀ A_enc given the other M2 terms is 0.711 (pilot: 0.813).

The pilot estimate cleared p < 0.05, so the winner's curse applies, and its value is probably inflated. The β₃₃ and half-pilot columns are the honest planning numbers.

## 6. Secondary analyses (reported in full, not confirmatory)

**As in the pilot:**
- **H1:** M1 for B and A50.
- **A50 under M2**, with the bootstrap.
- **A25** under M1 and M2.
- **H3:** M2 on fires of at least 10 acres, for A50 and B.
- **H4:** among fires of at least 10 acres, the share with final size ≤ A_enc, against 10,000 permutations within year × fuel-group strata, for A50 and B.
- **Sensitivity, for A50 and B:**
  - S1: snap on-holdable ignitions;
  - S2: include censored compartments;
  - S3: drop coarse coordinates;
  - S6a: lightning, meaning NWCG cause "Natural";
  - S6b: human;
  - S8: 2010 and later.
- **S5:** B+.

**New in the confirmatory plan:**
- **S9:** the two-way clustered interval for A50. For B it is part of the decision.
- **S10:** B without the 1,697 ignitions inside the pilot's compute box (§3).
- **S11:** B without the fuel-group term (§3).
- **Leave-one-year-out:** the primary estimate and decision with each year removed in turn. Any year whose removal changes the decision will be named.
- **Stacked model** with the pilot (§2).

## 7. Known threats

**Same as the pilot:**
- **Suppression access:** handled by road distance, density and the lightning-only analysis.
- **Anachronism and post-fire map updates:** see §3, S8 and S11.
- **Location precision:** see S3.

**New here:**
- **Spatial correlation.** Residuals share variance within 20 km blocks across years. The decision interval accounts for it (§2).
- **The 33 shared years.** Adjacent regions share fire seasons, so year-specific effects can move both estimates together. The stacked model estimates that covariance for the comparison with the pilot. The replication's own test does not depend on it.
- **Landscape overlap with the pilot.** 208 of 11,314 usable B ignitions sit in a compartment that also contains a pilot ignition. The samples are disjoint by ignition, but not entirely by landscape.
- **More wildland–urban interface near Spokane.** There are more human ignitions near dense roads. M2's road and density controls apply, and S6 splits by cause.
- **Different reporting agencies,** for example tribal and BIA records. Agency is not in the model, as in the pilot.

## 8. Freeze, timestamp and registration

**Frozen files:** everything listed in `FREEZE.json`:
- this file, its template and the registration README;
- all code;
- the blind predictor table and the configuration;
- every raw input, including the raw ignition and MTBS records;
- the request log and the fetch logs;
- the records: `EQUIVALENCE.json`, `BLIND_DESIGN.json`, `SYNTHETIC_VALIDATION.json`, `CHECKS.txt`, `FETCH_PROVENANCE.md`;
- the pilot files this test reads: its predictor table, outcomes and configuration.

**Timestamp.** `FREEZE.json` was submitted to OpenTimestamps calendars, with Bitcoin confirmation pending at freeze. The upgraded proof will be added once it is confirmed.

**Public registration.** This folder will be published under the author's account, as a commit in a public GitHub repository or as a Zenodo record. `fetch_outcomes.py` verifies the public copy itself before requesting any outcome. After fetching, it writes `OUTCOME_FETCH.json` and stamps it with OpenTimestamps. That record holds:
- the counts;
- the service's layer metadata;
- the hashes of outcomes.csv and of the request log.

## 9. Deviations

Any change after the freeze is reported as a numbered deviation, with its date and reason.
