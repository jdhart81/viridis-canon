# P1C: pre-registration of a confirmatory wildfire test (northeast Washington), v1.1

This folder is the **public registration** of a confirmatory test. Everything here was frozen, with hashes in `FREEZE.json`, before any fire-size outcome for the region was requested. v1.1 supersedes v1.0, which was frozen but never published. The plan's §0 says what changed and why. The v1.0 freeze record and its timestamp are kept as `v1.0_FREEZE.json` and `v1.0_FREEZE.json.ots`.

## What is tested

**The claim.** Wildfires that start inside smaller compartments of mapped barriers end smaller. The barriers are vehicle roads, open water and non-burnable ground. The effect holds beyond barrier density and distance to the nearest road. The claim comes from *Trees Cannot Cut*: compartments come only from closed loops of holdable features.

**The pilot,** in Okanogan, Methow and Chelan, WA, pre-registered and frozen 2026-10-20 20:13 ET:
- β = 0.063 (95% CI 0.010–0.117), n = 2,677;
- about 16% larger fires per tenfold larger compartment.

**This test.** One confirmatory test in a new, adjacent region:
- **H2, definition B, model M2:** SUPPORTED if β − t(0.975, G − 1) × max(two-way SE, year SE) > 0.
- **The two-way SE** is clustered by year and 20 km block.
- **Why this interval:** null calibrations on this design showed the pilot's narrower interval calls a true null effect too often.
- **The plan:** `PREREGISTRATION_P1C_NEWA_v1.1.md`.

## How to check the freeze

1. **Hashes.** `FREEZE.json` lists the SHA-256 of every frozen file, with paths as they were in the analysis folder. `SHA256SUMS.txt` covers this package.
2. **Gzipped files.** Decompressed, each `.gz` file must match its entry in `FREEZE.json`:
   - `predictors_blind.csv.gz` → `predictors_blind.csv`;
   - `raw_fpafod_ignitions_blind.json.gz` → `raw/fpafod_ignitions_blind.json`;
   - `raw_mtbs_perims.json.gz` → `raw/mtbs_perims.json`;
   - `pilot_*.gz` → `../p1/*`.
   
   `logs.tar.gz` holds `logs/`.
3. **Not shipped.** The large predictor inputs (LANDFIRE and PCL arrays, roads, NHD, ERC; about 400 MB) are not in this package. Their hashes are in `FREEZE.json`, and `fetch_data.py` re-fetches them from the public services.
4. **The timestamp.** `FREEZE.json.ots` is an OpenTimestamps proof that `FREEZE.json` existed when it was stamped. Run `ots upgrade FREEZE.json.ots`, then `ots verify FREEZE.json.ots`. Bitcoin confirmation takes a few hours after stamping.
5. **The outcome guard.** `fetch_outcomes.py` requests outcomes only after three checks:
   - the frozen files are unchanged;
   - it has itself downloaded this public copy of the plan and of `FREEZE.json` and found them byte-identical;
   - the sample shares no ignition with the pilot.

   Every record must come back, with year, date and location equal to the frozen records. Every request is logged, and the fetch record is timestamped.

**Running the code.** The scripts expect the pilot files at `../p1/`. To put them there:

```
mkdir -p ../p1
gunzip -c pilot_predictors_blind.csv.gz > ../p1/predictors_blind.csv
gunzip -c pilot_outcomes.csv.gz > ../p1/outcomes.csv
cp pilot_p1_config.json ../p1/p1_config.json
cp pilot_results.json ../p1/results.json
```

**Results** will be added later in a separate file. The files above will not change; any change after the freeze is reported as a numbered deviation.

## Authorship and AI use

**Author:** Justin D. Hart (Viridis LLC).

**AI use:** Claude (Anthropic) designed the analysis, wrote the code and ran it under the author's direction. An independent check of the v1.0 freeze was run by a separate Claude agent that had not built the study. Automated tools are not research authors.
