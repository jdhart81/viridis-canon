#!/usr/bin/env python3
"""Fill PREREG_TEMPLATE.md with numbers computed from files (no hand transcription) and write
PREREGISTRATION_P1C_NEWA_v1.1.md. Reads only predictor-side files and simulation records (no confirmatory outcome)."""
import json, re
import pandas as pd

cfg = json.load(open('p1_config.json'))
D = json.load(open('BLIND_DESIGN.json'))
S = json.load(open('SYNTHETIC_VALIDATION.json'))
E = json.load(open('EQUIVALENCE.json'))
assert S['pass'] and E['build']['identical'] and E['model']['identical']
raw = json.load(open('raw/fpafod_ignitions_blind.json'))
pilot = set(pd.read_csv(cfg['exclude_fod_ids_from'], usecols=['fod_id'])['fod_id'].astype('int64'))
LON0, LAT0, LON1, LAT1 = cfg['analysis_box_lonlat']
inbox = [f for f in raw if (f.get('geometry') or {}).get('x') is not None
         and LON0 <= f['attributes']['longitude'] <= LON1 and LAT0 <= f['attributes']['latitude'] <= LAT1]
excl = [f for f in inbox if int(float(f['attributes']['fod_id'])) in pilot]
on_meridian = sum(abs(float(f['attributes']['longitude']) - (-119.4)) < 1e-9 for f in excl)
assert D['n_table'] == len(inbox) - len(excl), (D['n_table'], len(inbox), len(excl))
if not excl:
    excl_sentence = ('No record needed removing: the two boxes meet only along the meridian at −119.4, and no '
                     'record lies on it in both. The check runs anyway, in the build and in every guard.')
else:
    excl_sentence = (f'{len(excl):,} records were removed, ' + ('all' if on_meridian == len(excl) else f'{on_meridian:,} of them')
                     + ' with longitude exactly −119.4, the shared boundary.')
cause = D['cause']
fmt = lambda v: f'{v:,}'
pct = lambda v: f'{100 * v:.1f}%'
P = D['power_primary']
usable_rows = '\n'.join(
    f"| {name} | {fmt(D['usable'][k]['n'])} | " + ' / '.join(f'{q:.2f}' for q in D['usable'][k]['log10_Aenc_acres_q10_q50_q90']) + ' |'
    for k, name in [('B', 'B, mapped barriers (primary)'), ('A50', 'A50, PCL > 0.5'), ('A25', 'A25, PCL > 0.25'), ('Bp', 'B+, B plus prior scars')])
sim = P['simulated_registered_rule']['power_P_SUPPORTED']
power_rows = '\n'.join(f"| {name} | " + ' | '.join(f'{v:.2f}' for v in vals.values()) + ' |' for name, vals in sim.items())
NC = S['null_calibration']
vc = NC['pilot_variance_components']
fill = {
    'W': fmt(cfg['W']), 'H': fmt(cfg['H']), 'N_RAW': fmt(len(inbox)), 'EXCL_SENTENCE': excl_sentence,
    'N_TABLE': fmt(D['n_table']), 'N_NAT': fmt(cause.get('Natural', 0)), 'N_HUM': fmt(cause.get('Human', 0)),
    'N_MISS': fmt(sum(v for k, v in cause.items() if k not in ('Natural', 'Human'))),
    'ERC_AVAIL': pct(D['erc_available']),
    'SYN_PLANT': f"{S['planted']['beta']:.3f} (interval {S['planted']['ci95_primary'][0]:.3f}–{S['planted']['ci95_primary'][1]:.3f})",
    'SYN_PLANT_DEC': S['planted']['decision'],
    'SYN_NULL': f"{S['null']['beta']:.3f} (interval {S['null']['ci95_primary'][0]:.3f} to {S['null']['ci95_primary'][1]:.3f})",
    'SYN_NULL_DEC': S['null']['decision'],
    'DOF': str(NC['dof']), 'TCRIT': f"{NC['t_crit']:.3f}",
    'VAR_BLOCK': f"{vc['var_block']:.3f}", 'VAR_TOTAL': f"{vc['var_block'] + vc['var_within']:.3f}",
    'ICC': f"{vc['var_block'] / (vc['var_block'] + vc['var_within']):.3f}",
    'CAL_IID_PILOT': pct(NC['iid']['pilot']['false_call_share']), 'CAL_COR_PILOT': pct(NC['block_correlated']['pilot']['false_call_share']),
    'CAL_IID_MAXZ': pct(NC['iid']['max_z']['false_call_share']), 'CAL_COR_MAXZ': pct(NC['block_correlated']['max_z']['false_call_share']),
    'CAL_IID_PRIMARY': pct(NC['iid']['primary']['false_call_share']), 'CAL_COR_PRIMARY': pct(NC['block_correlated']['primary']['false_call_share']),
    'USABLE_ROWS': usable_rows, 'N_B': fmt(P['n_usable_B']), 'SDRES': f"{P['sd_resid_log10Aenc']:.3f}",
    'AN_SE': f"{P['monte_carlo_iid']['analytic_iid_se']:.4f}", 'POWER_ROWS_SIM': power_rows,
    'N_S10': fmt(D['s10_outside_pilot_compute_box']['usable_B']), 'N_S10_IN': fmt(D['s10_outside_pilot_compute_box']['usable_B_inside']),
    'N_SHARED': fmt(D['landscape_overlap']['usable_B_ignitions_sharing_a_compartment_with_a_pilot_ignition']),
    'EQ_VALUES': fmt(E['model']['values_compared']), 'EQ_OUTPUTS': str(E['model']['outputs_compared']),
}
t = open('PREREG_TEMPLATE.md').read()
for k, v in fill.items():
    t = t.replace('{{' + k + '}}', re.sub(r'(?<![\w.])-(?=\d)', '−', v))   # typographic minus for negatives
left = re.findall(r'\{\{[A-Z0-9_]+\}\}', t)
assert not left, left
open('PREREGISTRATION_P1C_NEWA_v1.1.md', 'w').write(t)
print('written; excluded:', len(excl), '| on meridian:', on_meridian)
