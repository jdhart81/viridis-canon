#!/usr/bin/env python3
"""Freeze the confirmatory plan (v1.1): hash every frozen file into FREEZE.json, refusing if any check fails.

Invariants checked here (the run stops on any failure):
  F1 no outcomes.csv, results.json or REGISTRATION.json exists in this folder (nothing fetched, run or registered);
  F2 the raw ignition records carry only the allow-listed fields, and every MTBS record carries only its year;
  F3 every frozen file exists; F4 the pre-registration has no unfilled {{PLACEHOLDER}};
  F5 EQUIVALENCE.json was produced by the build_predictors.py and run_test.py being frozen, and both are identical;
  F6 SYNTHETIC_VALIDATION.json and BLIND_DESIGN.json were produced by the run_test.py and simcal.py being frozen,
     and the validation passed.
Frozen set: the plan, its template and README, all code, the blind predictor table and configuration, every raw
input and the request log, every fetch log, the records, the pilot files this test reads, and the v1.0 freeze record.
Then OpenTimestamps-stamp FREEZE.json (python3 freeze.py --stamp).
"""
import glob, hashlib, json, os, re, subprocess, sys, time

PREREG = 'PREREGISTRATION_P1C_NEWA_v1.1.md'
CODE = ['run_test.py', 'simcal.py', 'fetch_outcomes.py', 'build_predictors.py', 'fetch_data.py', 'check_predictors.py',
        'blind_design.py', 'validate_synthetic.py', 'verify_registration.py', 'equivalence.py', 'fill_prereg.py',
        'freeze.py', 'make_package.py', 'run_chain.sh']
DOCS = [PREREG, 'PREREG_TEMPLATE.md', 'REGISTRATION_README.md', 'FETCH_PROVENANCE.md']
RECORDS = ['p1_config.json', 'predictors_blind.csv', 'EQUIVALENCE.json', 'BLIND_DESIGN.json', 'SYNTHETIC_VALIDATION.json', 'CHECKS.txt']
PILOT = ['../p1/predictors_blind.csv', '../p1/outcomes.csv', '../p1/p1_config.json', '../p1/results.json', '../p1/DEVIATION_2.json']
HISTORY = ['history_v1.0/FREEZE.json', 'history_v1.0/FREEZE.json.ots']


def frozen_list():
    raw = sorted(p for p in glob.glob('raw/*') + glob.glob('raw/erc/*') if os.path.isfile(p))
    logs = sorted(glob.glob('logs/*'))
    return DOCS + CODE + RECORDS + raw + logs + PILOT + HISTORY


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def main():
    for f in ('outcomes.csv', 'results.json', 'REGISTRATION.json'):
        assert not os.path.exists(f), f'F1: {f} present'
    allow = {'objectid', 'fod_id', 'fire_year', 'discovery_date', 'discovery_doy', 'nwcg_cause_classification',
             'nwcg_general_cause', 'latitude', 'longitude', 'owner_descr', 'state', 'nwcg_reporting_agency'}
    keys = {k.lower() for f in json.load(open('raw/fpafod_ignitions_blind.json')) for k in f['attributes']}
    assert keys <= allow, f'F2: non-allow-listed fields in raw ignitions: {keys - allow}'
    mk = {k for f in json.load(open('raw/mtbs_perims.json')) for k in f['attributes']}
    assert mk == {'year'}, f'F2: MTBS attributes beyond year: {mk}'
    FROZEN = frozen_list()
    missing = [f for f in FROZEN if not os.path.exists(f)]
    assert not missing, f'F3: missing {missing}'
    assert not re.search(r'\{\{[A-Z0-9_]+\}\}', open(PREREG).read()), 'F4: unfilled placeholder in the prereg'
    E = json.load(open('EQUIVALENCE.json'))
    assert E['build']['build_predictors_sha256'] == sha('build_predictors.py') and E['build']['identical'], 'F5: build equivalence stale'
    assert E['model']['run_test_sha256'] == sha('run_test.py') and E['model']['identical'], 'F5: model equivalence stale'
    S = json.load(open('SYNTHETIC_VALIDATION.json')); B = json.load(open('BLIND_DESIGN.json'))
    assert S['pass'], 'F6: synthetic validation did not pass'
    for f in ('run_test.py', 'simcal.py'):
        assert S['code_sha256'][f] == sha(f) and B['code_sha256'][f] == sha(f), f'F6: records stale for {f}'
    assert B['code_sha256']['predictors_blind.csv'] == sha('predictors_blind.csv'), 'F6: design record stale'
    t = time.time()
    rec = dict(version='1.1', supersedes=dict(version='1.0', freeze_sha256=sha('history_v1.0/FREEZE.json'), published=False),
               frozen_at_local=time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(t)),
               frozen_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(t)),
               note=('Frozen before any FPA FOD outcome field (fire_size etc.) for this region was requested. '
                     'fetch_outcomes.py verifies these hashes and downloads the public copy of the plan before fetching.'),
               sha256={f: sha(f) for f in FROZEN})
    json.dump(rec, open('FREEZE.json', 'w'), indent=1)
    print(f'frozen {len(FROZEN)} files at', rec['frozen_at_local'])
    print('FREEZE.json sha256', sha('FREEZE.json'))


def stamp():
    cals = ['https://alice.btc.calendar.opentimestamps.org', 'https://finney.calendar.eternitywall.com',
            'https://bob.btc.calendar.opentimestamps.org', 'https://a.pool.opentimestamps.org']
    cmd = ['ots', 'stamp', '-m', '1'] + sum([['-c', c] for c in cals], []) + ['FREEZE.json']
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    print(r.stdout, r.stderr)
    assert os.path.exists('FREEZE.json.ots'), 'stamp failed'
    print(subprocess.run(['ots', 'info', 'FREEZE.json.ots'], capture_output=True, text=True).stdout[:600])


if __name__ == '__main__':
    stamp() if '--stamp' in sys.argv else main()
