#!/usr/bin/env python3
"""Assemble the public registration package (flat folder) for plan v1.1. Run after freeze.py --stamp.

Every frozen source is checked against FREEZE.json first. Large predictor inputs (LANDFIRE and PCL arrays, roads,
NHD, ERC: about 400 MB) are not copied; their hashes are in FREEZE.json and fetch_data.py re-fetches them.
Tables and raw records are gzipped deterministically (no name or timestamp in the header), and the logs are
packed into a deterministic tar.gz, so the package bytes are reproducible. SHA256SUMS.txt covers every file.
Usage: python3 make_package.py <output dir>"""
import gzip, hashlib, io, json, os, shutil, sys, tarfile

OUT = sys.argv[1]
F = json.load(open('FREEZE.json'))
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
for p, h in F['sha256'].items():
    assert sha(p) == h, f'{p} changed after the freeze'
assert os.path.exists('FREEZE.json.ots'), 'stamp FREEZE.json first'
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)


def gz(src, name):
    dst = os.path.join(OUT, name)
    with open(src, 'rb') as fi, open(dst, 'wb') as fo:
        with gzip.GzipFile(filename='', mode='wb', fileobj=fo, compresslevel=9, mtime=0) as g:
            shutil.copyfileobj(fi, g)
    assert hashlib.sha256(gzip.decompress(open(dst, 'rb').read())).hexdigest() == F['sha256'][src]


plain = [p for p in F['sha256'] if '/' not in p and p != 'predictors_blind.csv' and p != 'REGISTRATION_README.md']
for p in plain:
    shutil.copy2(p, os.path.join(OUT, p))
shutil.copy2('REGISTRATION_README.md', os.path.join(OUT, 'README.md'))
for p in ('FREEZE.json', 'FREEZE.json.ots'):
    shutil.copy2(p, os.path.join(OUT, p))
gz('predictors_blind.csv', 'predictors_blind.csv.gz')
gz('raw/fpafod_ignitions_blind.json', 'raw_fpafod_ignitions_blind.json.gz')
gz('raw/mtbs_perims.json', 'raw_mtbs_perims.json.gz')
for p, name in [('raw/requests.log', 'raw_requests.log'), ('raw/pcl_legend.json', 'raw_pcl_legend.json'),
                ('raw/pcl_tile_log.json', 'raw_pcl_tile_log.json'), ('../p1/p1_config.json', 'pilot_p1_config.json'),
                ('../p1/results.json', 'pilot_results.json'), ('../p1/DEVIATION_2.json', 'pilot_DEVIATION_2.json'),
                ('history_v1.0/FREEZE.json', 'v1.0_FREEZE.json'), ('history_v1.0/FREEZE.json.ots', 'v1.0_FREEZE.json.ots')]:
    shutil.copy2(p, os.path.join(OUT, name))
gz('../p1/predictors_blind.csv', 'pilot_predictors_blind.csv.gz')
gz('../p1/outcomes.csv', 'pilot_outcomes.csv.gz')
# logs: deterministic tar.gz
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode='w', format=tarfile.PAX_FORMAT) as tf:
    for p in sorted(k for k in F['sha256'] if k.startswith('logs/')):
        data = open(p, 'rb').read(); ti = tarfile.TarInfo(p); ti.size = len(data); ti.mtime = 0; ti.mode = 0o644
        ti.uid = ti.gid = 0; ti.uname = ti.gname = ''
        tf.addfile(ti, io.BytesIO(data))
with open(os.path.join(OUT, 'logs.tar.gz'), 'wb') as fo:
    with gzip.GzipFile(filename='', mode='wb', fileobj=fo, compresslevel=9, mtime=0) as g:
        g.write(buf.getvalue())
names = sorted(n for n in os.listdir(OUT) if n != 'SHA256SUMS.txt')
with open(os.path.join(OUT, 'SHA256SUMS.txt'), 'w') as fh:
    for n in names:
        fh.write(f'{sha(os.path.join(OUT, n))}  {n}\n')
size = sum(os.path.getsize(os.path.join(OUT, n)) for n in names)
print(OUT, len(names), 'files;', size // 1024, 'KiB')
