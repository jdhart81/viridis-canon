#!/usr/bin/env bash
# Resume the NHD waterbody fetch until it lands (one request per attempt when the server is down), then run the
# blind build and every pre-freeze step. Stops before the freeze so the filled plan can be reviewed first.
set -u
cd /home/claude/p1c
SYN=/tmp/claude-0/-home-claude/d23d759f-9c1b-589b-9849-6bba926e6bc3/scratchpad/synth_final
for i in $(seq 1 120); do
  [ -f raw/nhd_waterbody.json ] && break
  echo "$(date +%H:%M:%S) attempt $i"
  python3 -u fetch_data.py vectors > fetch_vectors_try$i.log 2>&1
  rc=$?
  grep -E "ids tile|features|done in" fetch_vectors_try$i.log | tail -5
  [ -f raw/nhd_waterbody.json ] && break
  echo "$(date +%H:%M:%S) attempt $i failed (rc=$rc); next in 90 s"
  sleep 90
done
[ -f raw/nhd_waterbody.json ] || { echo "CHAIN STOP: NHD waterbody still unavailable"; exit 2; }
echo "$(date +%H:%M:%S) data complete; building"
set -e
python3 build_predictors.py | tail -3
python3 check_predictors.py > CHECKS.txt; echo "checks: $(grep -c '^PASS' CHECKS.txt) PASS, $(grep -c '^FAIL' CHECKS.txt) FAIL"
python3 blind_design.py > /dev/null
python3 validate_synthetic.py "$SYN" | grep -E '"decision"|"pass"'
python3 equivalence_model.py | grep -E 'identical|max_abs'
python3 fill_prereg.py
echo "$(date +%H:%M:%S) CHAIN READY FOR FREEZE"
