#!/usr/bin/env python3
"""Fast simulations of the registered decision rules on a fixed blind design, for calibration and power.

Design() reproduces, for the B/M2 compartment slope, the exact arithmetic of run_test.fit (year-only CR1) and
run_test.fit_twoway (two-way CR1 by year and 20 km block, with the same fallback); callers check this against
run_test on the first replicates. pilot_variance_components() estimates, from the PILOT's B/M2 residuals (pilot
outcomes are already known), how much residual variance is shared within 20 km blocks (one-way ANOVA, method of
moments). No confirmatory outcome is used anywhere."""
import math
import numpy as np


class Design:
    def __init__(self, rt, pred, block_m=20000):
        s, a = rt.sample(pred.assign(fire_size=1.0), 'B')
        X = rt.design(s, a, 'rho_B', 'M2')
        self.Xv = X.values.astype(float); self.n, self.k = self.Xv.shape
        self.XtX_inv = np.linalg.pinv(self.Xv.T @ self.Xv)
        self.h = self.Xv @ self.XtX_inv[:, list(X.columns).index('log10_Aenc')]
        self.pos = pred.index.get_indexer(s.index)
        self.la = np.log10(s[a].values)
        g = s['fire_year'].astype(str).values
        blk = ((s['x'] // block_m).astype(int).astype(str) + '_' + (s['y'] // block_m).astype(int).astype(str)).values
        _, self.yinv = np.unique(g, return_inverse=True)
        _, self.binv = np.unique(blk, return_inverse=True)
        _, self.ybinv = np.unique(np.char.add(np.char.add(g, '|'), blk), return_inverse=True)
        self.nblocks = int(self.binv.max() + 1)
        self.dof = int(min(self.yinv.max() + 1, self.nblocks) - 1)
        self.t = rt.t_crit(self.dof)
        c = lambda inv: (inv.max() + 1) / inv.max() * (self.n - 1) / (self.n - self.k)
        self.cY, self.cB, self.cYB = c(self.yinv), c(self.binv), c(self.ybinv)

    def stats(self, y):
        """beta, year-only SE, two-way SE, max SE for outcome vector y (sample rows, in sample order)."""
        bj = float(self.h @ y)
        e = y - self.Xv @ (self.XtX_inv @ (self.Xv.T @ y)); w = self.h * e
        vy = self.cY * float((np.bincount(self.yinv, weights=w) ** 2).sum())
        vb = self.cB * float((np.bincount(self.binv, weights=w) ** 2).sum())
        vyb = self.cYB * float((np.bincount(self.ybinv, weights=w) ** 2).sum())
        v2 = vy + vb - vyb
        if v2 <= 0:
            v2 = max(vy, vb)
        sy, s2 = math.sqrt(vy), math.sqrt(v2)
        return bj, sy, s2, max(sy, s2)


def simulate(D, erc_sample, beta, reps, seed0, var_block=0.0, var_within=1.08 ** 2):
    """Outcome = beta * log10 Aenc + 0.5 * erc_pct + block effect + noise; returns call shares per rule:
    primary  = the registered P1C rule, beta +- t(0.975, G-1) * max(two-way SE, year-only SE);
    pilot    = the pilot's rule, beta +- 1.96 * year-only SE;
    max_z    = beta +- 1.96 * max(...), for reference."""
    rules = {'primary': lambda sy, sm: (D.t, sm), 'pilot': lambda sy, sm: (1.96, sy), 'max_z': lambda sy, sm: (1.96, sm)}
    counts = {r: {'SUPPORTED': 0, 'CONTRADICTED': 0, 'NOT SUPPORTED': 0} for r in rules}
    for r in range(reps):
        rng = np.random.default_rng(seed0 + r)
        y = beta * D.la + 0.5 * erc_sample + rng.normal(0, math.sqrt(var_within), D.n)
        if var_block > 0:
            y = y + rng.normal(0, math.sqrt(var_block), D.nblocks)[D.binv]
        bj, sy, s2, sm = D.stats(y)
        for name, f in rules.items():
            c, se = f(sy, sm)
            lo, hi = bj - c * se, bj + c * se
            counts[name]['SUPPORTED' if lo > 0 else ('CONTRADICTED' if hi < 0 else 'NOT SUPPORTED')] += 1
    return {rule: {k: v / reps for k, v in c.items()} for rule, c in counts.items()}


def pilot_variance_components(rt, pilot_dir='/home/claude/p1/', block_m=20000):
    import pandas as pd
    dp = pd.read_csv(pilot_dir + 'predictors_blind.csv').merge(pd.read_csv(pilot_dir + 'outcomes.csv')[['fod_id', 'fire_size']], on='fod_id', how='left')
    sp, ap = rt.sample(dp, 'B')
    Xp = rt.design(sp, ap, 'rho_B', 'M2').values.astype(float); yp = np.log10(sp['fire_size'].values)
    ep = yp - Xp @ np.linalg.lstsq(Xp, yp, rcond=None)[0]
    bp = ((sp['x'] // block_m).astype(int).astype(str) + '_' + (sp['y'] // block_m).astype(int).astype(str)).values
    codes, inv = np.unique(bp, return_inverse=True); nb = np.bincount(inv); N, B = len(ep), len(codes)
    means = np.bincount(inv, weights=ep) / nb
    msw = float(((ep - means[inv]) ** 2).sum()) / (N - B)
    msb = float((nb * (means - ep.mean()) ** 2).sum()) / (B - 1); n0 = (N - (nb ** 2).sum() / N) / (B - 1)
    return dict(var_block=max(0.0, (msb - msw) / n0), var_within=msw, blocks=int(B), n=int(N))
