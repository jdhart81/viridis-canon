#!/usr/bin/env python3
"""Validate run_test.py on SYNTHETIC outcomes before the freeze (v3, for plan v1.1). No real outcome exists for
this region; the script asserts that before and after.

A. End to end through run_test.py on this region's real blind predictors (scratch directory):
     planted: log10 size = 0.30 * log10 Aenc_B + 0.5 * erc_pct + N(0, 1.08)  -> must be SUPPORTED
     null:    log10 size =                      0.5 * erc_pct + N(0, 1.08)  -> one fixed draw (seed 202), reported
B. Null calibration of the decision rules on this design, 10,000 replicates each (simcal.py; exact arithmetic,
   checked against run_test on the first replicates):
     iid errors                      (seeds 100000..109999)
     block-correlated errors         (seeds 200000..209999), with the residual variance shared within 20 km blocks
                                     estimated from the PILOT's B/M2 residuals
   Rules: "primary" = the registered P1C rule, beta +- t(0.975, G-1) * max(two-way SE, year-only SE);
          "pilot"   = the pilot's rule, beta +- 1.96 * year-only SE (reported, not decisive);
          "max_z"   = beta +- 1.96 * max(...), for reference.
PASS iff (A) planted is SUPPORTED, and (B) the primary rule's false-call share (SUPPORTED + CONTRADICTED) is at most
0.065 under BOTH error models (nominal 0.05 plus 1.5 points of tolerance for a 33-cluster test; the tolerance was
set after an exploratory 4,000-replicate run, reported in the plan, gave 4.7% iid and 5.6% block-correlated).
History: run 1 (plan v1.0) scored a single null draw, which came out CONTRADICTED; v2 replaced that with a
1,000-replicate iid calibration of the pilot's rule (4.4%); v3 adds block-correlated errors and 10,000 replicates,
which show the pilot's rule over-calls (about 7% iid, 12% correlated), and that is why plan v1.1 decides on the
t x max-SE interval. Earlier records: history_v1.0/.
Usage: python3 validate_synthetic.py <scratch dir>
"""
import importlib.util, json, os, shutil, subprocess, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import simcal  # noqa: E402

assert not os.path.exists(os.path.join(HERE, 'outcomes.csv')), 'a real outcome file exists; stop'
SC = os.path.abspath(sys.argv[1]); os.makedirs(SC, exist_ok=True)
link = os.path.join(SC, 'p1')
if not os.path.islink(link):
    os.symlink('/home/claude/p1', link)            # so ../p1/... resolves for run_test.py
pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
la = np.log10(pred['Aenc_B'].where(pred['Aenc_B'] > 0, 1000.0)).values
erc = pred['erc_pct'].fillna(0.5).values
out = {}
for world, beta, seed in [('planted', 0.30, 101), ('null', 0.0, 202)]:
    d = os.path.join(SC, world); os.makedirs(d, exist_ok=True)
    shutil.copy(os.path.join(HERE, 'run_test.py'), d)
    dst = os.path.join(d, 'predictors_blind.csv')
    if not os.path.exists(dst):
        os.symlink(os.path.join(HERE, 'predictors_blind.csv'), dst)
    rng = np.random.default_rng(seed)
    y = beta * la + 0.5 * erc + rng.normal(0, 1.08, len(pred))
    pd.DataFrame({'fod_id': pred['fod_id'], 'fire_size': 10 ** y, 'fire_size_class': 'SYN'}).to_csv(os.path.join(d, 'outcomes.csv'), index=False)
    subprocess.run([sys.executable, 'run_test.py'], cwd=d, check=True, capture_output=True)
    R = json.load(open(os.path.join(d, 'results.json')))
    p = R['primary_test']
    out[world] = dict(planted_beta=beta, beta=round(p['beta'], 3), ci95_primary=[round(v, 3) for v in p['ci95_primary']],
                      ci95_year=[round(v, 3) for v in p['ci95_year']], n=p['n'], decision=R['decision'],
                      decision_pilot_rule=R['decision_pilot_rule'], reading=R['interpretation']['reading'])
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))

spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
D = simcal.Design(rt, pred)
erc_s = erc[D.pos]
# exactness: the fast path equals run_test on two replicates, with and without block effects
vc = simcal.pilot_variance_components(rt)
for r, vb in [(0, 0.0), (1, vc['var_block'])]:
    rng = np.random.default_rng(99 + r)
    y = 0.5 * erc_s + rng.normal(0, 1.08, D.n) + (rng.normal(0, np.sqrt(vb), D.nblocks)[D.binv] if vb > 0 else 0)
    yfull = np.zeros(len(pred)); yfull[D.pos] = y
    tw = rt.fit_twoway(pred.assign(fire_size=10 ** yfull), 'B'); bj, sy, s2, sm = D.stats(y)
    assert abs(tw['beta'] - bj) < 1e-10 and abs(tw['se_year_only'] - sy) < 1e-10 and abs(tw['se'] - s2) < 1e-10 and abs(tw['se_max'] - sm) < 1e-10
    assert tw['dof'] == D.dof and abs(tw['t_crit'] - D.t) < 1e-12
REPS = 10000
iid = simcal.simulate(D, erc_s, 0.0, REPS, 100000)
cor = simcal.simulate(D, erc_s, 0.0, REPS, 200000, var_block=vc['var_block'], var_within=vc['var_within'])
fc = lambda c: c['SUPPORTED'] + c['CONTRADICTED']
out['null_calibration'] = dict(reps=REPS, n=D.n, blocks=D.nblocks, pilot_variance_components=vc,
                               iid={rule: dict(c, false_call_share=fc(c)) for rule, c in iid.items()},
                               block_correlated={rule: dict(c, false_call_share=fc(c)) for rule, c in cor.items()},
                               dof=D.dof, t_crit=D.t, threshold=0.065)
ok = (out['planted']['decision'] == 'SUPPORTED' and fc(iid['primary']) <= 0.065 and fc(cor['primary']) <= 0.065)
out['pass_criterion'] = ('planted SUPPORTED under the registered rule, and that rule\'s null false-call share <= 0.065 '
                         'under iid and under block-correlated errors; the single null draw is reported, not scored')
out['pass'] = ok
import hashlib
out['code_sha256'] = {f: hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
                      for f in ('run_test.py', 'simcal.py', 'validate_synthetic.py')}
json.dump(out, open(os.path.join(HERE, 'SYNTHETIC_VALIDATION.json'), 'w'), indent=1)
print(json.dumps(out, indent=1))
sys.exit(0 if ok else 1)
