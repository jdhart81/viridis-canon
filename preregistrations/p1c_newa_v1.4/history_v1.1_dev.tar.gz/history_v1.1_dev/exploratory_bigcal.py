import importlib.util, json, sys, math, numpy as np, pandas as pd
sys.path.insert(0, '/home/claude/p1c'); import simcal
spec = importlib.util.spec_from_file_location('rt', '/home/claude/p1c/run_test.py'); rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
pred = pd.read_csv('/home/claude/p1c/predictors_blind.csv'); erc = pred['erc_pct'].fillna(0.5).values
D = simcal.Design(rt, pred); es = erc[D.pos]; vc = simcal.pilot_variance_components(rt)
T32 = 2.036933343460101
res = {}
for name, vb, vw, seed in [('iid', 0.0, 1.08**2, 30000), ('block', vc['var_block'], vc['var_within'], 40000)]:
    hits = {'year_1.96': 0, 'max_1.96': 0, 'max_t32': 0, 'year_t32': 0}; bs = []; sy_l = []; sm_l = []
    R = 4000
    for r in range(R):
        rng = np.random.default_rng(seed + r)
        y = 0.5 * es + rng.normal(0, math.sqrt(vw), D.n)
        if vb > 0: y = y + rng.normal(0, math.sqrt(vb), D.nblocks)[D.binv]
        bj, sy, s2, sm = D.stats(y); bs.append(bj); sy_l.append(sy); sm_l.append(sm)
        hits['year_1.96'] += abs(bj) > 1.96 * sy; hits['max_1.96'] += abs(bj) > 1.96 * sm
        hits['max_t32'] += abs(bj) > T32 * sm; hits['year_t32'] += abs(bj) > T32 * sy
    res[name] = dict({k: v / R for k, v in hits.items()}, reps=R, sd_beta=float(np.std(bs)), mean_se_year=float(np.mean(sy_l)), mean_se_max=float(np.mean(sm_l)))
print(json.dumps(res, indent=1))
