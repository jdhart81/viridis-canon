#!/usr/bin/env python3
"""P1 confirmatory replication (NE Washington): the pre-registered test.
Frozen with PREREGISTRATION_P1C_NEWA_v1.1.md; SHA-256 hashes in FREEZE.json.

Derived from the pilot's run_test_dev1.py (pilot frozen 2026-10-20 20:13 ET; its Deviation 1 guard included).
The model arithmetic (design, ols_cluster, cluster_bootstrap, sample, fit, containment_perm) is unchanged for
default arguments: replaying the pilot's call sequence reproduces every number in the pilot's results.json.
Changes, all fixed before any confirmatory outcome exists on disk:
  1. ONE primary test: H2 under definition B (mapped barriers), model M2. A50 and A25 are secondary.
  2. Disjointness assertion: no fod_id from the pilot predictor table may appear in this sample.
  3. Interpretive outputs that never change the decision: a small-telescopes reading (Simonsohn 2015),
     the difference from the pilot and a pooled estimate (under independence, and from a stacked model, item 7).
  4. The pilot's Deviation 1 not-estimable guard is built in (NOT ESTIMABLE when n <= k or < 2 year clusters).
  5. S9: the M2 estimate with SEs two-way clustered by year and 20 km block; the robustness reading uses the
     larger of the two-way and year-only SEs.
  6. S10: drop ignitions inside the pilot's compute box (where the pilot's MTBS fetch received all attributes).
  7. Stacked model with the pilot (separate coefficients, CR1 clustered by year across both regions), so the
     difference test and the pooled estimate account for the 33 shared years.
  8. Leave-one-year-out stability of the primary estimate.
  9. S11: M2 without the fuel-group term (LANDFIRE 2024 fuels partly reflect post-fire updates).
Inputs : predictors_blind.csv, outcomes.csv (fetched only through fetch_outcomes.py's guards), the pilot's
         predictors_blind.csv, outcomes.csv and p1_config.json (hashes in FREEZE.json).
Outputs: results.json
Models (exactly as in the pilot):
  Y = log10(fire_size acres)
  M1: Y ~ log10(Aenc) + erc_pct + C(fuel_group) + C(cause) + C(month) + C(year)
  M2: M1 + log10(rho + 0.001) + log10(road_dist_m + 30)
Inference: OLS, cluster-robust (CR1) standard errors by year; Wald 95% CI (estimate +- 1.96 SE, as in the pilot);
cluster bootstrap by year (2,000).
Decision (registered): SUPPORTED iff the CR1 95% CI for beta_log10Aenc (B, M2) lies entirely above 0;
CONTRADICTED iff entirely below 0; otherwise NOT SUPPORTED.
"""
import json
import math
import numpy as np
import pandas as pd

RNG = np.random.default_rng(20261020)

# Pilot primary estimate (B, M2), from p1/results.json, fixed before the freeze.
PILOT = dict(beta=0.06317647448409425, se=0.027318251774805232, n=2677, clusters=33)
Z = 1.96                                     # the pilot's critical value, used everywhere here
Z95 = 1.6448536269514722                     # one-sided 5% (the 90% interval used by the small-telescopes reading)
PHI_INV_033 = -0.4399131656732338            # standard normal quantile at 0.33
BETA33 = PILOT['se'] * (Z + PHI_INV_033)     # effect the pilot had 33% power to detect with its own rule
PILOT_DIR = '../p1/'
PILOT_TABLE = PILOT_DIR + 'predictors_blind.csv'
FES = ('fuel_group', 'cause', 'month', 'fire_year')


def phi(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def design(df, aenc_col, rho_col, model, fes=FES):
    cols = {'log10_Aenc': np.log10(df[aenc_col].values), 'erc_pct': df['erc_pct'].values}
    if model == 'M2':
        cols['log10_rho'] = np.log10(df[rho_col].values + 0.001)
        cols['log10_roaddist'] = np.log10(df['road_dist_m'].values + 30.0)
    X = pd.DataFrame(cols, index=df.index)
    for fe in fes:
        d = pd.get_dummies(df[fe].astype(str), prefix=fe, drop_first=True, dtype=float)
        X = pd.concat([X, d], axis=1)
    X.insert(0, 'const', 1.0)
    X = X.loc[:, X.std(ddof=0).gt(0) | (X.columns == 'const')]
    return X


def ols_cluster(X, y, groups):
    Xv = X.values.astype(float); yv = y.astype(float)
    XtX_inv = np.linalg.pinv(Xv.T @ Xv)
    b = XtX_inv @ Xv.T @ yv
    e = yv - Xv @ b
    n, k = Xv.shape
    G = pd.unique(groups); meat = np.zeros((k, k))
    if n - k <= 0 or len(G) < 2:          # pilot Deviation 1: not estimable
        nanv = pd.Series(np.nan, index=X.columns)
        return nanv, nanv, len(G), n
    for g in G:
        idx = groups == g
        s = Xv[idx].T @ e[idx]
        meat += np.outer(s, s)
    c = len(G) / (len(G) - 1) * (n - 1) / (n - k)
    V = c * XtX_inv @ meat @ XtX_inv
    se = np.sqrt(np.diag(V))
    return pd.Series(b, index=X.columns), pd.Series(se, index=X.columns), len(G), n


def cluster_bootstrap(X, y, groups, col, reps=2000):
    G = pd.unique(groups); idx_by = {g: np.nonzero(groups == g)[0] for g in G}
    j = list(X.columns).index(col); out = []
    Xv = X.values.astype(float)
    for _ in range(reps):
        pick = RNG.choice(G, size=len(G), replace=True)
        ii = np.concatenate([idx_by[g] for g in pick])
        b = np.linalg.lstsq(Xv[ii], y[ii], rcond=None)[0]
        out.append(b[j])
    return np.percentile(out, [2.5, 97.5]).tolist()


def sample(df, defn, snap=False, include_censored=False, extra=None):
    a = f'Aenc_{defn}_snap' if snap else f'Aenc_{defn}'
    c = f'cens_{defn}_snap' if snap else f'cens_{defn}'
    s = df[df['fire_size'] > 0].copy()
    s = s[s['erc_pct'].notna() & s['month'].notna()]
    if not snap:
        s = s[~s[f'on_hold_{defn}'].astype(bool)]
    if not include_censored:
        s = s[~s[c].astype(bool)]
    s = s[s[a].notna() & (s[a] > 0)]
    if extra is not None:
        s = s[extra(s)]
    return s, a


def fit(df, defn, model, snap=False, include_censored=False, extra=None, boot=False, min_size=None, fes=FES):
    s, a = sample(df, defn, snap, include_censored, extra)
    if min_size is not None:
        s = s[s['fire_size'] >= min_size]
    rho = {'A50': 'rho_A50', 'A25': 'rho_A25', 'B': 'rho_B', 'Bp': 'rho_B'}[defn]
    X = design(s, a, rho, model, fes)
    if include_censored:
        X['censored'] = s[f'cens_{defn}'].astype(float).values
    y = np.log10(s['fire_size'].values)
    b, se, ng, n = ols_cluster(X, y, s['fire_year'].values)
    if not np.isfinite(b['log10_Aenc']):
        return dict(defn=defn, model=model, n=int(n), clusters=int(ng), k=int(X.shape[1]), not_estimable=True,
                    beta=None, se=None, ci95=[None, None])
    res = dict(defn=defn, model=model, n=int(n), clusters=int(ng), beta=float(b['log10_Aenc']),
               se=float(se['log10_Aenc']), ci95=[float(b['log10_Aenc'] - 1.96 * se['log10_Aenc']),
                                                 float(b['log10_Aenc'] + 1.96 * se['log10_Aenc'])])
    if model == 'M2':
        res['beta_log10_rho'] = float(b['log10_rho']); res['beta_log10_roaddist'] = float(b['log10_roaddist'])
    if boot:
        res['boot_ci95'] = cluster_bootstrap(X, y, s['fire_year'].values, 'log10_Aenc')
    return res


def decide_ci(lo, hi):
    return 'SUPPORTED' if lo > 0 else ('CONTRADICTED' if hi < 0 else 'NOT SUPPORTED')


def fit_twoway(df, defn, block_m=20000):
    """S9: same M2 point estimate; SEs clustered by year (as registered) and two-way by year and 20 km block
    (Cameron, Gelbach & Miller 2011: V = V_year + V_block - V_year*block, each with the CR1 factor; if that
    variance is not positive, the larger one-way variance is used). The robustness reading uses the LARGER of
    the two-way and year-only SEs, so it can only be stricter than the registered rule."""
    s, a = sample(df, defn)
    rho = {'A50': 'rho_A50', 'A25': 'rho_A25', 'B': 'rho_B', 'Bp': 'rho_B'}[defn]
    X = design(s, a, rho, 'M2'); y = np.log10(s['fire_size'].values)
    Xv = X.values.astype(float); n, k = Xv.shape
    label = 'S9 two-way clustered (year x 20 km block)'
    if n - k <= 0:
        return dict(defn=defn, model='M2', label=label, not_estimable=True, beta=None, se=None, ci95=[None, None])
    XtX_inv = np.linalg.pinv(Xv.T @ Xv); b = XtX_inv @ Xv.T @ y; e = y - Xv @ b
    j = list(X.columns).index('log10_Aenc')
    year = s['fire_year'].astype(str).values
    block = ((s['x'] // block_m).astype(int).astype(str) + '_' + (s['y'] // block_m).astype(int).astype(str)).values

    def V(groups):
        G = pd.unique(groups); meat = np.zeros((k, k))
        for g in G:
            idx = groups == g; sc = Xv[idx].T @ e[idx]; meat += np.outer(sc, sc)
        return (len(G) / (len(G) - 1) * (n - 1) / (n - k)) * XtX_inv @ meat @ XtX_inv, len(G)
    Vy, Gy = V(year); Vb, Gb = V(block); Vyb, _ = V(np.char.add(np.char.add(year, '|'), block))
    var2 = (Vy + Vb - Vyb)[j, j]
    fallback = bool(var2 <= 0)
    if fallback:
        var2 = max(Vy[j, j], Vb[j, j])
    se2, sey = float(np.sqrt(var2)), float(np.sqrt(Vy[j, j]))
    sem = max(se2, sey); bj = float(b[j])
    return dict(defn=defn, model='M2', label=label, n=int(n), year_clusters=int(Gy), block_clusters=int(Gb),
                beta=bj, se=se2, ci95=[bj - Z * se2, bj + Z * se2], se_year_only=sey,
                se_block_only=float(np.sqrt(Vb[j, j])), nonpositive_fallback=fallback,
                se_max=sem, ci95_max=[bj - Z * sem, bj + Z * sem], robustness_reading=decide_ci(bj - Z * sem, bj + Z * sem))


def containment_perm(df, defn, reps=10000):
    s, a = sample(df, defn)
    s = s[s['fire_size'] >= 10]
    obs = float((s['fire_size'] <= s[a]).mean())
    strata = s['fire_year'].astype(str) + '|' + s['fuel_group'].astype(str)
    A = s[a].values; F = s['fire_size'].values
    groups = [np.nonzero((strata == k).values)[0] for k in strata.unique()]
    null = np.empty(reps)
    for i in range(reps):
        Ap = A.copy()
        for g in groups:
            if len(g) > 1:
                Ap[g] = A[RNG.permutation(g)]
        null[i] = (F <= Ap).mean()
    return dict(defn=defn, n=int(len(s)), observed=obs, null_mean=float(null.mean()),
                p_one_sided=float((np.sum(null >= obs) + 1) / (reps + 1)))


def decide(r):
    """Registered decision rule on the CR1 95% CI."""
    if r.get('not_estimable') or r['ci95'][0] is None:
        return 'NOT ESTIMABLE'
    return decide_ci(r['ci95'][0], r['ci95'][1])


def stacked_with_pilot(df_conf):
    """Item 7: pilot and confirmatory B/M2 samples in one block-diagonal OLS (every coefficient region-specific,
    so the point estimates equal the two separate fits), CR1 clustered by year across both regions. Returns the
    joint covariance of the two compartment slopes, the difference test and the GLS-pooled estimate."""
    dp = pd.read_csv(PILOT_TABLE).merge(pd.read_csv(PILOT_DIR + 'outcomes.csv')[['fod_id', 'fire_size']], on='fod_id', how='left')
    blocks, ys, gs = [], [], []
    for d in (dp, df_conf):
        s, a = sample(d, 'B'); X = design(s, a, 'rho_B', 'M2')
        blocks.append(X.values.astype(float)); ys.append(np.log10(s['fire_size'].values)); gs.append(s['fire_year'].values)
        if len(blocks) == 1:
            jp = list(X.columns).index('log10_Aenc')
        else:
            jc = blocks[0].shape[1] + list(X.columns).index('log10_Aenc')
    kp, kc = blocks[0].shape[1], blocks[1].shape[1]
    Xs = np.zeros((len(ys[0]) + len(ys[1]), kp + kc))
    Xs[:len(ys[0]), :kp] = blocks[0]; Xs[len(ys[0]):, kp:] = blocks[1]
    y = np.concatenate(ys); g = np.concatenate(gs)
    n, k = Xs.shape
    XtX_inv = np.linalg.pinv(Xs.T @ Xs); b = XtX_inv @ Xs.T @ y; e = y - Xs @ b
    G = pd.unique(g); meat = np.zeros((k, k))
    for gg in G:
        idx = g == gg; sc = Xs[idx].T @ e[idx]; meat += np.outer(sc, sc)
    V = (len(G) / (len(G) - 1) * (n - 1) / (n - k)) * XtX_inv @ meat @ XtX_inv
    bp, bc = float(b[jp]), float(b[jc]); vp, vc, cpc = float(V[jp, jp]), float(V[jc, jc]), float(V[jp, jc])
    S = np.array([[vp, cpc], [cpc, vc]]); w = np.linalg.solve(S, np.ones(2)); den = float(w.sum())
    pooled = float(w @ np.array([bp, bc]) / den); pse = math.sqrt(1 / den)
    dz = (bc - bp) / math.sqrt(vp + vc - 2 * cpc)
    return dict(beta_pilot=bp, beta_conf=bc, se_pilot=math.sqrt(vp), se_conf=math.sqrt(vc), cov=cpc,
                corr=cpc / math.sqrt(vp * vc), year_clusters=int(len(G)),
                difference=dict(diff=bc - bp, z=dz, p_two_sided=2 * (1 - phi(abs(dz)))),
                pooled_gls=dict(beta=pooled, se=pse, ci95=[pooled - Z * pse, pooled + Z * pse]))


def leave_one_year_out(df):
    """Item 8: the primary estimate with each year removed in turn."""
    base = decide(fit(df, 'B', 'M2'))
    out = []
    for yr in sorted(df['fire_year'].dropna().unique()):
        r = fit(df, 'B', 'M2', extra=lambda s, yr=yr: s['fire_year'] != yr)
        out.append(dict(year=int(yr), beta=r['beta'], ci95=r['ci95'], decision=decide(r)))
    betas = [o['beta'] for o in out if o['beta'] is not None]
    return dict(min_beta=min(betas), max_beta=max(betas),
                years_changing_decision=[o['year'] for o in out if o['decision'] != base], per_year=out)


def interpret(r, decision, stacked):
    """Pre-specified reading of the primary result against the pilot. Never changes the decision."""
    if decision == 'NOT ESTIMABLE':
        return dict(reading='NOT ESTIMABLE')
    b, se = r['beta'], r['se']
    upper90 = b + Z95 * se
    d = b - PILOT['beta']; sd = math.sqrt(se ** 2 + PILOT['se'] ** 2)
    w1, w2 = 1 / PILOT['se'] ** 2, 1 / se ** 2
    pooled = (w1 * PILOT['beta'] + w2 * b) / (w1 + w2); pooled_se = 1 / math.sqrt(w1 + w2)
    small_telescopes_reject = upper90 < BETA33
    if decision == 'SUPPORTED':
        reading = 'REPLICATED'
    elif decision == 'CONTRADICTED':
        reading = 'CONTRADICTED (effect of the opposite sign)'
    elif small_telescopes_reject:
        reading = 'NOT REPLICATED (effect significantly smaller than the pilot could detect)'
    else:
        reading = 'INCONCLUSIVE (neither supported nor shown smaller than the pilot could detect)'
    return dict(reading=reading,
                per_tenfold_multiplier=10 ** b,
                small_telescopes=dict(beta33=BETA33, upper90=upper90, reject_beta_ge_beta33=bool(small_telescopes_reject)),
                independent=dict(note='assumes the two estimates are independent (they share 33 years)',
                                 diff=d, z=d / sd, p_two_sided=2 * (1 - phi(abs(d / sd))),
                                 pilot_beta_inside_ci95=bool(r['ci95'][0] <= PILOT['beta'] <= r['ci95'][1]),
                                 pooled_fixed_effect=dict(beta=pooled, se=pooled_se,
                                                          ci95=[pooled - Z * pooled_se, pooled + Z * pooled_se])),
                stacked_with_pilot=stacked)


def main():
    pred = pd.read_csv('predictors_blind.csv')
    pilot_ids = set(pd.read_csv(PILOT_TABLE, usecols=['fod_id'])['fod_id'].astype('int64'))
    overlap = pilot_ids & set(pred['fod_id'].astype('int64'))
    assert not overlap, f'{len(overlap)} pilot ignitions in the confirmatory table'
    out = pd.read_csv('outcomes.csv')
    df = pred.merge(out[['fod_id', 'fire_size']], on='fod_id', how='left')
    R = {'n_ignitions': int(len(pred)), 'n_with_outcome': int(df['fire_size'].notna().sum()), 'pilot_overlap': 0}
    R['n_missing_outcome'] = R['n_ignitions'] - R['n_with_outcome']
    # PRIMARY (the only confirmatory test)
    prim = fit(df, 'B', 'M2', boot=True)
    assert prim['defn'] == 'B' and prim['model'] == 'M2'
    R['primary_test'] = dict(hypothesis='H2', **prim)
    R['decision'] = decide(prim)
    stacked = stacked_with_pilot(df) if R['decision'] != 'NOT ESTIMABLE' else None
    R['interpretation'] = interpret(prim, R['decision'], stacked)
    # SECONDARY: everything the pilot reported, unchanged, then the confirmatory additions
    R['secondary_models'] = [fit(df, 'B', 'M1'), fit(df, 'A50', 'M1'), fit(df, 'A50', 'M2', boot=True),
                             fit(df, 'A25', 'M1'), fit(df, 'A25', 'M2')]
    R['secondary_decisions_not_confirmatory'] = {f"{r['defn']}_{r['model']}": decide(r) for r in R['secondary_models']}
    R['H3_escaped'] = [fit(df, d, 'M2', min_size=10) for d in ['A50', 'B']]
    R['H4_containment'] = [containment_perm(df, d) for d in ['A50', 'B']]
    S = []
    for d in ['A50', 'B']:
        S.append(dict(label='S1 snap on-holdable', **fit(df, d, 'M2', snap=True)))
        S.append(dict(label='S2 include censored', **fit(df, d, 'M2', include_censored=True)))
        S.append(dict(label='S3 drop coarse coords', **fit(df, d, 'M2', extra=lambda s: ~s['coarse_coords'].astype(bool))))
        S.append(dict(label='S6a natural cause (lightning)', **fit(df, d, 'M2', extra=lambda s: s['cause'] == 'Natural')))
        S.append(dict(label='S6b human cause', **fit(df, d, 'M2', extra=lambda s: s['cause'] == 'Human')))
        S.append(dict(label='S8 years >= 2010', **fit(df, d, 'M2', extra=lambda s: s['fire_year'] >= 2010)))
    S.append(dict(label='S5 B+ (prior 10-yr scars)', **fit(df, 'Bp', 'M2')))
    S += [fit_twoway(df, 'B'), fit_twoway(df, 'A50')]
    pc = json.load(open(PILOT_DIR + 'p1_config.json'))['compute_box_5070']
    outside_pilot = lambda s: ~((s['x'] >= pc[0]) & (s['x'] <= pc[2]) & (s['y'] >= pc[1]) & (s['y'] <= pc[3]))
    S.append(dict(label="S10 outside the pilot's compute box", **fit(df, 'B', 'M2', extra=outside_pilot)))
    S.append(dict(label='S11 no fuel-group term', **fit(df, 'B', 'M2', fes=('cause', 'month', 'fire_year'))))
    R['sensitivity'] = S
    R['leave_one_year_out'] = leave_one_year_out(df)
    json.dump(R, open('results.json', 'w'), indent=1)
    print('PRIMARY (B, M2):', R['decision'], '|', R['interpretation']['reading'])
    print(json.dumps(R['primary_test']))


if __name__ == '__main__':
    main()
