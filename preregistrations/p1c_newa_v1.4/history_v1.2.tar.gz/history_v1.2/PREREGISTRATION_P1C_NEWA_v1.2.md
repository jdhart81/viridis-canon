# Pre-registration: confirmatory replication in northeast Washington — do real fires stay smaller inside small compartments?

**Project:** P1C, the confirmatory replication of P1 ("Trees Cannot Cut on real fires").
**Version:** 1.2. It supersedes v1.0 and v1.1, both frozen and timestamped but never published (§0).
**Author:** Justin D. Hart (Viridis LLC). Analysis designed and run by Claude (Anthropic) under the author's direction.

**Status at freeze**
- **Not requested:** no FPA FOD fire size, size class or containment field for any ignition in this region has been requested or stored.
- **Exception, large-fire perimeters (MTBS):** during the pilot, their full attribute records were received for part of this region. Only geometry and year were kept. See "Known limits of blindness" in §3.
- **Frozen:** the plan, code, blind predictor table, raw inputs and logs are hash-frozen in `FREEZE.json`. It has been submitted to OpenTimestamps for Bitcoin timestamping.
- **Guarded:** `fetch_outcomes.py` requests outcomes only if three guards pass, re-run immediately before the request:
  - **G1:** every frozen file is unchanged;
  - **G2:** it downloads the public copy of this file and of `FREEZE.json` and finds them byte-identical;
  - **G3:** the sample shares no ignition with the pilot.

## 0. Version history

Each version was frozen with hashes and an OpenTimestamps submission. Each was then audited by a separate agent that had not built the study. Neither earlier version was published. Their plans, code and freeze records are kept in `history_v1.0/` and `history_v1.1/` and shipped with this package.

**v1.0**, frozen 2026-10-20 23:58:20 EDT (`FREEZE.json` sha256 `eef249f9…`). The audit's mechanical checks all passed. It found:
- **C1:** an inaccurate blindness statement about MTBS attributes.
- **M1:** a registration guard that trusted a local file.
- **M2:** the 33 years shared with the pilot were ignored.
- **M3:** unfrozen fetch evidence.
- **M4:** undisclosed post-fire map updates.
- **Minor issues.**

**v1.1**, frozen 2026-10-21 00:55:41 EDT (`efd026fd…`). It fixed those findings. It also changed the decision interval to t(0.975, G−1) × max(two-way SE, year SE), after a calibration with 20 km block-correlated errors showed the pilot's interval over-calls. Its audit confirmed the fixes and found:
- **Critical:** that calibration held only if spatial correlation stops at the 20 km block edges. The pilot's residuals stay correlated across block boundaries, with an exponential range of about 11–12 km. Under such errors the v1.1 rule over-calls at 6–8%.
- **Moderate:**
  - the pilot's multiplicity was misdescribed (§1);
  - S10 missed part of the MTBS exposure;
  - the frozen evidence was a curated subset;
  - v1.0's text was not shipped;
  - an intermediate decision rule and the exploratory calibration run were not disclosed.
- **Minor issues.**

**v1.2 fixes all of them.** Its decision rule uses a critical value calibrated by simulation under four spatial error models fitted to the pilot (§2).

**How the decision rule evolved, in full.** All of this happened before any outcome from this region existed:

| When (2026-10-21 ET) | Rule | What prompted it |
|---|---|---|
| v1.0 | β ± 1.96 × SE_year (the pilot's rule) | — |
| about 00:36 | β ± 1.96 × max(SE₂, SE_year) | 1,000-replicate block-correlated calibration of the pilot's rule (11.7% false calls) |
| 00:41 | t(0.975, 32) × max(SE₂, SE_year) | an exploratory 4,000-replicate run (`history_v1.1_dev/exploratory_bigcal.py`, seeds 30000+ and 40000+): 1.96 × max gave 5.75% iid and 6.4% block-correlated; t × max gave 4.65% and 5.6% |
| 00:50 | v1.1's validation tolerance of 0.065 set | between those figures |
| v1.2 | C2 × max(SE₂, SE_year), C2 = 2.31 | the second audit's continuous-field finding |

Every change widened the interval: none can make SUPPORTED easier on any dataset. The cost is that NOT REPLICATED also becomes harder to reach, which §2 discloses.

## 1. What is being replicated

**The pilot:**
- **Region and data:** Okanogan, Methow and Chelan, Washington; FPA FOD 1992–2024.
- **Freeze:** the plan was frozen at 20:13 ET on 2026-10-20, before any fire size was fetched.
- **The decisive test, H2:** compartment size predicts final fire size beyond barrier density and road distance.
- **The registered rule:** a 95% CI for each of two definitions, either one counting. The pilot's write-up later added a Bonferroni check at 0.025. That check was not registered and is post hoc.

| Pilot definition | β, log₁₀ size per log₁₀ compartment area (95% CI) | n | Verdict (registered rule) |
|---|---|---|---|
| B, mapped barriers | **0.063 (0.010, 0.117)**; cluster bootstrap (0.012, 0.120); p = 0.021 | 2,677 | SUPPORTED |
| A50, DNR control-location map (PCL > 0.5) | 0.169 (−0.012, 0.350) | 194 | not supported (underpowered) |

In words: a compartment ten times larger went with fires about 16% larger.

**The pilot re-read under this plan's approach.** This is exploratory, recorded as pilot Deviation 2 (`p1/DEVIATION_2.json`). The pilot's statistic is T = β / max(SE₂, SE_year) = 2.31. Simulated on the pilot's own design under the same four error models:

| Error model | p, two-sided | 5% critical value | 2.5% critical value |
|---|---|---|---|
| iid (reference) | 0.024 | 1.98 | 2.27 |
| 20 km blocks | 0.028 | 2.09 | 2.35 |
| exponential field (all pairs) | 0.027 | 2.08 | 2.35 |
| exponential field (cross-year pairs) | 0.027 | 2.03 | 2.35 |
| blocks + exponential field | 0.028 | 2.08 | 2.38 |

**So the pilot's evidence is weaker than its headline.**
- **At 5%:** its B result is SUPPORTED (T = 2.31 against 2.09) under the most conservative model.
- **At the post hoc Bonferroni level of 2.5%:** it is NOT SUPPORTED (against 2.38).

That is the reason this confirmatory test matters.

**What was known when this plan was written.** The pilot's outcomes were known, and they fix the hypothesis, the barrier definition and the model. No outcome from this region is known.

## 2. The single confirmatory test

**H2, definition B, model M2:** β(log₁₀ A_enc) > 0.

**Decision rule.** The interval is β ± C2 × max(SE₂, SE_year), with C2 = **2.31**, where:
- **SE₂** is the CR1 standard error two-way clustered by year and 20 km block (Cameron, Gelbach & Miller 2011);
- **SE_year** is the pilot's year-clustered CR1 standard error.

The verdicts:
- **SUPPORTED** if the interval lies entirely above 0.
- **CONTRADICTED** if it lies entirely below 0.
- **NOT SUPPORTED** otherwise.
- **NOT ESTIMABLE** if n ≤ k or fewer than 2 year clusters.

This is one test, so there is no multiplicity adjustment. Two other readings are reported but do not decide: the pilot's rule (1.96 × SE_year) and v1.1's rule (t(0.975, 32) × max SE).

**How C2 was set** (`calibrate_critical.py` → `CALIBRATION.json`).
- **Fitting the error models:** the pilot's B/M2 residuals give a spatial correlogram: correlation 0.080 at about 1 km, about 0.030 at 3–10 km, about 0.010 at 12–30 km and near 0 beyond 40 km; exponential fits give a correlated share of 0.053 with range 11.2 km (all pairs) and 0.050 with range 11.7 km (cross-year pairs). Four error models were fitted to it:
  - 20 km block effects (one-way ANOVA);
  - a persistent exponential random field fitted to all pairs;
  - the same field fitted to cross-year pairs;
  - block effects plus a field, fitted jointly.
- **Simulating:** under each model, 10,000 null outcomes were simulated on this region's blind design. C2 is the largest 95th percentile of |T| = |β| / max(SE₂, SE_year), rounded up. C1 is the same at the 90th percentile.
- **Checking:** the calibration was run twice, before and after C2 was written into `run_test.py`, with identical results (the first record is in `history_v1.1_dev/`). `validate_synthetic.py` then re-checked the rule on 10,000 fresh-seed nulls per model. Fresh-seed shares scatter by about ±0.4 points around their calibration values.

| Error model | Fitted parameters | 95th pct of \|T\| | False calls: pilot's rule | v1.1 rule | **this rule** (fresh seeds) |
|---|---|---|---|---|---|
| iid (reference) | — | 2.001 | 6.2% | 4.7% | **2.6%** |
| 20 km blocks | block share 0.062 | 2.064 | 12.2% | 5.3% | **2.9%** |
| exponential field (all pairs) | field share 0.053, range 11.2 km | 2.250 | 12.8% | 7.5% | **5.2%** |
| exponential field (cross-year pairs) | field share 0.050, range 11.7 km | 2.303 | 12.8% | 7.9% | **4.8%** |
| blocks + exponential field | block share 0.028; field share 0.021, range 15.3 km | 2.176 | 11.9% | 6.5% | **4.2%** |

The calibration depends on these models. A spatial structure unlike any of them, for example correlation at scales well beyond 40 km, could still inflate errors. The models were fitted to the pilot and not to this region, whose outcomes are unknown.

**Pre-specified reading.** These readings never change the decision.

| Reading | Condition |
|---|---|
| **REPLICATED** | SUPPORTED |
| **NOT REPLICATED** | NOT SUPPORTED, and the one-sided bound β + C1 × max(SE₂, SE_year), with C1 = **1.91**, is below β₃₃ = 0.0415 |
| **INCONCLUSIVE** | NOT SUPPORTED, otherwise |
| **CONTRADICTED** | CONTRADICTED |

**β₃₃** is the effect the pilot had 33% power to detect with its own rule: the small-telescopes benchmark (Simonsohn 2015, *Psychological Science* 26:559–569). The wider intervals make NOT REPLICATED harder to reach than under the pilot's rule. For a true null effect, simulated on this design: iid (reference): 0.82 under this plan's reading against 0.87 under the pilot's rule; 20 km blocks: 0.68 under this plan's reading against 0.79 under the pilot's rule; exponential field (all pairs): 0.70 under this plan's reading against 0.76 under the pilot's rule; blocks + exponential field: 0.71 under this plan's reading against 0.78 under the pilot's rule.

**Also reported (descriptive):** the difference from the pilot and the pooled estimate.
- **From a stacked model:** both samples in one block-diagonal regression, clustered across both regions by year and two-way.
- **Under independence:** for reference.

**Retrieval rules, registered.** Every requested fod_id must come back exactly once. Each record's fire_year, discovery_date, latitude and longitude must equal the frozen blind record. Otherwise outcomes.csv is not written, and the failure is resolved as a numbered deviation before any analysis. `run_test.py` refuses to run unless its inputs match `FREEZE.json` and outcomes.csv matches the hash recorded at fetch time.

## 3. Region, data and sample

**Region**
- **Analysis box:** lon −119.4 to −117.0, lat 47.75 to 49.0. It covers eastern Okanogan, Ferry, Stevens and Pend Oreille counties, the northern edges of Lincoln and Spokane counties, and a strip about 3 km wide of the Idaho panhandle at the east edge.
- **Compute box:** the analysis box plus 15 km, 7,885 × 6,849 cells at 30 m in EPSG:5070 (`p1_config.json`).
- **Why this region:** it adjoins the pilot to the east and has similar fuels and fire regimes. It was fixed before any data from it were fetched. It was also expected to be covered by the DNR PCL raster, but §5 shows large gaps.

**Data.** The sources are the pilot's.
- **Ignitions:** FPA FOD 7th edition (FPA_FOD_20260615; 1992–2024), USFS EDW `EDW_FireOccurrenceCurrentEdition_01`, layer 0. Only the allow-listed fields are requested: id, year, discovery date and day, cause, location, owner and agency.
- **Roads:** TIGER, vehicle MTFCC classes only.
- **Water:** NHD large-scale Area (FTYPE 460, 431) and Waterbody (390, 436, 378). The waterbodies were requested by FTYPE because the USGS server timed out on the full layer. The features used are the same.
- **Fuels:** LANDFIRE LF2024 FBFM40; non-burnable 91, 92, 93, 98, 99.
- **Control locations:** Washington DNR PCL raster.
- **Burn scars:** MTBS perimeters, geometry only, for B+.
- **Weather:** gridMET ERC-G as a per-cell percentile over 1992–2024.

`FETCH_PROVENANCE.md` records which code version fetched each input. `logs/transcript_tool_calls_p1c.jsonl` holds every command and code edit from 20:33 ET onward, with timestamps.

**Sample.** The sample is every FPA FOD record inside the closed lon/lat box above, judged by its own coordinates: 14,105 records. Any record also in the pilot table is removed by fod_id. No record needed removing: the two boxes meet only along the meridian at −119.4, and no record lies on it in both. The check runs anyway, in the build and in every guard. That leaves 14,105 ignitions:

| Cause | Ignitions |
|---|---|
| Natural | 4,779 |
| Human | 9,080 |
| Missing | 246 |

ERC is available for 100.0% of them.

**Possible cross-boundary duplicates.** 5 ignitions here have a pilot ignition on the same discovery date within 5 km (`EXPOSURE_LISTS.json`). If any is a duplicate report of the same fire, the pilot's outcomes would reveal its size. S12 drops them.

**Blindness, checked before the freeze** (`check_predictors.py`, all PASS):
- **P1:** no outcome field in the predictor table or the raw ignition records.
- **P2:** diagonal lines split 4-connected fuel.
- **P3:** edge-touching compartments are censored.
- **P4:** every layer is on the compute grid.
- **P5:** no pilot ignition is present, and the exclusion list is the frozen pilot table (sha256 `57118595…`).
- **P6:** the table equals the raw records inside the lon/lat box minus the pilot records.

**Known limits of blindness, disclosed:**
- **MTBS during the pilot.** The pilot fetched MTBS perimeters at 19:53 and 20:06, before this region was chosen at about 20:33. It requested all attributes, which include burned acreage, over the pilot's compute box. 63 of those 275 perimeters (61 from 1992–2024) reach into this region. The pilot code kept only geometry and year, and no attribute value was stored, printed or looked at.
  - **S10** drops the 1,697 ignitions inside the pilot's compute box.
  - **S10b** also drops those inside, or within 1 km of, any of the 63 perimeters: 1,888 ignitions, 703 of them outside the pilot box, so 2,400 dropped in all.
  - This region's own MTBS fetch requested geometry only (`fields='OBJECTID'`). The evidence is the command log `logs/tasks/bdqn7r65m.output` and the transcript record of that command.
- **MTBS geometry.** The perimeter polygons on disk encode the burned area of every large fire (≥ 1,000 acres). They were used only as barriers in B+, and never linked to ignitions or measured for that purpose. Beyond the count per year, the only computations on them were the 63/61 intersection counts and the S10b zone above.
- **The PCL raster.** It is a model product that may have been trained on fire perimeters that include this region. That is one reason A50 and A25 are secondary here. The other is power.
- **Post-fire map updates.** The maps are from 2024 and are applied to 1992–2024 fires.
  - **Fuels:** LANDFIRE updates fuels after disturbances, so for recent large fires the fuel group at the ignition cell partly reflects that fire's own aftermath. S11 drops the fuel-group term.
  - **Roads:** roads built after a fire, such as salvage roads, would make compartments around large past fires smaller. That works against the hypothesis.

## 4. Models and code, unchanged from the pilot

**Outcome:** Y = log₁₀(fire_size, acres).

**Models:**
- **M1:** Y ~ log₁₀ A_enc + ERC_pct + fuel group + cause + month + year (fixed effects).
- **M2:** M1 + log₁₀(ρ + 0.001) + log₁₀(road distance + 30 m).

**Estimation.** OLS. The decision interval is defined in §2. The pilot's year-clustered CR1 interval and a 2,000-replicate cluster bootstrap by year are reported alongside.

**Sample rules.** Records need fire_size > 0, ERC and month. Ignitions on holdable cells and censored compartments are excluded, per definition.

**Definitions:**
- **B (primary):** roads, water and non-burnable ground.
- **A50:** PCL > 0.5. **A25:** PCL > 0.25.
- **B+:** B plus MTBS scars from the 10 prior years.

All are exactly as in the pilot.

**Code identity, verified before the freeze** (`equivalence.py` → `EQUIVALENCE.json`):
- **`build_predictors.py`:** rebuilt the frozen pilot predictor table byte-for-byte (sha256 `57118595…`).
- **`run_test.py`:** replaying the pilot's call sequence with it reproduces all 233 numbers in the pilot's 23 reported outputs exactly. The v1.1 audit also rebuilt this region's table byte-for-byte from the frozen raw inputs. Its changes from the pilot code are listed in its header.

**Synthetic validation,** in a scratch directory with no real outcome present (`SYNTHETIC_VALIDATION.json`):
- **Planted effect:** β = 0.30 on B was recovered as 0.290 (interval 0.261–0.320) and called SUPPORTED.
- **One null draw** (seed 202) was recovered as −0.036 (interval −0.073 to 0.001) and called NOT SUPPORTED. One draw cannot measure an error rate; the calibration table above can.
- **Null check:** the registered rule's false-call share on fresh seeds is in the last column of the table in §2.
- **Pass criterion:** the planted effect is SUPPORTED, and the false-call share is at most 0.058 under every model, which is 5% plus 3.5 Monte Carlo SE. It passed.

## 5. Blind sample sizes and power

| Definition | Usable ignitions | Compartment area, log₁₀ acres (10th / 50th / 90th percentile) |
|---|---|---|
| B, mapped barriers (primary) | 11,314 | 2.41 / 3.63 / 4.46 |
| A50, PCL > 0.5 | 102 | −0.33 / 1.51 / 4.94 |
| A25, PCL > 0.25 | 712 | 1.00 / 3.26 / 4.40 |
| B+, B plus prior scars | 11,105 | 2.39 / 3.59 / 4.43 |

"Usable" counts records that pass every predictor-based rule. The one outcome-based rule, fire_size > 0, removed no record in the pilot.

S10 keeps 9,941 usable B ignitions. S10b keeps 9,368.

The DNR PCL raster has no-data gaps across much of this region, so almost every A50 and A25 compartment touches no-data and is censored. Those two definitions are reported, but they carry little information here. Definition B does not depend on PCL.

**Power of the registered rule.** This is P(SUPPORTED), simulated on this region's blind design with 4,000 replicates per cell (`BLIND_DESIGN.json`).

| Error model | β = 0.063 (pilot) | β = 0.0415 (β₃₃) | β = 0.032 (half the pilot) |
|---|---|---|---|
| iid (reference) | 0.98 | 0.70 | 0.43 |
| 20 km blocks | 0.92 | 0.56 | 0.33 |
| exponential field (all pairs) | 0.92 | 0.61 | 0.40 |
| blocks + exponential field | 0.93 | 0.59 | 0.38 |

**For reference:**
- the analytic iid SE on this design is 0.0143 (n = 11,314);
- the residual SD of log₁₀ A_enc given the other M2 terms is 0.711 (pilot: 0.813).

The pilot estimate cleared p < 0.05, so the winner's curse applies, and its value is probably inflated. The β₃₃ and half-pilot columns are the honest planning numbers.

## 6. Secondary analyses (reported in full, not confirmatory)

**As in the pilot:**
- **H1:** M1 for B and A50.
- **A50 under M2**, with the bootstrap.
- **A25** under M1 and M2.
- **H3:** M2 on fires of at least 10 acres, for A50 and B.
- **H4:** among fires of at least 10 acres, the share with final size ≤ A_enc, against 10,000 permutations within year × fuel-group strata, for A50 and B.
- **Sensitivity, for A50 and B:**
  - S1: snap on-holdable ignitions;
  - S2: include censored compartments;
  - S3: drop coarse coordinates;
  - S6a: lightning, meaning NWCG cause "Natural";
  - S6b: human;
  - S8: 2010 and later.
- **S5:** B+.

**New in the confirmatory plan.** Each of these is reported with the registered interval.
- **S9:** the two-way clustered interval for A50.
- **S10:** without the pilot's compute box.
- **S10b:** also without the 63 pilot-fetched perimeters.
- **S11:** no fuel-group term.
- **S12:** without the possible duplicates.
- **Leave-one-year-out:** the primary estimate and decision with each year removed in turn. Any year whose removal changes the decision will be named.
- **Stacked model** with the pilot (§2).

## 7. Known threats

**Same as the pilot:**
- **Suppression access:** handled by road distance, density and the lightning-only analysis.
- **Anachronism and post-fire map updates:** see §3, S8 and S11.
- **Location precision:** see S3.

**New here:**
- **Spatial correlation.** It is handled by the two-way SE and the simulation-calibrated C2 (§2). Structures outside the four fitted models remain a residual risk.
- **The 33 shared years.** The stacked model handles them for the comparison with the pilot. The replication's own test does not depend on them.
- **Landscape overlap with the pilot.** 208 of 11,314 usable B ignitions share a compartment with a pilot ignition. They are disjoint by ignition, but not entirely by landscape.
- **More wildland–urban interface near Spokane.** M2's road and density controls apply, and S6 splits by cause.
- **Reporting agencies.** Agency is not in the model, as in the pilot.

## 8. Freeze, timestamp and registration

**Frozen files:** everything listed in `FREEZE.json`:
- this file, its template and the README;
- all code;
- the blind predictor table and the configuration;
- every raw input and the request log. `raw/requests.log` lists only completed requests.
- every fetch, retry and chain log, and every command log of this session's background jobs (`logs/tasks/`);
- the transcript extract;
- the calibration, exposure, equivalence, design, validation and check records;
- the pilot files this test reads or cites: its predictor table, outcomes, configuration, results, Deviation 2, MTBS perimeters and request log;
- the v1.0 and v1.1 freeze records, and v1.1's development files (`history_v1.1_dev/`).

**Timestamp.** `FREEZE.json` was submitted to OpenTimestamps calendars, with Bitcoin confirmation pending at freeze. The upgraded proof will be added once it is confirmed.

**Public registration.** This folder will be published under the author's account. Zenodo is preferred: G2's GitHub check runs through the environment's HTTPS proxy, and GitHub commits can later be deleted. `fetch_outcomes.py` verifies the public copy itself before requesting any outcome. Afterwards it writes `OUTCOME_FETCH.json` and stamps it with OpenTimestamps. That record holds:
- the downloaded hashes;
- the counts;
- the service metadata;
- the outcome and log hashes.

## 9. Deviations

Any change after the freeze is reported as a numbered deviation, with its date and reason.
