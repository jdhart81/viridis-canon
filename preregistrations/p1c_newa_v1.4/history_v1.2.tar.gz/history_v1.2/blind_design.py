#!/usr/bin/env python3
"""Blind design summary for the confirmatory pre-registration. Reads predictors only; no outcome exists on disk.

Writes BLIND_DESIGN.json with:
  - sample sizes per definition after every predictor-based filter (the only outcome-based filter,
    fire_size > 0, removed no record in the pilot);
  - predicted standard error and power for the primary test (B, M2), from the pilot's residual SD and
    design effect applied to THIS region's blind design matrix, checked by a Monte Carlo on that matrix;
  - how many usable confirmatory ignitions share a B compartment with a pilot ignition (landscape overlap).
"""
import importlib.util, json, math
import numpy as np
import pandas as pd

spec = importlib.util.spec_from_file_location('rt', 'run_test.py'); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
CFG = json.load(open('p1_config.json'))
# Pilot quantities for B, M2 (from the pilot's own data and the frozen pilot code; see the prereg, section 4)
PILOT = dict(n=2677, beta=0.06317647448409425, se_cr1=0.027318251774805232, se_iid=0.02567459347212416,
             deff=1.064018863802679, sigma=1.0797053862182389, sd_resid_log10Aenc=0.8127884182365132)

pred = pd.read_csv('predictors_blind.csv')
assert not ({'fire_size', 'fire_size_class'} & set(pred.columns))
df = pred.assign(fire_size=1.0)      # placeholder so sample() applies only predictor-based filters
D = dict(n_table=int(len(pred)), years=[int(pred.fire_year.min()), int(pred.fire_year.max())],
         cause={str(k): int(v) for k, v in pred['cause'].value_counts(dropna=False).items()},
         erc_available=round(float(pred['erc_pct'].notna().mean()), 4), usable={})
for d in ['A50', 'A25', 'B', 'Bp']:
    s, a = rt.sample(df, d)
    D['usable'][d] = dict(n=int(len(s)), log10_Aenc_acres_q10_q50_q90=[round(float(v), 2) for v in np.log10(s[a]).quantile([.1, .5, .9])])

# Power for the primary test
s, a = rt.sample(df, 'B'); X = rt.design(s, a, 'rho_B', 'M2')
others = [c for c in X.columns if c != 'log10_Aenc']
Z = X[others].values.astype(float); xa = X['log10_Aenc'].values
resid = xa - Z @ np.linalg.lstsq(Z, xa, rcond=None)[0]
n, sdres = len(s), float(resid.std(ddof=0))


def power(beta, se):
    """P(SUPPORTED): the probability that the 95% CI lies entirely above 0 when the true slope is beta."""
    return rt.phi(beta / se - 1.96)


scen = {'base: pilot residual SD and design effect': (PILOT['sigma'], PILOT['deff']),
        'pessimistic: residual SD +15%, design effect 1.5': (PILOT['sigma'] * 1.15, 1.5)}
betas = {'pilot estimate 0.063': PILOT['beta'], 'beta33 0.0415 (small-telescopes benchmark)': rt.BETA33,
         'half the pilot estimate 0.032': PILOT['beta'] / 2}
D['power_primary'] = dict(n_usable_B=n, k_columns=int(X.shape[1]), sd_resid_log10Aenc=sdres,
                          pilot_sd_resid_log10Aenc=PILOT['sd_resid_log10Aenc'], scenarios={})
for name, (sig, deff) in scen.items():
    se = deff * sig / (math.sqrt(n) * sdres)
    D['power_primary']['scenarios'][name] = dict(predicted_se=se, power={k: round(power(b, se), 3) for k, b in betas.items()})

# Simulated power of the REGISTERED rule (beta +- C2 * max SE) on this design, under the calibration error models
# (simcal.py, CALIBRATION.json): P(SUPPORTED) at three slopes, 4,000 replicates per cell
import sys as _sys, os as _os
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import simcal
CAL = json.load(open('CALIBRATION.json'))
assert rt.C2 == CAL['C2'], 'run_test.py C2 differs from CALIBRATION.json'
Dd = simcal.Design(rt, pred); es = pred['erc_pct'].fillna(0.5).values[Dd.pos]
xs, ys = pred['x'].values[Dd.pos].astype(float), pred['y'].values[Dd.pos].astype(float)
sim = {}
for mi, name in enumerate(['iid', 'block', 'exp_all', 'block_exp']):
    mod = {kk: CAL['models'][name][kk] for kk in ('var_total', 'block_share', 'field_share', 'range_km') if kk in CAL['models'][name]}
    sim[name] = {}
    for bi, (k, b) in enumerate(betas.items()):
        Bh, SY, SM = simcal.sim_stats(Dd, xs, ys, es, mod, 4000, 30_000_000 + 1_000_000 * mi + 10_000 * bi, beta=b)
        sim[name][k] = float(np.mean(Bh - rt.C2 * SM > 0))
D['power_primary']['simulated_registered_rule'] = dict(reps=4000, C2=rt.C2, power_P_SUPPORTED=sim)
# P(NOT REPLICATED) under a true null, registered reading (C2, C1 with max SE) vs the pilot's rule (1.96 / 1.645 year SE)
notrep = {}
for mi, name in enumerate(['iid', 'block', 'exp_all', 'block_exp']):
    mod = {kk: CAL['models'][name][kk] for kk in ('var_total', 'block_share', 'field_share', 'range_km') if kk in CAL['models'][name]}
    Bh, SY, SM = simcal.sim_stats(Dd, xs, ys, es, mod, 4000, 40_000_000 + 1_000_000 * mi, beta=0.0)
    reg = np.mean((np.abs(Bh) <= rt.C2 * SM) & (Bh + rt.C1 * SM < rt.BETA33))
    pil = np.mean((np.abs(Bh) <= 1.96 * SY) & (Bh + 1.6448536269514722 * SY < rt.BETA33))
    notrep[name] = dict(registered=float(reg), pilot_rule=float(pil))
D['power_primary']['p_not_replicated_under_null'] = dict(reps=4000, by_model=notrep)

# S10 sample: usable B ignitions outside the pilot's compute box (where the pilot's MTBS fetch reached)
pc = json.load(open('../p1/p1_config.json'))['compute_box_5070']
inside = (s['x'] >= pc[0]) & (s['x'] <= pc[2]) & (s['y'] >= pc[1]) & (s['y'] <= pc[3])
EXL = json.load(open('EXPOSURE_LISTS.json'))
D['s10b_usable_B'] = int((~inside & ~s['fod_id'].isin(set(EXL['s10b']['fod_ids_inside_perimeters']))).sum())
D['s12_usable_B'] = int((~s['fod_id'].isin(set(EXL['s12']['fod_ids']))).sum())
D['s10_outside_pilot_compute_box'] = dict(usable_B=int((~inside).sum()), usable_B_inside=int(inside.sum()),
                                          all_ignitions_inside=int(((pred.x >= pc[0]) & (pred.x <= pc[2]) & (pred.y >= pc[1]) & (pred.y <= pc[3])).sum()))

# Monte Carlo on the real blind design (iid normal errors with the pilot residual SD): checks the analytic SE
rng = np.random.default_rng(7)
Xv = X.values.astype(float); XtX_inv = np.linalg.pinv(Xv.T @ Xv); j = list(X.columns).index('log10_Aenc')
g = s['fire_year'].values; G = pd.unique(g); kk = Xv.shape[1]
cfac = len(G) / (len(G) - 1) * (n - 1) / (n - kk)
rej, ses = 0, []
for _ in range(400):
    y = PILOT['beta'] * xa + rng.normal(0, PILOT['sigma'], n)
    b = XtX_inv @ Xv.T @ y; e = y - Xv @ b
    meat = np.zeros((kk, kk))
    for gg in G:
        sc = Xv[g == gg].T @ e[g == gg]; meat += np.outer(sc, sc)
    se = math.sqrt(cfac * (XtX_inv @ meat @ XtX_inv)[j, j]); ses.append(se)
    rej += (b[j] - 1.96 * se) > 0
D['power_primary']['monte_carlo_iid'] = dict(reps=400, beta=PILOT['beta'], rejection_rate=rej / 400,
                                             mean_cr1_se=float(np.mean(ses)),
                                             analytic_iid_se=PILOT['sigma'] / (math.sqrt(n) * sdres))

# Landscape overlap with the pilot: confirmatory B compartments that also contain a pilot ignition
z = np.load('compartments_static.npz'); labB = z['labB']
X0, Y0, X1, Y1 = CFG['compute_box_5070']; H, W = CFG['H'], CFG['W']
pil = pd.read_csv(CFG['exclude_fod_ids_from'], usecols=['x', 'y'])
r = ((Y1 - pil['y'].values) // 30).astype(int); c = ((pil['x'].values - X0) // 30).astype(int)
ok = (r >= 0) & (r < H) & (c >= 0) & (c < W)
shared = set(np.unique(labB[r[ok], c[ok]]).tolist()) - {0}
sB, _ = rt.sample(df, 'B')
k_conf = labB[sB['row'].values, sB['col'].values]
D['landscape_overlap'] = dict(pilot_ignitions_inside_confirmatory_grid=int(ok.sum()),
                              usable_B_ignitions_sharing_a_compartment_with_a_pilot_ignition=int(np.isin(k_conf, list(shared)).sum()),
                              usable_B_ignitions=int(len(sB)))
import hashlib
D['code_sha256'] = {f: hashlib.sha256(open(f, 'rb').read()).hexdigest() for f in ('run_test.py', 'simcal.py', 'blind_design.py', 'predictors_blind.csv', 'CALIBRATION.json')}
json.dump(D, open('BLIND_DESIGN.json', 'w'), indent=1)
print(json.dumps(D, indent=1))
