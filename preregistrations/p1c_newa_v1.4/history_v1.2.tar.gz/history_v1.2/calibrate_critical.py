#!/usr/bin/env python3
"""Calibrate the decision rule's critical values by simulation (plan v1.2). Writes CALIBRATION.json.

Statistic: T = beta / max(SE_twoway, SE_year) for the B/M2 compartment slope.
Null outcomes are simulated on THIS region's blind design under error models fitted to the PILOT's B/M2 residuals:
  iid             no spatial correlation (reference)
  block           20 km block random effects, variance from one-way ANOVA (as in plan v1.1)
  exp_all         persistent exponential random field fitted to the correlogram of all pilot residual pairs
  exp_cross       the same, fitted to cross-year pairs only (the part year clustering cannot absorb)
  block_exp       block effects plus an exponential field, fitted jointly to cross-year pairs
The registered critical values are the MAXIMUM over the four spatial models, rounded UP to 2 decimals:
  C2 = 95th percentile of |T|  (two-sided 5%: the decision interval beta +- C2 * max SE)
  C1 = 90th percentile of |T|  (one-sided 5%: the bound used by the NOT REPLICATED reading)
The same simulation on the PILOT's own design gives the pilot's p-value and 5% / 2.5% critical values under each
model, for the plan's re-reading of the pilot. No confirmatory outcome is used anywhere.
Usage: python3 calibrate_critical.py   (about 15 minutes)"""
import hashlib, importlib.util, json, math, os, sys, time
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import simcal  # noqa: E402

spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))
t0 = time.time()
cg = simcal.pilot_correlogram(rt)
vc = simcal.pilot_variance_components(rt)
TOT = cg['total_var']
s_all, r_all = simcal.fit_exponential(cg['all'])
s_cr, r_cr = simcal.fit_exponential(cg['cross'])
b_be, s_be, r_be = simcal.fit_block_plus_exponential(cg['cross_same'], cg['cross_diff'])
MODELS = {
    'iid': dict(var_total=TOT, range_km=10.0),
    'block': dict(var_total=TOT, block_share=vc['var_block'] / (vc['var_block'] + vc['var_within']), range_km=10.0),
    'exp_all': dict(var_total=TOT, field_share=s_all, range_km=r_all),
    'exp_cross': dict(var_total=TOT, field_share=s_cr, range_km=r_cr),
    'block_exp': dict(var_total=TOT, block_share=b_be, field_share=s_be, range_km=r_be),
}
SPATIAL = ['block', 'exp_all', 'exp_cross', 'block_exp']


def run(pred, reps, seed_base):
    D = simcal.Design(rt, pred)
    xs, ys = pred['x'].values[D.pos].astype(float), pred['y'].values[D.pos].astype(float)
    es = pred['erc_pct'].fillna(0.5).values[D.pos]
    out = {}
    for k, (name, m) in enumerate(MODELS.items()):
        Tm, Ty = simcal.null_t(D, xs, ys, es, m, reps, seed_base + 100000 * k)
        out[name] = dict(Tm=Tm, Ty=Ty)
    return D, out


pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
D, sims = run(pred, 10000, 5_000_000)
res = {'models': {k: dict(v) for k, v in MODELS.items()}, 'confirmatory_design': dict(n=D.n, blocks=D.nblocks, dof=D.dof, t_crit=D.t)}
for name, s in sims.items():
    a = np.abs(s['Tm'])
    res['models'][name].update(
        q90_absT=float(np.quantile(a, 0.90)), q95_absT=float(np.quantile(a, 0.95)),
        false_call_share_v11_rule=float(np.mean(a > D.t)), false_call_share_pilot_rule=float(np.mean(np.abs(s['Ty']) > 1.96)),
        reps=len(a))
C2 = math.ceil(max(res['models'][m]['q95_absT'] for m in SPATIAL) * 100) / 100
C1 = math.ceil(max(res['models'][m]['q90_absT'] for m in SPATIAL) * 100) / 100
res['C2'] = C2; res['C1'] = C1
for name, s in sims.items():
    res['models'][name]['false_call_share_C2_rule'] = float(np.mean(np.abs(s['Tm']) > C2))
# The pilot under each model, on its own design
pp = pd.read_csv('/home/claude/p1/predictors_blind.csv')
Dp, psims = run(pp, 5000, 9_000_000)
T_obs = 0.06317647448409425 / 0.027318251774805232            # pilot beta / max(two-way SE 0.0234, year SE 0.0273)
res['pilot_reread'] = dict(T_obs=T_obs, design=dict(n=Dp.n, blocks=Dp.nblocks, dof=Dp.dof), models={})
for name, s in psims.items():
    a = np.abs(s['Tm'])
    res['pilot_reread']['models'][name] = dict(p_two_sided=float(np.mean(a >= T_obs)), c_5pct=float(np.quantile(a, 0.95)),
                                               c_2p5pct=float(np.quantile(a, 0.975)), reps=len(a))
res['correlogram'] = {k: (v.tolist() if hasattr(v, 'tolist') else v) for k, v in cg.items()}
res['fits'] = dict(exp_all=dict(share=s_all, range_km=r_all), exp_cross=dict(share=s_cr, range_km=r_cr),
                   block_exp=dict(block_share=b_be, field_share=s_be, range_km=r_be), anova=vc)
res['code_sha256'] = {f: hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
                      for f in ('run_test.py', 'simcal.py', 'calibrate_critical.py', 'predictors_blind.csv')}
res['seconds'] = round(time.time() - t0)
json.dump(res, open(os.path.join(HERE, 'CALIBRATION.json'), 'w'), indent=1)
print(json.dumps({k: res[k] for k in ('C2', 'C1', 'confirmatory_design')}, indent=1))
for name, m in res['models'].items():
    print(f"{name:10s} q95|T| {m['q95_absT']:.3f}  q90|T| {m['q90_absT']:.3f}  false calls: pilot rule {m['false_call_share_pilot_rule']:.3f}, "
          f"v1.1 rule {m['false_call_share_v11_rule']:.3f}, C2 rule {m['false_call_share_C2_rule']:.3f}")
for name, m in res['pilot_reread']['models'].items():
    print(f"pilot {name:10s} p {m['p_two_sided']:.4f}  c5% {m['c_5pct']:.3f}  c2.5% {m['c_2p5pct']:.3f}")
