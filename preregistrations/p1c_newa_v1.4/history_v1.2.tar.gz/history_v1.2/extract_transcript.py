#!/usr/bin/env python3
"""Write logs/transcript_tool_calls_p1c.jsonl: every shell command and file edit in this session's transcript that
touches the P1C (or pilot) files, with its timestamp, so the history of the code and of each fetch can be read
directly. The session transcript begins at 2026-10-21T00:33Z (20:33 ET); earlier work is documented by the logs and
by the pilot's raw request log. Invocations of this script itself are skipped."""
import json, re
SRC = '/root/.claude/projects/-home-claude/d23d759f-9c1b-589b-9849-6bba926e6bc3.jsonl'
pat = re.compile(r'p1c|/p1/|\.\./p1|p1_config|fetch_data|build_predictors|run_test|run_chain|simcal|freeze\.py|equivalence|'
                 r'validate_synthetic|blind_design|fill_prereg|fetch_outcomes|PREREG|history_v1|calibrate_critical|exposure_lists')
rows = []
for line in open(SRC):
    try:
        o = json.loads(line)
    except Exception:
        continue
    m = o.get('message') or {}
    for c in (m.get('content') if isinstance(m.get('content'), list) else []):
        if isinstance(c, dict) and c.get('type') == 'tool_use' and c.get('name') in ('Bash', 'Edit', 'Write'):
            s = json.dumps(c.get('input'))
            if pat.search(s) and 'extract_transcript' not in s and 'transcript_tool_calls' not in s:
                rows.append(dict(timestamp=o.get('timestamp'), tool=c['name'], input=c['input']))
with open('logs/transcript_tool_calls_p1c.jsonl', 'w') as fh:
    for r in rows:
        fh.write(json.dumps(r) + '\n')
print(len(rows), 'tool calls', rows[0]['timestamp'], '->', rows[-1]['timestamp'])
