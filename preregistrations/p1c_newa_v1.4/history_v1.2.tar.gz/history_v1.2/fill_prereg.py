#!/usr/bin/env python3
"""Fill PREREG_TEMPLATE.md with numbers computed from files (no hand transcription) and write
PREREGISTRATION_P1C_NEWA_v1.2.md. Reads only predictor-side files and simulation records (no confirmatory outcome)."""
import json, re
import pandas as pd

cfg = json.load(open('p1_config.json'))
D = json.load(open('BLIND_DESIGN.json'))
S = json.load(open('SYNTHETIC_VALIDATION.json'))
E = json.load(open('EQUIVALENCE.json'))
CAL = json.load(open('CALIBRATION.json'))
EX = json.load(open('EXPOSURE_LISTS.json'))
assert S['pass'] and E['build']['identical'] and E['model']['identical']
raw = json.load(open('raw/fpafod_ignitions_blind.json'))
pilot = set(pd.read_csv(cfg['exclude_fod_ids_from'], usecols=['fod_id'])['fod_id'].astype('int64'))
LON0, LAT0, LON1, LAT1 = cfg['analysis_box_lonlat']
inbox = [f for f in raw if (f.get('geometry') or {}).get('x') is not None
         and LON0 <= f['attributes']['longitude'] <= LON1 and LAT0 <= f['attributes']['latitude'] <= LAT1]
excl = [f for f in inbox if int(float(f['attributes']['fod_id'])) in pilot]
assert D['n_table'] == len(inbox) - len(excl), (D['n_table'], len(inbox), len(excl))
if not excl:
    excl_sentence = ('No record needed removing: the two boxes meet only along the meridian at −119.4, and no '
                     'record lies on it in both. The check runs anyway, in the build and in every guard.')
else:
    excl_sentence = f'{len(excl):,} records were removed, on the shared boundary.'
cause = D['cause']
fmt = lambda v: f'{v:,}'
pct = lambda v: f'{100 * v:.1f}%'
P = D['power_primary']
usable_rows = '\n'.join(
    f"| {name} | {fmt(D['usable'][k]['n'])} | " + ' / '.join(f'{q:.2f}' for q in D['usable'][k]['log10_Aenc_acres_q10_q50_q90']) + ' |'
    for k, name in [('B', 'B, mapped barriers (primary)'), ('A50', 'A50, PCL > 0.5'), ('A25', 'A25, PCL > 0.25'), ('Bp', 'B+, B plus prior scars')])
LABEL = {'iid': 'iid (reference)', 'block': '20 km blocks', 'exp_all': 'exponential field (all pairs)',
         'exp_cross': 'exponential field (cross-year pairs)', 'block_exp': 'blocks + exponential field'}
sim = P['simulated_registered_rule']['power_P_SUPPORTED']
power_rows = '\n'.join(f"| {LABEL[name]} | " + ' | '.join(f'{v:.2f}' for v in vals.values()) + ' |' for name, vals in sim.items())


def params(name, m):
    if name == 'iid':
        return '—'
    out = []
    if m.get('block_share'):
        out.append(f"block share {m['block_share']:.3f}")
    if m.get('field_share'):
        out.append(f"field share {m['field_share']:.3f}, range {m['range_km']:.1f} km")
    return '; '.join(out)


chk = S['null_check_fresh_seeds']['models']
cal_rows = '\n'.join(
    f"| {LABEL[name]} | {params(name, m)} | {m['q95_absT']:.3f} | {pct(m['false_call_share_pilot_rule'])} | "
    f"{pct(m['false_call_share_v11_rule'])} | **{pct(chk[name]['registered_rule'])}** |"
    for name, m in CAL['models'].items())
cg = CAL['correlogram']['all']
pick = lambda lo, hi: [r[1] for r in cg if lo <= r[0] < hi]
mean = lambda v: sum(v) / len(v)
f = CAL['fits']
corr_text = (f"correlation {mean(pick(0, 1.5)):.3f} at about 1 km, about {mean(pick(2.5, 10.5)):.3f} at 3–10 km, about "
             f"{mean(pick(12, 31)):.3f} at 12–30 km and near 0 beyond 40 km; exponential fits give a correlated share of "
             f"{f['exp_all']['share']:.3f} with range {f['exp_all']['range_km']:.1f} km (all pairs) and {f['exp_cross']['share']:.3f} "
             f"with range {f['exp_cross']['range_km']:.1f} km (cross-year pairs)")
PR = CAL['pilot_reread']
spatial = ['block', 'exp_all', 'exp_cross', 'block_exp']
pilot_rows = '| Error model | p, two-sided | 5% critical value | 2.5% critical value |\n|---|---|---|---|\n' + '\n'.join(
    f"| {LABEL[name]} | {m['p_two_sided']:.3f} | {m['c_5pct']:.2f} | {m['c_2p5pct']:.2f} |" for name, m in PR['models'].items())
c5 = max(PR['models'][m]['c_5pct'] for m in spatial); c25 = max(PR['models'][m]['c_2p5pct'] for m in spatial)
verdict = lambda c: 'SUPPORTED' if PR['T_obs'] > c else 'NOT SUPPORTED'
nr = P['p_not_replicated_under_null']['by_model']
notrep_text = '; '.join(f"{LABEL[k]}: {v['registered']:.2f} under this plan's reading against {v['pilot_rule']:.2f} under the pilot's rule"
                        for k, v in nr.items())
s10b = EX['s10b']
fill = {
    'W': fmt(cfg['W']), 'H': fmt(cfg['H']), 'N_RAW': fmt(len(inbox)), 'EXCL_SENTENCE': excl_sentence,
    'N_TABLE': fmt(D['n_table']), 'N_NAT': fmt(cause.get('Natural', 0)), 'N_HUM': fmt(cause.get('Human', 0)),
    'N_MISS': fmt(sum(v for k, v in cause.items() if k not in ('Natural', 'Human'))),
    'ERC_AVAIL': pct(D['erc_available']),
    'SYN_PLANT': f"{S['planted']['beta']:.3f} (interval {S['planted']['interval_registered'][0]:.3f}–{S['planted']['interval_registered'][1]:.3f})",
    'SYN_PLANT_DEC': S['planted']['decision'],
    'SYN_NULL': f"{S['null']['beta']:.3f} (interval {S['null']['interval_registered'][0]:.3f} to {S['null']['interval_registered'][1]:.3f})",
    'SYN_NULL_DEC': S['null']['decision'],
    'C2': f"{CAL['C2']:.2f}", 'C1': f"{CAL['C1']:.2f}", 'CAL_ROWS': cal_rows, 'CORR_TEXT': corr_text,
    'PILOT_T': f"{PR['T_obs']:.2f}", 'PILOT_REREAD_ROWS': pilot_rows,
    'PILOT_5_VERDICT': f"{verdict(c5)} (T = {PR['T_obs']:.2f} against {c5:.2f})",
    'PILOT_25_VERDICT': f"{verdict(c25)} (against {c25:.2f})",
    'NOTREP_TEXT': notrep_text,
    'USABLE_ROWS': usable_rows, 'N_B': fmt(P['n_usable_B']), 'SDRES': f"{P['sd_resid_log10Aenc']:.3f}",
    'AN_SE': f"{P['monte_carlo_iid']['analytic_iid_se']:.4f}", 'POWER_ROWS_SIM': power_rows,
    'N_S10': fmt(D['s10_outside_pilot_compute_box']['usable_B']), 'N_S10_ALL': fmt(s10b['n_inside_pilot_box']),
    'N_S10B': fmt(D['s10b_usable_B']), 'N_PERIM_IN': fmt(s10b['n_inside_perimeters']),
    'N_PERIM_OUT_BOX': fmt(s10b['n_inside_perimeters_outside_pilot_box']), 'N_S10B_DROP': fmt(s10b['n_dropped_s10b']),
    'N_DUP': fmt(len(EX['s12']['fod_ids'])),
    'N_SHARED': fmt(D['landscape_overlap']['usable_B_ignitions_sharing_a_compartment_with_a_pilot_ignition']),
    'EQ_VALUES': fmt(E['model']['values_compared']), 'EQ_OUTPUTS': str(E['model']['outputs_compared']),
}
t = open('PREREG_TEMPLATE.md').read()
for k, v in fill.items():
    t = t.replace('{{' + k + '}}', re.sub(r'(?<![\w.])-(?=\d)', '−', v))   # typographic minus for negatives
left = re.findall(r'\{\{[A-Z0-9_]+\}\}', t)
assert not left, left
open('PREREGISTRATION_P1C_NEWA_v1.2.md', 'w').write(t)
print('written; pilot at 5%:', verdict(c5), c5, '| at 2.5%:', verdict(c25), c25)
