#!/usr/bin/env python3
"""Fast simulations of the registered decision rules on a fixed blind design, for calibration and power.

Design() reproduces, for the B/M2 compartment slope, the exact arithmetic of run_test.fit (year-only CR1) and
run_test.fit_twoway (two-way CR1 by year and 20 km block, with the same fallback); callers check this against
run_test on the first replicates. pilot_variance_components() estimates, from the PILOT's B/M2 residuals (pilot
outcomes are already known), how much residual variance is shared within 20 km blocks (one-way ANOVA, method of
moments). No confirmatory outcome is used anywhere."""
import math
import numpy as np


class Design:
    def __init__(self, rt, pred, block_m=20000):
        s, a = rt.sample(pred.assign(fire_size=1.0), 'B')
        X = rt.design(s, a, 'rho_B', 'M2')
        self.Xv = X.values.astype(float); self.n, self.k = self.Xv.shape
        self.XtX_inv = np.linalg.pinv(self.Xv.T @ self.Xv)
        self.h = self.Xv @ self.XtX_inv[:, list(X.columns).index('log10_Aenc')]
        self.pos = pred.index.get_indexer(s.index)
        self.la = np.log10(s[a].values)
        g = s['fire_year'].astype(str).values
        blk = ((s['x'] // block_m).astype(int).astype(str) + '_' + (s['y'] // block_m).astype(int).astype(str)).values
        _, self.yinv = np.unique(g, return_inverse=True)
        _, self.binv = np.unique(blk, return_inverse=True)
        _, self.ybinv = np.unique(np.char.add(np.char.add(g, '|'), blk), return_inverse=True)
        self.nblocks = int(self.binv.max() + 1)
        self.dof = int(min(self.yinv.max() + 1, self.nblocks) - 1)
        self.t = rt.t_crit(self.dof)
        c = lambda inv: (inv.max() + 1) / inv.max() * (self.n - 1) / (self.n - self.k)
        self.cY, self.cB, self.cYB = c(self.yinv), c(self.binv), c(self.ybinv)

    def stats(self, y):
        """beta, year-only SE, two-way SE, max SE for outcome vector y (sample rows, in sample order)."""
        bj = float(self.h @ y)
        e = y - self.Xv @ (self.XtX_inv @ (self.Xv.T @ y)); w = self.h * e
        vy = self.cY * float((np.bincount(self.yinv, weights=w) ** 2).sum())
        vb = self.cB * float((np.bincount(self.binv, weights=w) ** 2).sum())
        vyb = self.cYB * float((np.bincount(self.ybinv, weights=w) ** 2).sum())
        v2 = vy + vb - vyb
        if v2 <= 0:
            v2 = max(vy, vb)
        sy, s2 = math.sqrt(vy), math.sqrt(v2)
        return bj, sy, s2, max(sy, s2)


def simulate(D, erc_sample, beta, reps, seed0, var_block=0.0, var_within=1.08 ** 2):
    """Outcome = beta * log10 Aenc + 0.5 * erc_pct + block effect + noise; returns call shares per rule:
    primary  = the registered P1C rule, beta +- t(0.975, G-1) * max(two-way SE, year-only SE);
    pilot    = the pilot's rule, beta +- 1.96 * year-only SE;
    max_z    = beta +- 1.96 * max(...), for reference."""
    rules = {'primary': lambda sy, sm: (D.t, sm), 'pilot': lambda sy, sm: (1.96, sy), 'max_z': lambda sy, sm: (1.96, sm)}
    counts = {r: {'SUPPORTED': 0, 'CONTRADICTED': 0, 'NOT SUPPORTED': 0} for r in rules}
    for r in range(reps):
        rng = np.random.default_rng(seed0 + r)
        y = beta * D.la + 0.5 * erc_sample + rng.normal(0, math.sqrt(var_within), D.n)
        if var_block > 0:
            y = y + rng.normal(0, math.sqrt(var_block), D.nblocks)[D.binv]
        bj, sy, s2, sm = D.stats(y)
        for name, f in rules.items():
            c, se = f(sy, sm)
            lo, hi = bj - c * se, bj + c * se
            counts[name]['SUPPORTED' if lo > 0 else ('CONTRADICTED' if hi < 0 else 'NOT SUPPORTED')] += 1
    return {rule: {k: v / reps for k, v in c.items()} for rule, c in counts.items()}


def pilot_variance_components(rt, pilot_dir='/home/claude/p1/', block_m=20000):
    import pandas as pd
    dp = pd.read_csv(pilot_dir + 'predictors_blind.csv').merge(pd.read_csv(pilot_dir + 'outcomes.csv')[['fod_id', 'fire_size']], on='fod_id', how='left')
    sp, ap = rt.sample(dp, 'B')
    Xp = rt.design(sp, ap, 'rho_B', 'M2').values.astype(float); yp = np.log10(sp['fire_size'].values)
    ep = yp - Xp @ np.linalg.lstsq(Xp, yp, rcond=None)[0]
    bp = ((sp['x'] // block_m).astype(int).astype(str) + '_' + (sp['y'] // block_m).astype(int).astype(str)).values
    codes, inv = np.unique(bp, return_inverse=True); nb = np.bincount(inv); N, B = len(ep), len(codes)
    means = np.bincount(inv, weights=ep) / nb
    msw = float(((ep - means[inv]) ** 2).sum()) / (N - B)
    msb = float((nb * (means - ep.mean()) ** 2).sum()) / (B - 1); n0 = (N - (nb ** 2).sum() / N) / (B - 1)
    return dict(var_block=max(0.0, (msb - msw) / n0), var_within=msw, blocks=int(B), n=int(N))


# ---------------------------------------------------------------------------------------------------------------
# Continuous spatial error models (plan v1.2). The pilot's residuals are correlated across 20 km block boundaries
# (exponential correlogram, range about 11-12 km), which block clustering does not capture. These helpers fit
# that correlogram on the pilot and simulate persistent Gaussian random fields on a design, so the decision
# rule's critical value can be calibrated by simulation (calibrate_critical.py).

def pilot_residuals(rt, pilot_dir='/home/claude/p1/'):
    import pandas as pd
    dp = pd.read_csv(pilot_dir + 'predictors_blind.csv').merge(pd.read_csv(pilot_dir + 'outcomes.csv')[['fod_id', 'fire_size']], on='fod_id', how='left')
    sp, ap = rt.sample(dp, 'B')
    X = rt.design(sp, ap, 'rho_B', 'M2').values.astype(float); y = np.log10(sp['fire_size'].values)
    e = y - X @ np.linalg.lstsq(X, y, rcond=None)[0]
    return e, sp['x'].values, sp['y'].values, sp['fire_year'].values


def pilot_correlogram(rt, max_km=60.0, block_m=20000):
    """Residual correlations by distance bin on the pilot: all pairs, and cross-year pairs (split by same block)."""
    e, x, y, yr = pilot_residuals(rt)
    z = e / e.std()
    blk = (np.floor(x / block_m).astype(int) * 100000 + np.floor(y / block_m).astype(int))
    i, j = np.triu_indices(len(z), 1)
    d = np.hypot(x[i] - x[j], y[i] - y[j]) / 1000.0
    k = d < max_km; i, j, d = i[k], j[k], d[k]
    prod = z[i] * z[j]; cross = yr[i] != yr[j]; same = blk[i] == blk[j]
    edges = np.array([0, 1, 2, 3.5, 5, 7.5, 10, 12.5, 15, 20, 25, 30, 40, 50, 60.0])

    def bins(mask):
        rows = []
        for lo, hi in zip(edges[:-1], edges[1:]):
            m = mask & (d >= lo) & (d < hi)
            if m.sum():
                rows.append([float(d[m].mean()), float(prod[m].mean()), int(m.sum())])
        return np.array(rows)
    return dict(total_var=float(e.var()), all=bins(np.ones_like(cross)), cross=bins(cross),
                cross_same=bins(cross & same), cross_diff=bins(cross & ~same))


def fit_exponential(rows):
    from scipy.optimize import least_squares
    f = lambda p: (p[0] * np.exp(-rows[:, 0] / p[1]) - rows[:, 1]) * np.sqrt(rows[:, 2] / rows[:, 2].sum())
    r = least_squares(f, [0.05, 10.0], bounds=([0.0, 0.5], [1.0, 200.0]))
    return float(r.x[0]), float(r.x[1])


def fit_block_plus_exponential(same_rows, diff_rows):
    """corr = b * [same block] + s * exp(-d / r), fitted jointly to cross-year pairs."""
    from scipy.optimize import least_squares
    rows = np.vstack([np.c_[same_rows, np.ones(len(same_rows))], np.c_[diff_rows, np.zeros(len(diff_rows))]])
    w = np.sqrt(rows[:, 2] / rows[:, 2].sum())
    f = lambda p: (p[0] * rows[:, 3] + p[1] * np.exp(-rows[:, 0] / p[2]) - rows[:, 1]) * w
    r = least_squares(f, [0.02, 0.04, 10.0], bounds=([0.0, 0.0, 0.5], [1.0, 1.0, 200.0]))
    return float(r.x[0]), float(r.x[1]), float(r.x[2])


class Field:
    """Stationary Gaussian random field with unit variance and exponential correlation exp(-d / range_km), on a
    1 km periodic grid of NG x NG cells (circulant embedding, exact for the grid). Points are mapped to cells."""
    def __init__(self, range_km, xs, ys, NG=512):
        d1 = np.minimum(np.arange(NG), NG - np.arange(NG)).astype(float)
        lam = np.real(np.fft.fft2(np.exp(-np.sqrt(d1[:, None] ** 2 + d1[None, :] ** 2) / range_km)))
        self.sq = np.sqrt(np.clip(lam, 0, None)); self.NG = NG
        self.ci = ((xs - xs.min()) // 1000).astype(int) + 5
        self.cj = ((ys - ys.min()) // 1000).astype(int) + 5
        assert self.ci.max() < NG and self.cj.max() < NG

    def draw(self, rng):
        w = rng.normal(size=(self.NG, self.NG))
        return np.real(np.fft.ifft2(self.sq * np.fft.fft2(w)))[self.ci, self.cj]


def null_t(D, xs, ys, erc_sample, model, reps, seed0):
    """T = beta / max SE (and beta / year SE) under a null outcome with the given error model on design D.
    model: dict(var_total, block_share, field_share, range_km); the rest of the variance is independent noise."""
    vt = model['var_total']; vb = vt * model.get('block_share', 0.0); vf = vt * model.get('field_share', 0.0)
    vn = vt - vb - vf
    F = Field(model['range_km'], xs, ys) if vf > 0 else None
    Tm, Ty = np.empty(reps), np.empty(reps)
    for r in range(reps):
        rng = np.random.default_rng(seed0 + r)
        y = 0.5 * erc_sample + rng.normal(0, math.sqrt(vn), D.n)
        if vb > 0:
            y = y + rng.normal(0, math.sqrt(vb), D.nblocks)[D.binv]
        if F is not None:
            y = y + math.sqrt(vf) * F.draw(rng)
        bj, sy, s2, sm = D.stats(y)
        Tm[r], Ty[r] = bj / sm, bj / sy
    return Tm, Ty


def sim_stats(D, xs, ys, erc_sample, model, reps, seed0, beta=0.0):
    """Like null_t, with a planted slope beta on log10 Aenc; returns arrays (beta_hat, se_year, se_max)."""
    vt = model['var_total']; vb = vt * model.get('block_share', 0.0); vf = vt * model.get('field_share', 0.0)
    vn = vt - vb - vf
    F = Field(model['range_km'], xs, ys) if vf > 0 else None
    B, SY, SM = np.empty(reps), np.empty(reps), np.empty(reps)
    for r in range(reps):
        rng = np.random.default_rng(seed0 + r)
        y = beta * D.la + 0.5 * erc_sample + rng.normal(0, math.sqrt(vn), D.n)
        if vb > 0:
            y = y + rng.normal(0, math.sqrt(vb), D.nblocks)[D.binv]
        if F is not None:
            y = y + math.sqrt(vf) * F.draw(rng)
        B[r], SY[r], _, SM[r] = D.stats(y)
    return B, SY, SM
