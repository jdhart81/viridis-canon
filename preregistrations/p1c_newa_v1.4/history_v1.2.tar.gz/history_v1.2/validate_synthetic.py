#!/usr/bin/env python3
"""Validate run_test.py on SYNTHETIC outcomes before the freeze (v4, for plan v1.2). No real outcome exists for
this region; the script asserts that before and after.

A. End to end through run_test.py (with --synthetic) on this region's real blind predictors, in a scratch directory:
     planted: log10 size = 0.30 * log10 Aenc_B + 0.5 * erc_pct + N(0, 1.08)  -> must be SUPPORTED
     null:    log10 size =                      0.5 * erc_pct + N(0, 1.08)  -> one fixed draw (seed 202), reported
B. Null check of the registered rule (beta +- C2 * max SE) under every error model in CALIBRATION.json (iid, block,
   exp_all, exp_cross, block_exp), 10,000 replicates each on FRESH seeds (not the calibration seeds).
PASS iff (A) planted is SUPPORTED, and (B) the registered rule's false-call share is at most 0.058 under every model
(5% plus 3.5 Monte Carlo standard errors). The pilot's rule and plan v1.1's rule are reported alongside.
History: v1.0 scored one null draw; v2 a 1,000-replicate iid calibration of the pilot's rule; v3 added
block-correlated errors and decided on t x max SE (plan v1.1); v4 checks the simulation-calibrated C2 (plan v1.2).
Usage: python3 validate_synthetic.py <scratch dir>
"""
import hashlib, importlib.util, json, os, shutil, subprocess, sys
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import simcal  # noqa: E402

assert not os.path.exists(os.path.join(HERE, 'outcomes.csv')), 'a real outcome file exists; stop'
SC = os.path.abspath(sys.argv[1]); os.makedirs(SC, exist_ok=True)
link = os.path.join(SC, 'p1')
if not os.path.islink(link):
    os.symlink('/home/claude/p1', link)            # so ../p1/... resolves for run_test.py
pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
la = np.log10(pred['Aenc_B'].where(pred['Aenc_B'] > 0, 1000.0)).values
erc = pred['erc_pct'].fillna(0.5).values
out = {}
for world, beta, seed in [('planted', 0.30, 101), ('null', 0.0, 202)]:
    d = os.path.join(SC, world); os.makedirs(d, exist_ok=True)
    shutil.copy(os.path.join(HERE, 'run_test.py'), d)
    for f in ('predictors_blind.csv', 'EXPOSURE_LISTS.json'):
        dst = os.path.join(d, f)
        if not os.path.exists(dst):
            os.symlink(os.path.join(HERE, f), dst)
    rng = np.random.default_rng(seed)
    y = beta * la + 0.5 * erc + rng.normal(0, 1.08, len(pred))
    pd.DataFrame({'fod_id': pred['fod_id'], 'fire_size': 10 ** y, 'fire_size_class': 'SYN'}).to_csv(os.path.join(d, 'outcomes.csv'), index=False)
    subprocess.run([sys.executable, 'run_test.py', '--synthetic'], cwd=d, check=True, capture_output=True)
    R = json.load(open(os.path.join(d, 'results.json')))
    p = R['primary_test']
    out[world] = dict(planted_beta=beta, beta=round(p['beta'], 3), interval_registered=[round(v, 3) for v in p['interval_registered']],
                      ci95_year=[round(v, 3) for v in p['ci95_year']], n=p['n'], decision=R['decision'],
                      reading_v11_rule=R['reading_v11_rule'], decision_pilot_rule=R['decision_pilot_rule'],
                      reading=R['interpretation']['reading'])
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))

spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
CAL = json.load(open(os.path.join(HERE, 'CALIBRATION.json')))
assert rt.C2 == CAL['C2'] and rt.C1 == CAL['C1'], 'run_test.py critical values differ from CALIBRATION.json'
D = simcal.Design(rt, pred)
xs, ys = pred['x'].values[D.pos].astype(float), pred['y'].values[D.pos].astype(float)
es = erc[D.pos]
# exactness: the fast path equals run_test.fit_twoway on one replicate with a field and block effects
m = CAL['models']['block_exp']
rng = np.random.default_rng(77)
F = simcal.Field(m['range_km'], xs, ys)
y = 0.5 * es + rng.normal(0, 1.0, D.n) + rng.normal(0, 0.2, D.nblocks)[D.binv] + 0.2 * F.draw(rng)
yfull = np.zeros(len(pred)); yfull[D.pos] = y
tw = rt.fit_twoway(pred.assign(fire_size=10 ** yfull), 'B'); bj, sy, s2, sm = D.stats(y)
assert abs(tw['beta'] - bj) < 1e-10 and abs(tw['se_year_only'] - sy) < 1e-10 and abs(tw['se'] - s2) < 1e-10 and abs(tw['se_max'] - sm) < 1e-10
REPS = 10000
checks = {}
for k, (name, mod) in enumerate(CAL['models'].items()):
    model = {kk: mod[kk] for kk in ('var_total', 'block_share', 'field_share', 'range_km') if kk in mod}
    Tm, Ty = simcal.null_t(D, xs, ys, es, model, REPS, 70_000_000 + 1_000_000 * k)
    checks[name] = dict(registered_rule=float(np.mean(np.abs(Tm) > rt.C2)), v11_rule=float(np.mean(np.abs(Tm) > D.t)),
                        pilot_rule=float(np.mean(np.abs(Ty) > 1.96)), reps=REPS)
out['null_check_fresh_seeds'] = dict(C2=rt.C2, C1=rt.C1, threshold=0.058, models=checks)
ok = out['planted']['decision'] == 'SUPPORTED' and all(c['registered_rule'] <= 0.058 for c in checks.values())
out['pass_criterion'] = 'planted SUPPORTED, and the registered rule false-call share <= 0.058 under every calibration model on fresh seeds'
out['pass'] = bool(ok)
out['code_sha256'] = {f: hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
                      for f in ('run_test.py', 'simcal.py', 'validate_synthetic.py', 'CALIBRATION.json')}
json.dump(out, open(os.path.join(HERE, 'SYNTHETIC_VALIDATION.json'), 'w'), indent=1)
print(json.dumps(out, indent=1))
sys.exit(0 if ok else 1)
