#!/usr/bin/env python3
"""Write logs/transcript_tool_calls_p1c_part2.jsonl: the command record that follows the extract frozen with plan v1.2.

Part 1, logs/transcript_tool_calls_p1c.jsonl, is kept exactly as frozen with v1.2 (its sha256 is in
history_v1.2/FREEZE.json): every matching shell command and file edit from 20:33 ET (00:33Z) to 02:30:15 ET. It cannot
be regenerated, because the session transcript was compacted at about 02:51 ET and now begins there.

Part 2 (written here) holds, with a 'source' field on every row:
  (a) 02:30:42-02:31:57 ET (06:30:42Z-06:31:57Z), recovered from logs/transcript_view_by_third_audit_0232ET.txt: the
      third audit's own printout of the session transcript, made at 02:32 ET. Each recovered command's length must
      equal the length printed with it. The first of these commands, the final v1.2 pre-freeze command, is missing
      from part 1 because v1.2's extractor skipped any command that mentioned the extractor;
  (b) 02:51 ET (06:51Z) onward, from the session transcript itself.
Commands between 02:31:57 and 02:51 ET cannot be recovered (plan v1.3, section 3).
Both parts use the same filter: Bash, Edit and Write calls whose input matches PAT below. The only command skipped is a
bare invocation of this script ('python3 extract_transcript.py' with nothing else), whose output is this file."""
import json, re

SRC = '/root/.claude/projects/-home-claude/d23d759f-9c1b-589b-9849-6bba926e6bc3.jsonl'
VIEW = 'logs/transcript_view_by_third_audit_0232ET.txt'
PAT = re.compile(r'p1c|/p1/|\.\./p1|p1_config|fetch_data|build_predictors|run_test|run_chain|simcal|freeze\.py|equivalence|'
                 r'validate_synthetic|blind_design|fill_prereg|fetch_outcomes|PREREG|history_v1|calibrate_critical|exposure_lists')
BARE = re.compile(r'^\s*(cd\s+\S+\s*&&\s*)?python3\s+(\./)?extract_transcript\.py\s*$')
LAST_PART1 = '2026-10-21T06:30:15.050Z'
RESUME = '2026-10-21T06:51:00Z'


def keep(tool, inp):
    s = json.dumps(inp)
    if not PAT.search(s):
        return False
    return not (tool == 'Bash' and BARE.match(inp.get('command', '')))


rows = []
view = open(VIEW).read()
recovered = re.findall(r'(\d{4}-\d\d-\d\dT[\d:.]+Z) (Bash|Edit|Write) (\d+)\n(.*?)\n=======(?:\n|$)', view, flags=re.S)
assert len(recovered) == view.count('\n=======') , 'unparsed blocks in the third audit view'
assert recovered, 'nothing parsed from the third audit view'
for ts, tool, n, text in recovered:
    assert len(text) == int(n), f'length mismatch at {ts}: {len(text)} != {n}'
    inp = {'command': text} if tool == 'Bash' else json.loads(text)
    if ts > LAST_PART1 and keep(tool, inp):
        rows.append(dict(timestamp=ts, tool=tool, input=inp,
                         source='third audit printout of the session transcript, 02:32 ET (command text only)'))
n_a = len(rows)
for line in open(SRC):
    try:
        o = json.loads(line)
    except Exception:
        continue
    ts = o.get('timestamp') or ''
    m = o.get('message') or {}
    for c in (m.get('content') if isinstance(m.get('content'), list) else []):
        if isinstance(c, dict) and c.get('type') == 'tool_use' and c.get('name') in ('Bash', 'Edit', 'Write'):
            if ts >= RESUME and keep(c['name'], c.get('input') or {}):
                rows.append(dict(timestamp=ts, tool=c['name'], input=c['input'], source='session transcript'))
rows.sort(key=lambda r: r['timestamp'])
with open('logs/transcript_tool_calls_p1c_part2.jsonl', 'w') as fh:
    for r in rows:
        fh.write(json.dumps(r) + '\n')
print(f'{len(rows)} tool calls ({n_a} recovered, {len(rows) - n_a} from the session transcript)',
      rows[0]['timestamp'], '->', rows[-1]['timestamp'])
