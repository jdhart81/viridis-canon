# Decision record: the v1.3 primary model adds 40 km regional fixed effects (M2R)

Written 2026-10-21, before the pilot's estimate under M2R was computed, and before any confirmatory outcome exists.

## What the exploratory runs showed (no outcome used)

`exploratory_multiscale.py` and `exploratory_regional_fe.py`, on this region's blind design, 1,000 null replicates per error model:

| Error model (persistent exponential field + independent noise) | q95 \|T\|, M2 (pilot model) | q95 \|T\|, M2 + 40 km SE in the max | q95 \|T\|, M2R |
|---|---|---|---|
| iid | 1.98–1.99 | 1.96 | 2.02 |
| share 0.06, range 30 km | 2.55 | 2.43 | 2.05 |
| share 0.11, range 45 km | 3.07 | 2.89 | 2.23 |
| share 0.11, range 90 km | 2.97 | 2.86 | 2.15 |
| share 0.20, range 90 km | 3.52 | 3.25 | 2.28 |
| share 0.25, range 180 km | 3.37 | — | 2.11 |

- The first v1.3 calibration run (statistic as in v1.2) found that the pilot cannot reject fields with shares up to the grid edge (0.11) at ranges of 22–90 km. It was stopped after the three reference models and 9 of the 38 retained field models (`calibrate_v13_firstrun_T2_stopped.log`).
- Under such fields the M2 statistic needs a critical value of about 3.1–3.5, and power at β₃₃ falls to about 0.3. Adding a 40 km SE to the max barely helps.
- Adding 40 km regional fixed effects (blocks of 2 × 2 cells of the 20 km clustering grid) removes most of the long-range sensitivity, while the identifying variation barely changes: the SD of log₁₀ A_enc given the other terms goes from 0.711 to 0.701.

## Decision

1. **The primary model becomes M2R:** M2 plus fixed effects for 40 km regions (EPSG:5070 cells, x // 40,000 and y // 40,000). The SEs, the max-SE statistic and the decision structure are unchanged; C2 and C1 are recalibrated for M2R.
2. **Region size:** 40 km was the first and only size tried, chosen beforehand as twice the 20 km clustering block. No other size will be tried.
3. **The pilot's exact model, M2,** stays in the plan as a secondary reading (S13), with its own critical value calibrated over the same credible set.
4. **The credible set** is extended in share and range until its edge is closed or reaches range 180 km, so C2 is not set by the grid edge.

This decision stands whatever the pilot's M2R estimate turns out to be. That estimate is computed next, as pilot Deviation 3 (exploratory), to state the replication target in §1.
