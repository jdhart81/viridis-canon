#!/usr/bin/env python3
"""Calibrate the decision rule's critical values by simulation (plan v1.3). Writes CALIBRATION.json.

Statistic: T = beta / max(SE_twoway, SE_year) for the B/M2 compartment slope.
Step 1, which spatial error models are credible (simcal.PilotPlausibility). A correlogram fitted to residuals is
  biased toward short ranges, so the pilot's plug-in fit (share 0.053, range 11.2 km) is not taken at face value.
  Every field model on a grid of correlated shares x exponential ranges is simulated on the PILOT design
  (200 replicates, residualized on the pilot's B/M2 design, correlogram refitted exactly as for the real residuals);
  a model is RETAINED if the pilot's observed fitted share and range both lie inside the central 95% of its fits.
Step 2, null outcomes on THIS region's blind design, 4,000 replicates per model, for: every retained field model;
  20 km block effects (one-way ANOVA on pilot residuals); block effects plus a field (fitted jointly to cross-year
  pairs); and iid errors (reference only).
Registered values, the MAXIMUM over the spatial models (iid excluded), rounded UP to 2 decimals:
  C2 = 95th percentile of |T| (two-sided 5%: the decision interval beta +- C2 * max SE)
  C1 = 90th percentile of |T| (one-sided 5%: the bound used by the NOT REPLICATED reading)
Step 3, the pilot re-read: the same models (binding ones plus references) on the PILOT's own design, 5,000 replicates.
No confirmatory outcome is used anywhere. Usage: python3 calibrate_critical.py   (about 40 minutes)"""
import hashlib, importlib.util, json, math, os, sys, time
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import simcal  # noqa: E402

spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rt)
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))
t0 = time.time()
SHARES = [0.03, 0.045, 0.06, 0.075, 0.09, 0.11]
RANGES = [6.0, 11.0, 16.0, 22.0, 30.0, 45.0, 60.0, 90.0]
PP = simcal.PilotPlausibility(rt)
grid = []
for a, s in enumerate(SHARES):
    for b, r in enumerate(RANGES):
        grid.append(PP.check(s, r, 200, 1_000_000 + 1000 * (len(RANGES) * a + b)))
        print(f"plausibility share {s:.3f} range {r:5.1f}: retained={grid[-1]['retained']} "
              f"fitted share q50 {grid[-1]['fitted_share_q025_q50_q975'][1]:.3f}, range q50 {grid[-1]['fitted_range_q025_q50_q975'][1]:.1f}", flush=True)
cg = simcal.pilot_correlogram(rt)
vc = simcal.pilot_variance_components(rt)
TOT = cg['total_var']
b_be, s_be, r_be = simcal.fit_block_plus_exponential(cg['cross_same'], cg['cross_diff'])
MODELS = {'iid': dict(var_total=TOT, range_km=10.0),
          'block': dict(var_total=TOT, block_share=vc['var_block'] / (vc['var_block'] + vc['var_within']), range_km=10.0),
          'block_exp': dict(var_total=TOT, block_share=b_be, field_share=s_be, range_km=r_be)}
for g in grid:
    if g['retained']:
        MODELS[f"field_s{g['share']:.3f}_r{g['range_km']:.0f}"] = dict(var_total=TOT, field_share=g['share'], range_km=g['range_km'])
SPATIAL = [m for m in MODELS if m != 'iid']


def run(pred, models, reps, seed_base):
    D = simcal.Design(rt, pred)
    xs, ys = pred['x'].values[D.pos].astype(float), pred['y'].values[D.pos].astype(float)
    es = pred['erc_pct'].fillna(0.5).values[D.pos]
    out = {}
    for k, name in enumerate(models):
        Tm, Ty = simcal.null_t(D, xs, ys, es, MODELS[name], reps, seed_base + 100000 * k)
        out[name] = dict(Tm=Tm, Ty=Ty)
        print(f'  {name}: q95|T| {np.quantile(np.abs(Tm), 0.95):.3f}  ({time.time() - t0:.0f}s)', flush=True)
    return D, out


pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
D, sims = run(pred, list(MODELS), 4000, 5_000_000)
res = {'grid': grid, 'pilot_observed_fit': dict(share=PP.obs[0], range_km=PP.obs[1]), 'models': {},
       'confirmatory_design': dict(n=D.n, blocks=D.nblocks, dof=D.dof, t_crit=D.t)}
for name, s in sims.items():
    a = np.abs(s['Tm'])
    res['models'][name] = dict(MODELS[name], q90_absT=float(np.quantile(a, 0.90)), q95_absT=float(np.quantile(a, 0.95)),
                               false_call_share_v11_rule=float(np.mean(a > D.t)),
                               false_call_share_pilot_rule=float(np.mean(np.abs(s['Ty']) > 1.96)), reps=len(a))
C2 = math.ceil(max(res['models'][m]['q95_absT'] for m in SPATIAL) * 100) / 100
C1 = math.ceil(max(res['models'][m]['q90_absT'] for m in SPATIAL) * 100) / 100
res['C2'] = C2; res['C1'] = C1
res['binding_model_C2'] = max(SPATIAL, key=lambda m: res['models'][m]['q95_absT'])
res['binding_model_C1'] = max(SPATIAL, key=lambda m: res['models'][m]['q90_absT'])
for name, s in sims.items():
    res['models'][name]['false_call_share_C2_rule'] = float(np.mean(np.abs(s['Tm']) > C2))
# pilot re-read on its own design: references plus the three models with the largest q95 here
top = sorted(SPATIAL, key=lambda m: -res['models'][m]['q95_absT'])[:3]
pmodels = ['iid', 'block', 'block_exp'] + [m for m in top if m not in ('block', 'block_exp')]
pp = pd.read_csv('/home/claude/p1/predictors_blind.csv')
Dp, psims = run(pp, pmodels, 5000, 9_000_000)
T_obs = 0.06317647448409425 / 0.027318251774805232            # pilot beta / max(two-way SE 0.0234, year SE 0.0273)
res['pilot_reread'] = dict(T_obs=T_obs, design=dict(n=Dp.n, blocks=Dp.nblocks, dof=Dp.dof), models={})
for name, s in psims.items():
    a = np.abs(s['Tm'])
    res['pilot_reread']['models'][name] = dict(p_two_sided=float(np.mean(a >= T_obs)), c_5pct=float(np.quantile(a, 0.95)),
                                               c_2p5pct=float(np.quantile(a, 0.975)), reps=len(a))
res['correlogram'] = {k: (v.tolist() if hasattr(v, 'tolist') else v) for k, v in cg.items()}
res['fits'] = dict(block_exp=dict(block_share=b_be, field_share=s_be, range_km=r_be), anova=vc)
res['code_sha256'] = {f: hashlib.sha256(open(os.path.join(HERE, f), 'rb').read()).hexdigest()
                      for f in ('run_test.py', 'simcal.py', 'calibrate_critical.py', 'predictors_blind.csv')}
json.dump(res, open(os.path.join(HERE, 'CALIBRATION.json'), 'w'), indent=1)
print(json.dumps({k: res[k] for k in ('C2', 'C1', 'binding_model_C2', 'binding_model_C1', 'pilot_observed_fit')}, indent=1))
print('retained models:', [m for m in MODELS if m.startswith('field')])
for name, m in res['pilot_reread']['models'].items():
    print(f"pilot {name:22s} p {m['p_two_sided']:.4f}  c5% {m['c_5pct']:.3f}  c2.5% {m['c_2p5pct']:.3f}")
print('seconds', round(time.time() - t0))
