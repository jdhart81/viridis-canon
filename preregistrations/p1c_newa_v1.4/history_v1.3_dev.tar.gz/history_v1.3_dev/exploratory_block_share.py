#!/usr/bin/env python3
"""EXPLORATORY (plan v1.3 development; disclosed). No confirmatory outcome used.
Questions: (1) the 'block' reference model uses the pilot's ANOVA block share as a plug-in. Which block shares can the
pilot not reject (observed ANOVA estimate inside the central 95% of estimates simulated on the pilot design)?
(2) How does q95|T| under M2R and M2 grow with the block share on the confirmatory design? 1,000 replicates each."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import importlib.util, json, math, sys
import numpy as np, pandas as pd
HERE = '/home/claude/p1c'; sys.path.insert(0, HERE)
import simcal
spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
vc = simcal.pilot_variance_components(rt); obs = vc['var_block'] / (vc['var_block'] + vc['var_within'])
dp = pd.read_csv('/home/claude/p1/predictors_blind.csv').merge(pd.read_csv('/home/claude/p1/outcomes.csv')[['fod_id', 'fire_size']], on='fod_id', how='left')
sp, ap = rt.sample(dp, 'B'); Xp = rt.design(sp, ap, 'rho_B', 'M2').values.astype(float); Mp = np.linalg.pinv(Xp)
bp = ((sp['x'] // 20000).astype(int).astype(str) + '_' + (sp['y'] // 20000).astype(int).astype(str)).values
codes, inv = np.unique(bp, return_inverse=True); nb = np.bincount(inv); N, B = len(inv), len(codes)
n0 = (N - (nb ** 2).sum() / N) / (B - 1)
def anova_share(e):
    means = np.bincount(inv, weights=e) / nb
    msw = float(((e - means[inv]) ** 2).sum()) / (N - B); msb = float((nb * (means - e.mean()) ** 2).sum()) / (B - 1)
    vb = max(0.0, (msb - msw) / n0); return vb / (vb + msw)
TOT = vc['var_block'] + vc['var_within']
pred = rt.add_regions(pd.read_csv(os.path.join(HERE, 'predictors_blind.csv')))
DR, D0 = simcal.Design(rt, pred, fes=rt.FES_R), simcal.Design(rt, pred, fes=rt.FES)
xs, ys = pred['x'].values[DR.pos].astype(float), pred['y'].values[DR.pos].astype(float); es = pred['erc_pct'].fillna(0.5).values[DR.pos]
out = dict(observed_share=obs, rows=[])
print('observed ANOVA block share', round(obs, 4), flush=True)
for k, sh in enumerate([0.03, 0.045, 0.0623, 0.075, 0.09, 0.11, 0.13, 0.16]):
    rng = np.random.default_rng(82_000_000 + 1000 * k); est = []
    for _ in range(200):
        y = rng.normal(0, math.sqrt(TOT * (1 - sh)), N) + rng.normal(0, math.sqrt(TOT * sh), B)[inv]
        est.append(anova_share(y - Xp @ (Mp @ y)))
    q = np.quantile(est, [0.025, 0.5, 0.975]); keep = bool(q[0] <= obs <= q[2])
    TmR, _, Tm0, _ = simcal.null_t_pair(DR, D0, xs, ys, es, dict(var_total=TOT, block_share=sh, range_km=10.0), 1000, 83_000_000 + 1_000_000 * k)
    row = dict(block_share=sh, est_q025_q50_q975=q.tolist(), retained=keep, q95_M2R=float(np.quantile(np.abs(TmR), .95)), q95_M2=float(np.quantile(np.abs(Tm0), .95)))
    out['rows'].append(row); print({kk: (round(v, 3) if isinstance(v, float) else v) for kk, v in row.items() if kk != 'est_q025_q50_q975'}, [round(v, 3) for v in q], flush=True)
json.dump(out, open(os.path.join(HERE, 'history_v1.3_dev', 'exploratory_block_share.json'), 'w'), indent=1)
