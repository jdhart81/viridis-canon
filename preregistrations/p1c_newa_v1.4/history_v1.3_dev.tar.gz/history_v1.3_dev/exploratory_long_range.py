#!/usr/bin/env python3
"""EXPLORATORY (plan v1.3 development; disclosed). No confirmatory outcome is used.
The binding model of the registered calibration sits at the grid's longest range (share 0.40, range 180 km). Does the
M2R statistic get worse for credible fields beyond 180 km? Fields are drawn on a 1,024 km periodic grid (the 512 km grid
of the calibration is too small for these ranges). For ranges 240 and 360 km and shares 0.4-0.8: the pilot screen
(200 replicates, as simcal.PilotPlausibility.check); then, for the largest retained share at each range, and for
share 0.40 at 180 km as a cross-check of the grid size, q95|T| on the confirmatory design (2,000 replicates)."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import importlib.util, json, math, multiprocessing as mp, sys
import numpy as np, pandas as pd
HERE = '/home/claude/p1c'; sys.path.insert(0, HERE)
import simcal
spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))
PP = simcal.PilotPlausibility(rt)
pred = rt.add_regions(pd.read_csv(os.path.join(HERE, 'predictors_blind.csv')))
DR, D0 = simcal.Design(rt, pred, fes=rt.FES_R), simcal.Design(rt, pred, fes=rt.FES)
xs, ys = pred['x'].values[DR.pos].astype(float), pred['y'].values[DR.pos].astype(float); es = pred['erc_pct'].fillna(0.5).values[DR.pos]
TOT = json.load(open(os.path.join(HERE, 'CALIBRATION.json')))['models']['iid']['var_total']
NG = 1024


def neg_mass(r):
    d1 = np.minimum(np.arange(NG), NG - np.arange(NG)).astype(float)
    lam = np.real(np.fft.fft2(np.exp(-np.sqrt(d1[:, None] ** 2 + d1[None, :] ** 2) / r)))
    return float(-lam[lam < 0].sum() / lam[lam > 0].sum())


def screen(arg):
    share, r, seed = arg
    F = simcal.Field(r, PP.x, PP.y, NG=NG); rng = np.random.default_rng(seed); fs = []
    for _ in range(200):
        yy = rng.normal(0, math.sqrt(PP.TOT * (1 - share)), PP.n) + math.sqrt(PP.TOT * share) * F.draw(rng)
        fs.append(PP.fit(yy - PP.X @ (PP.M @ yy)))
    fs = np.array(fs); qs = np.quantile(fs[:, 0], [.025, .5, .975]); qr = np.quantile(fs[:, 1], [.025, .5, .975])
    return dict(share=share, range_km=r, retained=bool(qs[0] <= PP.obs[0] <= qs[2] and qr[0] <= PP.obs[1] <= qr[2]),
                fitted_share_q=qs.tolist(), fitted_range_q=qr.tolist())


def q95(arg):
    share, r, seed = arg
    F = simcal.Field(r, xs, ys, NG=NG); TR, T0 = [], []
    for i in range(2000):
        rng = np.random.default_rng(seed + i)
        y = 0.5 * es + rng.normal(0, math.sqrt(TOT * (1 - share)), DR.n) + math.sqrt(TOT * share) * F.draw(rng)
        b1, _, _, m1 = DR.stats(y); b0, _, _, m0 = D0.stats(y); TR.append(b1 / m1); T0.append(b0 / m0)
    return dict(share=share, range_km=r, q95_M2R=float(np.quantile(np.abs(TR), .95)), q95_M2=float(np.quantile(np.abs(T0), .95)),
                false_M2R_at_C2=float(np.mean(np.abs(TR) > 2.37)))


if __name__ == '__main__':
    out = dict(negative_mass_NG1024={r: neg_mass(r) for r in (180, 240, 360)})
    print(out, flush=True)
    args = [(s, r, 84_000_000 + 1000 * i) for i, (s, r) in enumerate([(sh, r) for r in (240, 360) for sh in (0.4, 0.5, 0.6, 0.8)] + [(0.4, 180), (0.5, 180)])]
    with mp.get_context('fork').Pool(2) as pool:
        out['screen'] = list(pool.imap(screen, args))
        for g in out['screen']:
            print('screen', g['share'], g['range_km'], g['retained'], [round(v, 3) for v in g['fitted_share_q']], flush=True)
        todo = [(0.4, 180, 85_000_000)]
        for r in (240, 360):
            kept = [g['share'] for g in out['screen'] if g['range_km'] == r and g['retained']]
            if kept:
                todo.append((max(kept), r, 85_000_000 + 10_000 * r))
        out['q95'] = list(pool.imap(q95, todo))
    for q in out['q95']:
        print('q95', q, flush=True)
    json.dump(out, open(os.path.join(HERE, 'history_v1.3_dev', 'exploratory_long_range.json'), 'w'), indent=1)
