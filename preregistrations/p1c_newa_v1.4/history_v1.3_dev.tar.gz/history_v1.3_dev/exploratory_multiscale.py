#!/usr/bin/env python3
"""EXPLORATORY (plan v1.3 development; disclosed in the plan's section 0). No outcome is used.
Question: would adding a 40 km two-way SE to the max in the denominator make T less sensitive to long-range fields?
T2 = beta / max(SE_year, SE_yx20km)          (the v1.2 statistic)
T3 = beta / max(SE_year, SE_yx20km, SE_yx40km)
Simulated on the confirmatory blind design, 1,000 null replicates per model (seeds 80,000,000 + 1,000,000 k), and
planted beta = beta33 under iid errors for a power comparison."""
import importlib.util, json, math, os, sys, time
import numpy as np, pandas as pd
HERE = '/home/claude/p1c'; sys.path.insert(0, HERE)
import simcal
spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))
pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
D = simcal.Design(rt, pred)
s, a = rt.sample(pred.assign(fire_size=1.0), 'B')
g = s['fire_year'].astype(str).values
b40 = ((s['x'] // 40000).astype(int).astype(str) + '_' + (s['y'] // 40000).astype(int).astype(str)).values
_, binv40 = np.unique(b40, return_inverse=True); _, ybinv40 = np.unique(np.char.add(np.char.add(g, '|'), b40), return_inverse=True)
c = lambda inv: (inv.max() + 1) / inv.max() * (D.n - 1) / (D.n - D.k)
cB40, cYB40 = c(binv40), c(ybinv40)
print('blocks20', D.nblocks, 'blocks40', binv40.max() + 1, flush=True)

def stats3(y):
    bj = float(D.h @ y); e = y - D.Xv @ (D.XtX_inv @ (D.Xv.T @ y)); w = D.h * e
    vy = D.cY * float((np.bincount(D.yinv, weights=w) ** 2).sum())
    v20 = vy + D.cB * float((np.bincount(D.binv, weights=w) ** 2).sum()) - D.cYB * float((np.bincount(D.ybinv, weights=w) ** 2).sum())
    v40 = vy + cB40 * float((np.bincount(binv40, weights=w) ** 2).sum()) - cYB40 * float((np.bincount(ybinv40, weights=w) ** 2).sum())
    sy = math.sqrt(vy); s20 = math.sqrt(max(v20, 0)) if v20 > 0 else sy; s40 = math.sqrt(v40) if v40 > 0 else sy
    return bj, max(sy, s20), max(sy, s20, s40)

xs, ys = pred['x'].values[D.pos].astype(float), pred['y'].values[D.pos].astype(float)
es = pred['erc_pct'].fillna(0.5).values[D.pos]
TOT = json.load(open(os.path.join(HERE, 'CALIBRATION.json')))['models']['iid']['var_total']
models = {'iid': (0, 10), 's0.030_r11': (0.03, 11), 's0.060_r30': (0.06, 30), 's0.110_r45': (0.11, 45), 's0.110_r90': (0.11, 90), 's0.200_r90': (0.20, 90)}
out = {}
t0 = time.time()
for k, (name, (sh, r)) in enumerate(models.items()):
    F = simcal.Field(r, xs, ys) if sh > 0 else None
    T2, T3 = [], []
    for i in range(1000):
        rng = np.random.default_rng(80_000_000 + 1_000_000 * k + i)
        y = 0.5 * es + rng.normal(0, math.sqrt(TOT * (1 - sh)), D.n)
        if F is not None: y = y + math.sqrt(TOT * sh) * F.draw(rng)
        bj, m2, m3 = stats3(y); T2.append(bj / m2); T3.append(bj / m3)
    T2, T3 = np.abs(T2), np.abs(T3)
    out[name] = dict(q95_T2=float(np.quantile(T2, .95)), q95_T3=float(np.quantile(T3, .95)), q90_T2=float(np.quantile(T2, .9)), q90_T3=float(np.quantile(T3, .9)))
    print(name, {kk: round(v, 3) for kk, v in out[name].items()}, f'{time.time()-t0:.0f}s', flush=True)
# power at beta33 under iid
P2, P3 = [], []
for i in range(1000):
    rng = np.random.default_rng(90_000_000 + i)
    y = rt.BETA33 * D.la + 0.5 * es + rng.normal(0, math.sqrt(TOT), D.n)
    bj, m2, m3 = stats3(y); P2.append(bj / m2); P3.append(bj / m3)
out['beta33_iid_T'] = dict(T2=np.quantile(P2, [.1, .5, .9]).tolist(), T3=np.quantile(P3, [.1, .5, .9]).tolist())
C2a = max(v['q95_T2'] for kk, v in out.items() if kk.startswith('s')); C3a = max(v['q95_T3'] for kk, v in out.items() if kk.startswith('s'))
out['power_beta33_iid'] = dict(C_T2=C2a, power_T2=float(np.mean(np.array(P2) > C2a)), C_T3=C3a, power_T3=float(np.mean(np.array(P3) > C3a)))
print(json.dumps({k: out[k] for k in ('beta33_iid_T', 'power_beta33_iid')}, indent=1))
json.dump(out, open(os.path.join(HERE, 'history_v1.3_dev', 'exploratory_multiscale.json'), 'w'), indent=1)
