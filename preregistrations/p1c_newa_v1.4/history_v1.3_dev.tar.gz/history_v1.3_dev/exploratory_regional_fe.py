#!/usr/bin/env python3
"""EXPLORATORY (plan v1.3 development; disclosed in the plan's section 0). No confirmatory outcome is used.
Question: with 40 km regional fixed effects added to M2 ('M2R'), is T = beta / max(SE_year, SE_yx20km) still
sensitive to long-range residual fields, and how much identifying variation in log10 Aenc remains?
Confirmatory blind design; 1,000 null replicates per model (seeds 81,000,000 + 1,000,000 k)."""
import importlib.util, json, math, os, sys, time
import numpy as np, pandas as pd
HERE = '/home/claude/p1c'; sys.path.insert(0, HERE)
import simcal
spec = importlib.util.spec_from_file_location('rt', os.path.join(HERE, 'run_test.py')); rt = importlib.util.module_from_spec(spec); spec.loader.exec_module(rt)
assert not os.path.exists(os.path.join(HERE, 'outcomes.csv'))
pred = pd.read_csv(os.path.join(HERE, 'predictors_blind.csv'))
pred['region40'] = (pred['x'] // 40000).astype(int).astype(str) + '_' + (pred['y'] // 40000).astype(int).astype(str)


class DesignR(simcal.Design):
    def __init__(self, rt, pred, fes, block_m=20000):
        s, a = rt.sample(pred.assign(fire_size=1.0), 'B')
        X = rt.design(s, a, 'rho_B', 'M2', fes=fes)
        self.Xv = X.values.astype(float); self.n, self.k = self.Xv.shape
        self.XtX_inv = np.linalg.pinv(self.Xv.T @ self.Xv)
        j = list(X.columns).index('log10_Aenc'); self.h = self.Xv @ self.XtX_inv[:, j]
        self.pos = pred.index.get_indexer(s.index); self.la = np.log10(s[a].values)
        others = [c for c in X.columns if c != 'log10_Aenc']; Z = X[others].values.astype(float)
        self.sdres = float((self.la - Z @ np.linalg.lstsq(Z, self.la, rcond=None)[0]).std())
        g = s['fire_year'].astype(str).values
        blk = ((s['x'] // block_m).astype(int).astype(str) + '_' + (s['y'] // block_m).astype(int).astype(str)).values
        _, self.yinv = np.unique(g, return_inverse=True); _, self.binv = np.unique(blk, return_inverse=True)
        _, self.ybinv = np.unique(np.char.add(np.char.add(g, '|'), blk), return_inverse=True)
        self.nblocks = int(self.binv.max() + 1); self.dof = int(min(self.yinv.max() + 1, self.nblocks) - 1); self.t = rt.t_crit(self.dof)
        c = lambda inv: (inv.max() + 1) / inv.max() * (self.n - 1) / (self.n - self.k)
        self.cY, self.cB, self.cYB = c(self.yinv), c(self.binv), c(self.ybinv)


D0 = DesignR(rt, pred, rt.FES); DR = DesignR(rt, pred, rt.FES + ('region40',))
print('k M2', D0.k, 'k M2R', DR.k, 'sd resid log10Aenc: M2', round(D0.sdres, 4), 'M2R', round(DR.sdres, 4), flush=True)
xs, ys = pred['x'].values[D0.pos].astype(float), pred['y'].values[D0.pos].astype(float)
es = pred['erc_pct'].fillna(0.5).values[D0.pos]
TOT = json.load(open(os.path.join(HERE, 'CALIBRATION.json')))['models']['iid']['var_total']
models = {'iid': (0, 10), 's0.060_r30': (0.06, 30), 's0.110_r45': (0.11, 45), 's0.110_r90': (0.11, 90), 's0.200_r90': (0.20, 90), 's0.250_r180': (0.25, 180)}
out = dict(k=dict(M2=D0.k, M2R=DR.k), sdres=dict(M2=D0.sdres, M2R=DR.sdres), models={})
t0 = time.time()
for k, (name, (sh, r)) in enumerate(models.items()):
    F = simcal.Field(r, xs, ys) if sh > 0 else None
    T0, TR = [], []
    for i in range(1000):
        rng = np.random.default_rng(81_000_000 + 1_000_000 * k + i)
        y = 0.5 * es + rng.normal(0, math.sqrt(TOT * (1 - sh)), D0.n)
        if F is not None: y = y + math.sqrt(TOT * sh) * F.draw(rng)
        b0, _, _, m0 = D0.stats(y); bR, _, _, mR = DR.stats(y); T0.append(b0 / m0); TR.append(bR / mR)
    T0, TR = np.abs(T0), np.abs(TR)
    out['models'][name] = dict(q95_M2=float(np.quantile(T0, .95)), q95_M2R=float(np.quantile(TR, .95)))
    print(name, {kk: round(v, 3) for kk, v in out['models'][name].items()}, f'{time.time()-t0:.0f}s', flush=True)
json.dump(out, open(os.path.join(HERE, 'history_v1.3_dev', 'exploratory_regional_fe.json'), 'w'), indent=1)
