# Decision record: the v1.4 stress set and how it sets C2

Written 2026-10-21, after the fourth audit's report (`audits/AUDIT_4_of_v1.3.md`) and before any stress-set simulation was run. No confirmatory outcome exists.

## Why

The fourth audit found no critical issue. It found that C2 = 2.37 has no margin. Two credible structures outside the registered family over-call under it:
- north–south elongated anisotropic fields: about 5.4–5.9%;
- compartment-level clustering: 5.6% at a compartment share of 0.08.

It also found that S13's C2_M2 = 3.74 under-covers exact long-range fields (about 6.0%). Its range checks used exact (Cholesky) fields, because the 512 km periodic grid distorts long ranges.

## Decision

v1.4 keeps the registered calibration (`CALIBRATION.json`, unchanged) and adds a **stress set** of structures outside it. The final critical values are the maxima over both:
- **C2** = max(C2 of `CALIBRATION.json`, the stress set's largest 95th percentile of |T| under M2R, rounded up to two decimals);
- **C1** is the same at the 90th percentile;
- **C2_M2 and C1_M2** are the same for M2 (S13).

`calibrate_stress.py` → `CRITICAL_VALUES.json`; `run_test.py` reads the final values from there.

**The stress set**, fixed here before any of it is simulated. All fields are exact: Cholesky factors of the covariance at the actual points, with a jitter of 1e-6 on the diagonal (more only if the factorization fails, and recorded).

1. **S-A, anisotropic exponential fields,** correlation exp(−√((dx/rx)² + (dy/ry)²)):
   - orientation north–south (rx short, ry long) or east–west (the transpose);
   - (short, long) ranges of (10, 60), (10, 120), (15, 90) and (20, 180) km;
   - shares 0.08, 0.10, 0.13, 0.15, 0.20 and 0.25.

   That is 48 candidates.
2. **S-L, long-range isotropic exponential fields:** ranges of 180, 240, 360, 480 and 720 km × shares 0.3, 0.4, 0.5, 0.6, 0.7, 0.8 and 0.9. That is 35 candidates.
3. **S-C, compartment random effects** (one effect per definition-B compartment, from the compartment labels of each design): shares 0.02, 0.04, 0.06, 0.08, 0.10, 0.12 and 0.15. That is 7 candidates.

**Screens, on the pilot's design, 1,000 replicates each:**
- **S-A and S-L:** the registered statistic, the exponential fit (share, range) to the residual correlogram, refitted exactly as for the real residuals. A model is retained if the pilot's observed fit lies inside the central 95% of the simulated fits on both.
- **S-C:** the one-way ANOVA share between compartments of the pilot's M2 residuals. A model is retained if the observed share lies inside the central 95% of the simulated ones.
- **No directional screen is applied,** so east–west fields are kept whenever the registered statistic keeps them. That is conservative.

**Simulation.** Every retained stress model gets 4,000 null replicates on this region's blind design, for both statistics. There is no monotonicity shortcut.

**Checks.**
- `validate_synthetic.py` re-runs every stress model on fresh seeds: 10,000 replicates for the binding models and 500 for the others (limit 0.084 = 5% + 3.5 Monte Carlo SE).
- `pilot_reread.py` adds the retained stress models on the pilot's design.

**Not changed:** the model (M2R), the statistic, the registered calibration and its screen, and the decision structure. Structures outside both sets (for example correlation that changes from year to year, or other shapes) remain a disclosed residual risk.
